"""
ora_gui.py — ORA MODELER, interfaz gráfica.

Flujo con clics, sin CMD:
  1) Elegir el plano DXF y su unidad.
  2) "Analizar plano" -> informe en pantalla (muros, vanos, columnas,
     escalera, plantas, dudas) + formulario de decisiones.
  3) "Generar 3D y abrir SketchUp" -> crea salidas/modelo.rb, deja la marca
     de autocarga y abre SketchUp: el modelo se construye solo (plugin v2).

Tema claro y oscuro con el logo de ORA Modeler.
Todo usa el MISMO motor que la línea de comandos (kernel/adaptador/exportador).
"""

import json
import os
import re
import subprocess
import sys
import tempfile
import threading
import time

# ---------------------------------------------------------------------
# TRACE FORENSE — fase de solo instrumentación (ver REGLAMENTO/README_TRACE).
#
# Envuelve cada módulo dependiente de ORA ANTES de que nada más lo importe,
# para que cualquier `from X import y` posterior — esté en ora_gui.py o
# dentro de ora.py/adaptador_dwg.py/memoria_elementos.py, que este parche NO
# toca — reciba la versión trazada sin modificar el código fuente de esos
# módulos ni un solo bit de su comportamiento.
#
# Si algo de esto falla (un módulo no está en este entorno, o lo que sea),
# ORA tiene que seguir abriendo exactamente igual que sin TRACE: por eso
# cada intento va en su propio try/except y nunca se deja subir un error
# de instrumentación hasta el arranque real del programa.
class _TraceNulo:
    """Se usa SOLO si trace_forense.py no se pudo importar. Cualquier
    llamada `trace_forense.lo_que_sea(...)` en el resto de este archivo
    queda como no-operación, para no tener que blindar cada punto de
    instrumentación con un `if trace_forense:` — y para que la ausencia
    de trace_forense.py nunca sea, en sí misma, un motivo de que ORA truene."""
    def __getattr__(self, _nombre):
        return lambda *a, **kw: None


try:
    import trace_forense
    for _m_trace in ("memoria_elementos", "kernel", "adaptador_dwg", "ora",
                      "exportar_sketchup", "apilar_pisos", "rutas_datos",
                      "sincronizacion_vivo", "evidencia", "vigas"):
        try:
            trace_forense.envolver_modulo_seguro(_m_trace)
        except Exception:
            pass
except Exception:
    trace_forense = _TraceNulo()
# ---------------------------------------------------------------------

BASE = os.path.dirname(os.path.abspath(__file__))


def _tiene_plugin_ora(exe):
    """¿Esa versión de SketchUp tiene instalado el plugin de ORA?

    Los Plugins de SketchUp viven en
    %APPDATA%\\SketchUp\\SketchUp <año>\\SketchUp\\Plugins — una carpeta POR
    VERSIÓN. Saberlo evita abrir un SketchUp donde ORA no puede hacer nada.
    """
    try:
        anio = ""
        for parte in os.path.normpath(exe).split(os.sep):
            m = re.search(r"(20\d\d)", parte)
            if m:
                anio = m.group(1)
        if not anio:
            return False
        base = os.path.join(os.environ.get("APPDATA", ""), "SketchUp",
                            "SketchUp " + anio, "SketchUp", "Plugins")
        if not os.path.isdir(base):
            return False
        return any("ora_importer" in n.lower() for n in os.listdir(base))
    except Exception:
        return False


def _log_arranque(msg):
    print("[ORA] " + msg)


os.chdir(BASE)
sys.path.insert(0, BASE)

# ------------------------- temas -------------------------
TEMAS = {
    "claro": {
        "bg": "#f4f6f9", "panel": "#ffffff", "texto": "#1d2733",
        "acento": "#1257d8", "acento_txt": "#ffffff", "borde": "#d7dde6",
        "ok": "#1a7f37", "warn": "#b45309", "logo": "assets/logo_claro.png",
        "consola_bg": "#ffffff", "consola_fg": "#1d2733",
    },
    "oscuro": {
        "bg": "#1e222a", "panel": "#262b35", "texto": "#e8ecf2",
        "acento": "#3b82f6", "acento_txt": "#ffffff", "borde": "#39404d",
        "ok": "#4ade80", "warn": "#fbbf24", "logo": "assets/logo_oscuro.png",
        "consola_bg": "#14171d", "consola_fg": "#d7dee8",
    },
}


# ------------------------- motor (sin ventana) -------------------------
class Motor:
    """Envuelve el pipeline ORA para usarlo desde la interfaz."""

    def __init__(self):
        self.kernel = None
        self.resumen = None
        self.archivo = None
        self.unidad = "m"

    def analizar(self, archivo, unidad, cuadro_manual=None, archivo_specs=None,
                 archivo_cortes=None, z_base=None):
        from kernel import ORAKernel
        from adaptador_dwg import importar_dxf, levantar_con_cruce
        self.archivo, self.unidad = archivo, unidad
        self.archivo_specs = archivo_specs
        self.modelo = None
        self.archivo_cortes = archivo_cortes
        # EL KERNEL SE ASIGNA AL FINAL, NO AL PRINCIPIO. Antes se hacía
        # `self.kernel = ORAKernel()` aquí arriba: si la lectura del DXF
        # fallaba a medias, el motor quedaba con un kernel vacío y sin
        # resumen — medio analizado. Desde ahí, cualquier cosa que generara
        # reventaba con "'NoneType' object has no attribute 'to_dict'".
        # Ahora, o se analiza entero, o el motor se queda como estaba.
        k = ORAKernel()
        if archivo_specs:
            resumen, self.nota_cruce = levantar_con_cruce(
                k, archivo, archivo_specs, unidad=unidad,
                cuadro_manual=cuadro_manual, archivo_cortes=archivo_cortes,
                z_base=z_base)
        else:
            self.nota_cruce = ""
            resumen = importar_dxf(k, archivo, unidad=unidad, z_base=z_base,
                                   cuadro_manual=cuadro_manual,
                                   archivo_cortes=archivo_cortes)
        self.kernel, self.resumen = k, resumen
        self._reponer_peraltes()
        # El modelo, para poder buscar el contorno de cualquier elemento por
        # su nombre y recortarle su evidencia sin llevarle coordenadas a mano.
        try:
            self.modelo = k.to_dict()
        except Exception:
            self.modelo = None
        return self.resumen

    def analizar_edificio(self, pisos_config, unidad, archivo_cortes=None,
                          progreso=None):
        """FASE D: un DXF limpio + un DXF de datos POR PISO, apilados con su
        cota real (los sótanos van con cota negativa). El DXF de cortes es uno
        solo, del edificio completo."""
        from kernel import ORAKernel
        from apilar_pisos import apilar
        self.archivo = pisos_config[0]["dxf"] if pisos_config else None
        self.unidad = unidad
        self.archivo_specs = None
        self.archivo_cortes = archivo_cortes
        self.pisos_config = pisos_config
        # Mismo criterio que en `analizar`: el kernel se asigna solo si el
        # apilado termina bien. Un edificio a medio leer no puede dejar el
        # motor en un estado que reviente al generar.
        k = ORAKernel()
        self.nota_cruce = ""
        resumen = apilar(k, pisos_config, unidad=unidad,
                         archivo_cortes=archivo_cortes, progreso=progreso)
        self.kernel, self.resumen = k, resumen
        self._reponer_peraltes()
        return self.resumen

    def _reponer_peraltes(self):
        """Devuelve a las vigas el peralte que el usuario ya había escrito.

        Analizar reconstruye `resumen` desde el DXF, y el peralte NO está en
        el DXF: está donde Willy lo escribió. Sin esto se borraba en cada
        cambio de paso y el paso de Vigas no levantaba nada.
        """
        try:
            from memoria_elementos import peraltes_de
            guardados = peraltes_de(getattr(self, "firma_memoria", None)
                                    or (self.resumen or {}).get(
                                        "clasificacion_capas", {}).get("firma"),
                                    int(getattr(self, "piso_activo", 0) or 0))
        except Exception:
            return
        if not guardados:
            return
        n = 0
        for v in ((self.resumen or {}).get("vigas") or []):
            nom = str(v.get("nombre") or "")
            base = nom.split("_")[0] if "_" in nom else nom
            val = guardados.get(nom, guardados.get(base))
            # v91-peraltes · `guardados` SOLO contiene lo que Willy confirmó
            # a mano en "Aplicar a las marcadas" (unico escritor de
            # guardar_peraltes() en todo el archivo). Antes, `and not
            # v.get("peralte")` bloqueaba la confirmacion manual cada vez
            # que el DXF/corte YA traia un valor propio (como VG05, que sale
            # en 0.30 por el texto "V2") -- la unica viga donde SI se veia
            # el cambio era una sin peralte de origen (como el VG01 de
            # Azotea). La lectura del DXF/corte no cambia: sigue calculando
            # lo mismo; esto solo decide cual de los dos gana al final.
            if val:
                v["peralte"] = float(val)
                v["peralte_asumido"] = False
                v["fuente_peralte"] = "escrito por ti (recordado)"
                n += 1
        if n:
            print(f"  ↺ {n} viga(s) recuperan el peralte que ya habías escrito.")
        self._reponer_npt_pisos()

    def _reponer_npt_pisos(self):
        """Devuelve a los paños el NPT que el usuario ya había escrito.

        Igual que el peralte: analizar reconstruye `resumen` desde el DXF y
        ese dato no está en el DXF. Sin esto, el aviso que resolviste vuelve
        a salir en cuanto cambias de paso.
        """
        try:
            from memoria_elementos import npt_pisos_de
            guardados = npt_pisos_de(
                getattr(self, "firma_memoria", None)
                or (self.resumen or {}).get(
                    "clasificacion_capas", {}).get("firma"),
                int(getattr(self, "piso_activo", 0) or 0))
        except Exception:
            return
        if not guardados:
            return
        n = 0
        for p in ((self.resumen or {}).get("pisos") or []):
            nom = str(p.get("nombre") or "")
            if nom not in guardados:
                continue
            val = guardados[nom]
            if val is None:
                # «Déjalo como cara»: se respeta y no vuelve a preguntar.
                p["npt_declarado"] = False
                p["npt_resuelto"] = True
            else:
                p["npt"] = round(float(val), 3)
                p["npt_declarado"] = True
                p["npt_fuente"] = "escrito por ti (recordado)"
            n += 1
        if n:
            print(f"  ↺ {n} paño(s) recuperan el NPT que ya habías escrito.")

    # ---------------- FICHA DE UN ELEMENTO (selección en vivo) ----------------
    def ficha_de(self, nombre_grupo):
        """Texto de la ficha del elemento que está seleccionado en SketchUp.
        `nombre_grupo` llega como 'ORA_M06' (el nombre del grupo)."""
        if not self.kernel:
            return None
        nombre = nombre_grupo[4:] if nombre_grupo.startswith("ORA_") else nombre_grupo
        modelo = self.kernel.to_dict()
        objetivo = None
        for ent_id, ent in modelo["entities"].items():
            if ((ent.get("properties") or {}).get("nombre")) == nombre:
                objetivo = (ent_id, ent)
                break
        if not objetivo:
            return f"{nombre}\n(no es un elemento del plano: piso, techo o alerta)"
        ent_id, ent = objetivo
        pr = ent.get("properties") or {}
        etiquetas = {"wall": "Muro", "door": "Puerta", "window": "Ventana",
                     "column": "Columna", "slab": "Losa", "stair": "Escalera"}
        sub = {"muro_bajo": " bajo", "muro_vista": " en vista"}.get(pr.get("subtipo"), "")
        lineas = [f"{nombre} — {etiquetas.get(ent['type'], ent['type'])}{sub}"]
        amb = pr.get("ambientes") or []
        if amb:
            lineas.append("Ambiente: " + ", ".join(
                f"{a.get('nombre') or '?'} (NPT {a.get('npt', 0):+.2f})" for a in amb))
        if ent.get("thickness"):
            lineas.append(f"Espesor medido: {ent['thickness']:.3f} m")
        alt = ent.get("height")
        if isinstance(alt, (int, float)):
            origen = pr.get("altura_origen")
            if pr.get("altura_por_defecto"):
                lineas.append("Altura: la general de '2 · Decisiones'")
            else:
                lineas.append(f"Altura: {alt:.2f} m"
                              + (f" (del {origen})" if origen else ""))
        if pr.get("npt_base") is not None:
            lineas.append(f"Arranca en NPT {pr['npt_base']:+.2f} · "
                          f"altura libre desde {pr.get('npt_ref', 0):+.2f}")
        vanos = [modelo["entities"][r["source"]] for r in modelo.get("relationships", [])
                 if r["type"] == "opening_in" and r["target"] == ent_id]
        if vanos:
            lineas.append("Vanos: " + ", ".join(
                f"{(v.get('properties') or {}).get('codigo') or '?'} "
                f"({(v.get('properties') or {}).get('ancho', 0):.2f}×{v.get('height', 0):.2f})"
                for v in vanos))
        for campo, texto in (("corte_espesor", "Espesor de corte"),):
            if pr.get(campo):
                lineas.append(f"{texto}: {pr[campo]} m")
        if pr.get("aviso_npt"):
            lineas.append("⚠ " + pr["aviso_npt"])
        return "\n".join(lineas)

    def informe(self):
        from ora import _informe
        base = _informe(self.resumen, self.kernel.to_dict(), self.archivo)
        if (self.resumen or {}).get("edificio"):
            from apilar_pisos import resumen_texto
            base = resumen_texto(self.resumen) + "\n\n" + base
        extra = []
        r = self.resumen or {}
        # VIGAS: cuántas se leyeron y cuáles cuelgan del techo.
        vg = r.get("vigas") or []
        if vg:
            peraltadas = [v for v in vg if v.get("tipo") == "peraltada"]
            extra.append(
                f"🏗️ {len(vg)} viga(s) declaradas"
                + (f" · {len(peraltadas)} peraltada(s) que cuelgan del techo "
                   "y quitan altura libre" if peraltadas else ""))
            asumidas = [v for v in vg if v.get("peralte_asumido")]
            if asumidas:
                extra.append(f"   ⚠ {len(asumidas)} sin peralte en ningún plano: "
                             "se asumió 0.60 m.")
        # DIFERENCIAS ENTRE PLANTAS: esto ya no es modelado, es revisión de
        # planos — encuentra el error de dibujo antes que el revisor municipal.
        for d in (r.get("diferencias_entre_plantas") or []):
            extra.append(
                f"🔍 Piso {d['b'] + 1} y Piso {d['a'] + 1} son "
                f"{d['parecido'] * 100:.0f}% iguales pero NO idénticos:")
            for linea in d["detalle"][:4]:
                extra.append(f"   · {linea}")
        aviso = self._aviso_aprendido()
        partes = ([aviso] if aviso else []) + (["\n".join(extra)] if extra else [])
        return ("\n\n".join(partes) + "\n\n" + base) if partes else base

    def _aviso_aprendido(self):
        """4.2: el informe de análisis SIEMPRE muestra la lectura cruda del
        DXF (por diseño), nunca lo aprendido/congelado — eso confundía mucho
        a Willy, porque el informe se veía IDÉNTICO en la segunda vuelta y
        parecía que las correcciones no se estaban guardando. Esto no cambia
        los valores mostrados (el informe sigue siendo la lectura del plano),
        solo agrega un aviso de cuántos elementos tienen una corrección ya
        confirmada que SÍ se va a aplicar al generar el modelo 3D."""
        try:
            from memoria_elementos import congelados_de
        except Exception:
            return ""
        firma = ((self.resumen or {}).get("clasificacion_capas") or {}).get("firma")
        if not firma:
            return ""
        total = 0
        if (self.resumen or {}).get("edificio"):
            for lvl in (self.resumen.get("niveles") or []):
                total += len(congelados_de(firma, lvl.get("index", 0)))
        else:
            total = len(congelados_de(firma, getattr(self, "piso_activo", 0)))
        if not total:
            return ""
        return (f"ℹ️ {total} elemento(s) tienen una corrección aprendida "
                "(medidas ya confirmadas en SketchUp) que se aplicará al "
                "generar el modelo. Este informe muestra la lectura CRUDA del "
                "DXF, no esas correcciones — revísalas en la tabla de "
                "elementos, no aquí.")

    def generar(self, dec, categorias=None, preguntar=True):
        from ora import (_generar_escalera, generar_escalera_desde_peldanos,
                         generar_vigas)
        from exportar_sketchup import exportar_a_ruby
        from memoria_elementos import procesar_deltas_pendientes
        # ÚLTIMA BARRERA. La interfaz ya no deja llegar aquí sin plano, pero
        # el motor no puede fiarse de eso: si alguna vez vuelve a colarse una
        # llamada (un pulso de SketchUp, un botón nuevo), tiene que decir qué
        # pasa, no reventar con "'NoneType' object has no attribute 'to_dict'".
        if self.kernel is None or not self.resumen:
            raise RuntimeError(
                "Todavía no hay ningún plano analizado. Elige tu DXF limpio "
                "en «1 · Plano» y pulsa ANALIZAR PLANO.")
        os.makedirs("salidas", exist_ok=True)
        with open("salidas/decisiones.json", "w", encoding="utf-8") as f:
            json.dump(dec, f, ensure_ascii=False, indent=2)
        self.avisos_escalera = []
        esc = self.resumen.get("escalera") if self.resumen else None
        multi = (self.resumen or {}).get("escaleras") or []
        if dec.get("escalera") and multi:
            # BLOQUE 0.5: cada escalera del plano se genera POR SEPARADO, con
            # sus propios ajustes. Antes ORA asumía una sola y metía todos los
            # peldaños en el mismo saco: en un proyecto con dos escaleras se
            # encadenaban entre sí y salía cualquier cosa. Ahora, si una falla,
            # las demás se generan igual.
            for eid in [i for i, e in self.kernel.project.entities.items()
                        if e.type == "stair"]:
                self.kernel.delete_entity(eid)
            for _e in multi:
                _dec_e = dict(dec)
                # Ajustes propios de ESTA escalera (contrahuella, NPT, sentido,
                # espesores): el asistente los guarda por id.
                _dec_e.update((dec.get("escaleras_ajustes") or {})
                              .get(str(_e["id"]), {}))
                try:
                    _n, _av = generar_escalera_desde_peldanos(
                        self.kernel, _e, _dec_e, limpiar_previas=False)
                    self.avisos_escalera += [f"Escalera {_e['id']}: {a}"
                                             for a in _av]
                except Exception as ex:
                    self.avisos_escalera.append(
                        f"Escalera {_e['id']} ({_e['forma']['forma']}) no se "
                        f"pudo generar: {ex}. Las demás sí se generaron.")
        elif dec.get("escalera") and esc:
            if esc.get("real"):
                # Peldaños REALES del plano: solo se les da altura.
                _n, self.avisos_escalera = generar_escalera_desde_peldanos(
                    self.kernel, esc, dec)
            else:
                # El plano no trae peldaños dibujados: respaldo por cuestionario.
                for eid in [i for i, e in self.kernel.project.entities.items()
                            if e.type == "stair"]:
                    self.kernel.delete_entity(eid)
                _generar_escalera(self.kernel, esc, dec)

        # ---- VIGAS ----
        # Van después de la escalera y antes de serializar: necesitan el techo
        # ya confirmado para saber dónde está la cara superior del entrepiso.
        self.avisos_vigas = []
        _firma_trace = (getattr(self, "firma_memoria", None)
                        or (self.resumen or {}).get(
                            "clasificacion_capas", {}).get("firma"))
        _piso_trace = getattr(self, "piso_activo", 0)
        if dec.get("vigas", True):
            try:
                _dv = dict(dec)
                _dv["vigas_sin_recortar"] = getattr(
                    self, "vigas_sin_recortar", False)
                # ---- TRACE: TODO lo que entra a generar_vigas() --------
                # Caso prioritario del encargo. Ahora sí se ve el cálculo
                # interno también (cota_llegada/_corona/ajustes quedan
                # instrumentados directamente dentro de ora.py), pero esto
                # deja además el punto de entrada/salida de la función
                # completa, para comparar de un vistazo.
                trace_forense.evento(
                    "vigas:entrada_generar_vigas", modulo="ora",
                    funcion="generar_vigas", firma=_firma_trace,
                    piso=_piso_trace,
                    datos={
                        "altura_muro": dec.get("altura_muro"),
                        "espesor_losa": dec.get("espesor_losa"),
                        "vigas_sin_recortar": _dv["vigas_sin_recortar"],
                        "vigas_confirmadas_keys":
                            list((dec.get("vigas_confirmadas") or {}).keys()),
                        "muros_confirmados_keys":
                            list((dec.get("muros_confirmados") or {}).keys()),
                        "peraltes_previos": {
                            v.get("nombre"): v.get("peralte")
                            for v in (self.resumen or {}).get("vigas") or []},
                    })
                _nv, _av = generar_vigas(self.kernel, self.resumen or {}, _dv)
                self.avisos_vigas += _av
                trace_forense.evento(
                    "vigas:salida_generar_vigas", modulo="ora",
                    funcion="generar_vigas", firma=_firma_trace,
                    piso=_piso_trace,
                    datos={"generadas_o_contador": _nv, "avisos": _av})
            except Exception as ex:
                trace_forense.excepcion(
                    ex, funcion="generar_vigas", firma=_firma_trace,
                    piso=_piso_trace)
                self.avisos_vigas = [f"No se pudieron generar las vigas: {ex}. "
                                     "El resto del modelo sí se generó."]
        modelo = self.kernel.to_dict()
        # ---- TRACE: Z real de cada viga en el kernel YA generado -------
        # Este es el primer punto, después de generar_vigas(), donde se
        # puede leer la Z que CADA viga terminó teniendo. Si más adelante
        # Ruby/SketchUp devuelve una Z distinta a la que aparece aquí, el
        # LAST WRITER de trace_forense lo señala solo.
        try:
            for _ent in modelo.get("entities", {}).values():
                if _ent.get("type") != "beam":
                    continue
                _pr = _ent.get("properties") or {}
                _nombre_v = _pr.get("nombre")
                if not _nombre_v:
                    continue
                trace_forense.escritura(
                    archivo="kernel.to_dict() (post generar_vigas)",
                    funcion="Motor.generar", firma=_firma_trace,
                    piso=_piso_trace, elemento=_nombre_v, campo="height",
                    valor=_ent.get("height"), es_confirmacion=False,
                    npt_base=_pr.get("npt_base"), thickness=_ent.get("thickness"))
        except Exception as ex:
            trace_forense.excepcion(ex, funcion="Motor.generar:snapshot_vigas",
                                     firma=_firma_trace, piso=_piso_trace)

        # Aprendizaje: aplicar lo que el usuario haya borrado/movido en
        # SketchUp desde la última vez (mapa nombre-de-elemento -> piso).
        # LA MISMA ETIQUETA QUE USA LA INTERFAZ PARA LEER (v57). Si aquí se
        # escribe con la firma del plano cargado y allí se lee con la del
        # edificio, lo confirmado se pierde. `firma_memoria` lo fija quien
        # manda: la interfaz.
        firma = (getattr(self, "firma_memoria", None)
                 or self.resumen.get("clasificacion_capas", {}).get("firma"))
        mensajes_aprendizaje = []
        if firma:
            mapa_np = {}
            for ent in modelo["entities"].values():
                nombre = (ent.get("properties") or {}).get("nombre")
                if nombre:
                    lvl = modelo["levels"].get(ent["level_id"], {})
                    mapa_np[nombre] = int(lvl.get("index", 0))
            mensajes_aprendizaje = procesar_deltas_pendientes(firma, mapa_np)
        self.mensajes_aprendizaje = mensajes_aprendizaje

        with open("salidas/modelo_generado.json", "w", encoding="utf-8") as f:
            json.dump(modelo, f, ensure_ascii=False, indent=2, default=str)
        with open("salidas/analisis.txt", "w", encoding="utf-8") as f:
            f.write(self.informe())
        fichas = {}
        if os.path.exists("biblioteca/fichas.json"):
            with open("biblioteca/fichas.json", encoding="utf-8") as f:
                fichas = json.load(f)
        # ---- TRACE: frontera Python -> Ruby ----------------------------
        # exportar_a_ruby ya queda trazado en general por el envoltorio de
        # módulo del bootstrap (entrada/salida/duración). Aquí se agrega
        # el detalle fino que el encargo pidió para vigas específicamente,
        # y se deja marcado que verificar el resultado REAL dentro de
        # SketchUp — Z final del objeto, si el corte se aplicó — es un
        # punto que requiere evidencia visual (sección 18 del encargo).
        trace_forense.evento(
            "ruby:exportar_a_ruby:entrada", modulo="exportar_sketchup",
            funcion="exportar_a_ruby", firma=firma, piso=_piso_trace,
            datos={"altura_muro": dec["altura_muro"],
                   "espesor_losa": dec["espesor_losa"],
                   "piso_edificio": (dec.get("nivel") or {}).get("piso"),
                   "npt_nivel": dec.get("nivel", {}).get("npt"),
                   "vigas_z_enviadas": {
                       _e.get("properties", {}).get("nombre"): _e.get("height")
                       for _e in modelo.get("entities", {}).values()
                       if _e.get("type") == "beam"}})
        total = exportar_a_ruby(
            modelo, "salidas/modelo.rb",
            altura_muro=dec["altura_muro"], espesor_losa=dec["espesor_losa"],
            con_carpinteria=dec.get("carpinteria", False),
            dudas=self.resumen.get("dudas") or [],
            alertas=self.resumen.get("alertas") or [],
            mobiliario=self.resumen.get("mobiliario") or [],
            fichas=fichas, pisos=self.resumen.get("pisos") or [],
            techos=self.resumen.get("techos") or [],
            firma_plano=firma, categorias=categorias,
            altura_desde_npt=dec.get("altura_desde_npt", True),
            preguntar=preguntar,
            ajustes_vano=self._ajustes_vano_actuales(firma),
            # MODO EDIFICIO. `nivel` lo pone la interfaz al elegir la planta
            # activa; en modo un piso llega vacío y no cambia nada.
            alturas_subtipo=dec.get("alturas_subtipo") or {},
            piso_edificio=(dec.get("nivel") or {}).get("piso") or None,
            nombre_piso=(dec.get("nivel") or {}).get("grupo") or None,
            losa_cuelga=bool((dec.get("nivel") or {}).get("cuelga")),
            # NPT DEL NIVEL (v55). Willy: «cada piso, los muros empiezan a
            # partir de SU piso». Sin este dato el ajuste de altura usaba el
            # NPT ABSOLUTO del ambiente: en la planta típica (NPT +2.75) los
            # muros salían de ALTURA_MURO + 2.75 = 5.15 m, y en la azotea
            # peor. Con el NPT del nivel el ajuste vuelve a ser relativo a su
            # propio piso, que es lo que siempre debió ser.
            npt_nivel=float((dec.get("nivel") or {}).get("npt") or 0.0),
            # Solo la planta MÁS BAJA apoya en terreno: su piso rellena hasta
            # su NPT (los 15 cm del piso 1). Las demás llevan losa.
            sobre_terreno=bool((dec.get("nivel") or {}).get("sobre_terreno", True)),
            # v65.4: la POSICIÓN de la planta decide si el muro nace en el
            # terreno, y el RELLENO medido en el corte decide cuánto baja.
            nace_en_terreno=(dec.get("nivel") or {}).get("nace_en_terreno"),
            relleno_planta=((self.resumen or {}).get("medido_en_el_corte")
                            or {}).get("relleno_piso"),
            sugerencias=(self.resumen or {}).get("sugerencias_corte"))
        trace_forense.evento(
            "ruby:exportar_a_ruby:salida", modulo="exportar_sketchup",
            funcion="exportar_a_ruby", firma=firma, piso=_piso_trace,
            datos={"total_elementos_exportados": total,
                   "archivo_generado": "salidas/modelo.rb"})
        trace_forense.marcar_evidencia_visual(
            "Confirmar en SketchUp la Z real de cada viga listada arriba en "
            "'vigas_z_enviadas' DESPUÉS de abrir/actualizar salidas/modelo.rb "
            "-- Python no puede leer el resultado dentro de SketchUp sin "
            "instrumentar también el plugin .rb.", firma=firma, piso=_piso_trace,
            archivo_a_revisar="salidas/modelo.rb")

        # Un contorno que SketchUp no puede dibujar dejaba un hueco en el
        # modelo sin decir nada (el `rescue` del Ruby solo escribe en la
        # consola, que nadie tiene abierta). Ahora sube a la interfaz.
        try:
            from exportar_sketchup import CONTORNOS_RECHAZADOS
            self.avisos_dibujo = list(CONTORNOS_RECHAZADOS)
        except Exception:
            self.avisos_dibujo = []

        # Lista de "esperados" para que el plugin, al GUARDAR, sepa qué generó
        # ORA y detecte qué borró/movió/editó-por-dentro el usuario.
        # Formato: "ORA_nombre|caras|aristas|volumen" (firma interna aproximada).
        try:
            import tempfile
            from exportar_sketchup import expandir_categorias, CAT_DE_TIPO
            # SOLO lo que ESTE paso generó de verdad. Antes se declaraban todas
            # las entidades del modelo aunque el paso fuera solo Muros+Pisos:
            # al guardar en SketchUp, el plugin veía que las columnas, vanos,
            # peldaños y techos "esperados" no estaban en el modelo y los
            # aprendía como BORRADOS POR EL USUARIO. De ahí salieron los 41
            # elementos excluidos que nadie borró. Lo que todavía no se generó
            # no puede contar como borrado.
            cats_paso = expandir_categorias(categorias)
            # MODO PREVIA: solo se dibujan cajas translúcidas ORA_PREVIA_*, no
            # los vanos de verdad. Si acá declaráramos los vanos como
            # "generados", al guardar en SketchUp el plugin los vería ausentes
            # y los aprendería como BORRADOS POR EL USUARIO — que es
            # exactamente lo que dejó los 11 vanos excluidos y por lo que la
            # puerta de entrada no volvía a aparecer nunca.
            if "vanos_previa" in cats_paso:
                cats_paso = set()
            # VANO CORTADO = HUECO DENTRO DEL MURO, no un grupo suyo.
            # Al cortar, 'ORA_M03-P-2' deja de existir como grupo de SketchUp:
            # pasa a ser un agujero dentro del grupo del muro. Si se declara
            # como esperado, al guardar el plugin lo busca, no lo encuentra, y
            # aprende que EL USUARIO LO BORRÓ. Resultado: en la siguiente
            # corrida del mismo plano ese vano queda excluido para siempre y no
            # se vuelve a cortar nunca.
            # (Comprobado en el diagnóstico del 31/07: los 7 vanos que Willy
            # acababa de cortar bien aparecían como 'borrado_en_sketchup', y en
            # ora_estado_vivo.txt no había ni un solo grupo de vano.)
            #
            # ÚNICA excepción: con «Carpintería en vanos» activada sí se crea
            # un grupo 'ORA_<vano>' con el panel, y entonces sí puede (y debe)
            # comprobarse su existencia.
            _hay_carpinteria = bool(dec.get("carpinteria", False))
            lineas = []
            for ent in modelo["entities"].values():
                nombre = (ent.get("properties") or {}).get("nombre")
                if not nombre:
                    continue
                pr = ent.get("properties") or {}
                if pr.get("subtipo") == "mobiliario":
                    cat = "mobiliario"
                elif ent["type"] in ("door", "window"):
                    cat = "vanos"
                    # Sin carpintería el vano es solo un hueco: no hay grupo
                    # que buscar, así que no se declara (ver nota de arriba).
                    if not _hay_carpinteria:
                        continue
                else:
                    cat = CAT_DE_TIPO.get(ent["type"], "muros")
                if cat not in cats_paso:
                    continue
                # firma interna esperada: una caja simple = 6 caras, 12 aristas;
                # el volumen aproximado por tipo (el plugin compara con tolerancia).
                # La firma real la mide SketchUp al terminar de construir y la
                # guarda él mismo (ver ora_importer.rb). Aquí solo se declara
                # QUÉ elementos generó ORA. Antes se mandaba un volumen
                # inventado (-1) que nunca coincidía, y eso marcaba TODOS los
                # muros como "editados por el usuario" desde el primer guardado,
                # congelándolos con datos viejos. Ese era el bug de fondo.
                lineas.append(f"ORA_{nombre}|{ent['type']}")
            ruta_esp = os.path.join(tempfile.gettempdir(), "ora_esperados.txt")
            with open(ruta_esp, "w", encoding="utf-8") as f:
                f.write("\n".join(lineas))
        except Exception:
            pass
        return total

    piso_activo = 0      # lo actualiza la interfaz al cambiar de piso

    def _ajustes_vano_actuales(self, firma):
        """Corrimientos que el usuario aplicó a las cajas de PREVIA de los
        vanos. Si movió una caja a donde de verdad va el hueco, el corte real
        sale ya en ese sitio."""
        if not firma:
            return {}
        try:
            from memoria_elementos import ajustes_vano_de
            return ajustes_vano_de(firma, getattr(self, "piso_activo", 0))
        except Exception:
            return {}

    @staticmethod
    def abrir_sketchup():
        """Deja la marca de autocarga y abre SketchUp. Devuelve (ok, mensaje)."""
        from ia_asistente import cargar_config
        ruta_rb = os.path.abspath(os.path.join(BASE, "salidas", "modelo.rb"))
        marca = os.path.join(tempfile.gettempdir(), "ora_autoload.txt")
        with open(marca, "w", encoding="utf-8") as f:
            f.write(ruta_rb)
        cfg = cargar_config()
        guardado = cfg.get("sketchup_exe", "")
        if guardado and os.path.exists(guardado):
            subprocess.Popen([guardado])
            return True, f"SketchUp abierto: el modelo se construirá solo.\n({guardado})"
        candidatos = []
        raices = [os.environ.get("ProgramFiles", r"C:\\Program Files"),
                  os.environ.get("ProgramFiles(x86)", ""),
                  os.environ.get("LOCALAPPDATA", "")]
        for pf in raices:
            if not pf or not os.path.isdir(pf):
                continue
            for carpeta in ("SketchUp", "SketchUp Pro", "Trimble"):
                base = os.path.join(pf, carpeta)
                if not os.path.isdir(base):
                    continue
                for d in sorted(os.listdir(base), reverse=True):
                    for exe_rel in ("SketchUp.exe", os.path.join("SketchUp", "SketchUp.exe")):
                        exe = os.path.join(base, d, exe_rel)
                        if os.path.exists(exe):
                            candidatos.append(exe)
        # ELEGIR LA VERSIÓN QUE TIENE EL PLUGIN, no la más nueva.
        # Los plugins de SketchUp son POR VERSIÓN: el .rbz instalado en 2024
        # no existe en 2026. Como los candidatos se ordenaban al revés, con
        # las dos versiones instaladas ORA abría siempre la más alta — y ahí
        # el plugin no está, así que no llegaba nada y sin ningún aviso.
        con_plugin = [e for e in candidatos if _tiene_plugin_ora(e)]
        if con_plugin:
            candidatos = con_plugin + [e for e in candidatos
                                       if e not in con_plugin]
        elif candidatos:
            _log_arranque(
                "Ninguna versión de SketchUp tiene el plugin de ORA "
                "instalado. Instala sketchup_plugin/ora_importer.rbz EN LA "
                "VERSIÓN que vas a usar (los plugins son por versión).")
        if candidatos:
            from ia_asistente import guardar_config
            cfg["sketchup_exe"] = candidatos[0]
            guardar_config(cfg)
            subprocess.Popen([candidatos[0]])
            return True, f"SketchUp abierto: el modelo se construirá solo.\n({candidatos[0]})"
        return False, ("No encontré SketchUp automáticamente.\n"
                       "Indica dónde está en ⚙ Configuración (una sola vez),\n"
                       "o ábrelo tú: el modelo se construirá solo al iniciar.")


# ------------------------- interfaz -------------------------
def main():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    motor = Motor()
    estado = {"tema": "claro", "logo_img": None}

    root = tk.Tk()
    root.title("ORA Modeler")
    root.geometry("1080x760")
    root.minsize(940, 640)

    # ---------- utilidades de tema ----------
    def T():
        return TEMAS[estado["tema"]]

    def cargar_logo():
        ruta = T()["logo"]
        try:
            from PIL import Image, ImageTk
            img = Image.open(ruta)
            w = 380
            h = int(img.height * w / img.width)
            img = img.resize((w, h), Image.LANCZOS)
            estado["logo_img"] = ImageTk.PhotoImage(img)
        except Exception:
            try:
                img = tk.PhotoImage(file=ruta)
                factor = max(1, img.width() // 380)
                estado["logo_img"] = img.subsample(factor, factor)
            except Exception:
                estado["logo_img"] = None
        return estado["logo_img"]

    # ---------- estructura ----------
    cab = tk.Frame(root)
    cab.pack(fill="x", padx=14, pady=(10, 0))
    lbl_logo = tk.Label(cab)
    lbl_logo.pack(side="left")
    btn_tema = tk.Button(cab, text="🌙  Tema oscuro", relief="flat",
                         cursor="hand2", font=("Segoe UI", 10))
    btn_tema.pack(side="right", padx=4)
    btn_config = tk.Button(cab, text="⚙  Configuración", relief="flat",
                           cursor="hand2", font=("Segoe UI", 10))
    btn_config.pack(side="right", padx=4)
    btn_ayuda = tk.Button(cab, text="📘  ¿Cómo preparo mi plano?", relief="flat",
                          cursor="hand2", font=("Segoe UI", 10))
    btn_ayuda.pack(side="right", padx=4)
    # v94 · Biblioteca 3D — fijo en la cabecera, independiente de cualquier
    # proyecto (igual que Ayuda/Configuración): se puede abrir y llenar
    # antes de cargar un plano, o en cualquier momento.
    btn_biblioteca = tk.Button(cab, text="📚  Biblioteca", relief="flat",
                               cursor="hand2", font=("Segoe UI", 10))
    btn_biblioteca.pack(side="right", padx=4)

    cuerpo = tk.Frame(root)
    cuerpo.pack(fill="both", expand=True, padx=14, pady=10)

    # ---- Panel izquierdo con SCROLL PROPIO (independiente del informe) ----
    # Antes 'izq' era un Frame normal: con muchos paneles (Fases, Selección,
    # Escalera...) el contenido se salía de la ventana y no había forma de
    # bajar a verlo. Ahora es un Canvas + Scrollbar; todo lo que antes se
    # colocaba en 'izq' ahora se coloca en 'izq' (el frame interior), igual
    # que antes — el canvas es solo el contenedor que lo hace desplazable.
    IZQ_ANCHO = 300
    izq_cont = tk.Frame(cuerpo, width=IZQ_ANCHO)
    izq_cont.pack(side="left", fill="y", padx=(0, 10))
    izq_cont.pack_propagate(False)
    izq_canvas = tk.Canvas(izq_cont, width=IZQ_ANCHO, highlightthickness=0,
                           bd=0)
    izq_scroll = ttk.Scrollbar(izq_cont, orient="vertical",
                               command=izq_canvas.yview)
    izq_canvas.configure(yscrollcommand=izq_scroll.set)
    izq_canvas.pack(side="left", fill="both", expand=True)
    izq_scroll.pack(side="right", fill="y")
    izq = tk.Frame(izq_canvas)   # <- todo el contenido de "1·2·3" va aquí
    izq_win = izq_canvas.create_window((0, 0), window=izq, anchor="nw",
                                       width=IZQ_ANCHO)

    def _izq_actualizar_scroll(_e=None):
        izq_canvas.configure(scrollregion=izq_canvas.bbox("all"))
    izq.bind("<Configure>", _izq_actualizar_scroll)

    def _izq_rueda(event):
        # Windows/Mac mandan delta; Linux manda Button-4/5. Cubrimos ambos.
        delta = -1 if getattr(event, "delta", 0) > 0 else 1
        if getattr(event, "num", None) == 4:
            delta = -1
        elif getattr(event, "num", None) == 5:
            delta = 1
        izq_canvas.yview_scroll(delta, "units")

    def _izq_activar_rueda(_e=None):
        izq_canvas.bind_all("<MouseWheel>", _izq_rueda)
        izq_canvas.bind_all("<Button-4>", _izq_rueda)
        izq_canvas.bind_all("<Button-5>", _izq_rueda)

    def _izq_desactivar_rueda(_e=None):
        izq_canvas.unbind_all("<MouseWheel>")
        izq_canvas.unbind_all("<Button-4>")
        izq_canvas.unbind_all("<Button-5>")
    # El scroll con la rueda solo actúa cuando el mouse está SOBRE el panel
    # izquierdo, para no robarle el scroll al informe de la derecha.
    izq_canvas.bind("<Enter>", _izq_activar_rueda)
    izq_canvas.bind("<Leave>", _izq_desactivar_rueda)

    der = tk.Frame(cuerpo)
    der.pack(side="right", fill="both", expand=True)

    # ---------- panel izquierdo: pasos ----------
    p1 = tk.LabelFrame(izq, text="  1 · Plano  ", font=("Segoe UI", 10, "bold"),
                       bd=1, relief="solid", padx=10, pady=10)
    p1.pack(fill="x", pady=(0, 8))
    var_archivo = tk.StringVar()
    ent_archivo = tk.Entry(p1, textvariable=var_archivo, width=34,
                           font=("Segoe UI", 9))
    ent_archivo.grid(row=0, column=0, columnspan=2, sticky="we", pady=(0, 2))
    tk.Label(p1, text="① DXF LIMPIO — la geometría (muros, vanos, columnas)",
             font=("Segoe UI", 7), fg="#1a7f37").grid(
        row=1, column=0, columnspan=2, sticky="w")
    btn_buscar = tk.Button(p1, text="📂  Elegir DXF limpio...", cursor="hand2",
                           font=("Segoe UI", 10))
    btn_buscar.grid(row=2, column=0, sticky="we", padx=(0, 4), pady=(2, 0))
    var_unidad = tk.StringVar(value="m")
    cmb_unidad = ttk.Combobox(p1, textvariable=var_unidad, width=6,
                              values=["m", "cm", "mm", "in", "ft"],
                              state="readonly")
    cmb_unidad.grid(row=2, column=1, sticky="we", pady=(2, 0))
    tk.Label(p1, text="unidad del dibujo", font=("Segoe UI", 8)).grid(
        row=3, column=1, sticky="w")
    # Plano de especificaciones (con cotas/cortes/cuadro de vanos) — OPCIONAL
    var_specs = tk.StringVar()
    tk.Label(p1, text="② DXF DE DATOS (opcional) — cuadro de vanos, NPT por "
                      "ambiente, acabados. NO es la geometría: es la ficha "
                      "de información del MISMO plano.",
             font=("Segoe UI", 8), wraplength=270, justify="left").grid(
        row=4, column=0, columnspan=2, sticky="w", pady=(10, 0))
    ent_specs = tk.Entry(p1, textvariable=var_specs, width=34, font=("Segoe UI", 9))
    ent_specs.grid(row=5, column=0, columnspan=2, sticky="we", pady=(2, 4))
    btn_specs = tk.Button(p1, text="📐  Elegir DXF de datos...", cursor="hand2",
                          font=("Segoe UI", 9))
    btn_specs.grid(row=6, column=0, columnspan=2, sticky="we")
    tk.Label(p1, text="ORA cruza los dos: geometría del ① + medidas del ②",
             font=("Segoe UI", 7)).grid(row=7, column=0, columnspan=2, sticky="w")
    var_cortes = tk.StringVar()
    tk.Label(p1, text="③ DXF DE CORTES/elevaciones (opcional) — alturas reales "
                      "por ambiente, rotulado 'CORTE A - A''.",
             font=("Segoe UI", 8), wraplength=270, justify="left").grid(
        row=8, column=0, columnspan=2, sticky="w", pady=(10, 0))
    ent_cortes = tk.Entry(p1, textvariable=var_cortes, width=34, font=("Segoe UI", 9))
    ent_cortes.grid(row=9, column=0, columnspan=2, sticky="we", pady=(2, 4))
    btn_cortes = tk.Button(p1, text="✂️  Elegir DXF de cortes...", cursor="hand2",
                           font=("Segoe UI", 9))
    btn_cortes.grid(row=10, column=0, columnspan=2, sticky="we")
    tk.Label(p1, text="Rotulado 'CORTE A - A'' y con su línea marcada en la planta",
             font=("Segoe UI", 7)).grid(row=11, column=0, columnspan=2, sticky="w")
    # ------------------------------------------------------------------
    # LOS DOS CARRILES (v47)
    # ------------------------------------------------------------------
    # Regla de Willy: «en una sola pantalla está combinándose cosas».
    #   🏠 Un piso     -> el flujo de siempre. Está probado y NO se toca.
    #   🏢 Varios pisos -> la tabla de plantas y el recorrido por niveles.
    # Elegir el carril es lo primero que se hace. A partir de ahí, cada uno
    # enseña solo lo suyo: los campos de un plano suelto no aparecen en
    # multipisos y la tabla de plantas no aparece en un piso.
    # Los campos de un plano suelto: se enseñan SOLO al elegir «Un piso».
    campos_un_piso = [w for w in p1.grid_slaves()
                      if int(w.grid_info().get("row", 99)) <= 10]
    fr_carril = tk.Frame(p1)
    fr_carril.grid(row=12, column=0, columnspan=2, sticky="we", pady=(10, 2))
    modo_app = {"cual": None}
    btn_un_piso = tk.Button(fr_carril, text="🏠  Un piso", cursor="hand2",
                            font=("Segoe UI", 9, "bold"), pady=5)
    btn_un_piso.pack(side="left", fill="x", expand=True, padx=(0, 3))
    btn_edificio = tk.Button(fr_carril, text="🏢  Varios pisos",
                             cursor="hand2", font=("Segoe UI", 9, "bold"),
                             pady=5)
    btn_edificio.pack(side="left", fill="x", expand=True)
    lbl_carril = tk.Label(p1, text="Elige cómo vas a trabajar antes de "
                                   "cargar los planos.",
                          font=("Segoe UI", 7), fg="#64748b", wraplength=270,
                          justify="left")
    lbl_carril.grid(row=13, column=0, columnspan=2, sticky="w")
    lbl_edificio = tk.Label(p1, text="", font=("Segoe UI", 7), fg="#1a7f37")
    lbl_edificio.grid(row=14, column=0, columnspan=2, sticky="w")
    btn_analizar = tk.Button(p1, text="🔍  ANALIZAR PLANO",
                             font=("Segoe UI", 11, "bold"), cursor="hand2",
                             pady=6)
    btn_analizar.grid(row=14, column=0, columnspan=2, sticky="we", pady=(8, 0))
    p1.columnconfigure(0, weight=1)

    p2 = tk.LabelFrame(izq, text="  2 · Decisiones  ",
                       font=("Segoe UI", 10, "bold"), bd=1, relief="solid",
                       padx=10, pady=10)
    p2.pack(fill="x", pady=(0, 8))

    # ── EN MULTIPISOS NO SE DECIDE NADA A MANO (v66) ──────────────────────
    # Willy: «eso ya se toma de los planos, aquí no nos conviene, nos
    # complica; si es así sácalo». Tenía razón y era la raíz: lo que hubiera
    # en esas casillas GANABA sobre lo medido (`_medida_decidida`), y se
    # rellenaban solas al analizar. Imposible ganarle esa carrera.
    #
    # En multipisos el panel entero se oculta y en su sitio queda un recuadro
    # que solo MUESTRA lo que ORA midió y de dónde salió. En un piso todo
    # sigue exactamente igual: ese carril está probado y no se toca.
    p2_lectura = tk.LabelFrame(izq, text="  2 · Medido en el plano  ",
                               font=("Segoe UI", 9, "bold"))
    lbl_medido = tk.Label(p2_lectura, justify="left", anchor="w",
                          font=("Segoe UI", 9), wraplength=280,
                          text="Carga las plantas y su corte.")
    lbl_medido.pack(fill="x", padx=8, pady=(4, 6))

    def _pintar_medido(resumen=None, npt=None):
        """Enseña lo medido para la planta activa. No se puede editar."""
        sug = ((resumen or getattr(motor, "resumen", None) or {})
               .get("sugerencias_corte") or {})
        _f = ((resumen or getattr(motor, "resumen", None) or {})
              .get("medido_en_el_corte") or {})
        if not sug:
            lbl_medido.configure(
                text="Todavía no he podido medir el corte de esta planta.\n"
                     "Elige el DXF de cortes en la ventana de plantas.")
            return
        _l = []
        if npt is None:
            npt = _f.get("npt")
        if npt is not None:
            _l.append(f"Planta NPT {float(npt):+.2f}")
        for _c, _et in (("altura_muro", "Altura de muros"),
                        ("espesor_losa", "Espesor de losa"),
                        ("relleno_piso", "Relleno del piso"),
                        ("viga_total", "Peralte de viga")):
            _d = sug.get(_c)
            if not _d:
                continue
            _v = _d.get("veces")
            _l.append(f"{_et}:  {float(_d['valor']):.2f} m"
                      + (f"   ({_v})" if _v else ""))
        _l.append("")
        _l.append("Todo medido del corte. Si algo no cuadra, corrige la cota "
                  "en el DXF: ORA la lee de ahí.")
        lbl_medido.configure(text="\n".join(_l))
    # LOS CAMPOS NACEN VACÍOS (v61). Willy: «esos 2.60 y 0.20 aparecen por
    # defecto en ORA; no deberían aparecer — ORA al analizar debe indicar esos
    # datos porque ya leyó todos los planos».
    #
    # Y los lee: en su corte, la altura libre sale 16 veces (2.40) y el
    # espesor de losa 36 veces (0.20). El 2.60 de fábrica no era del proyecto
    # y mandaba sobre el plano sin que nadie lo hubiera escrito. Ahora se
    # rellenan al ANALIZAR, con su origen a la vista; si el plano no lo dice,
    # se quedan vacíos y ORA lo pregunta en vez de suponerlo.
    var_altura = tk.StringVar(value="")
    var_losa = tk.StringVar(value="")

    def _medida_decidida(var, clave, respaldo):
        """Lo que el usuario escribió; si está vacío, lo que dice el plano.

        Los campos nacen vacíos a propósito (v61). Si el usuario no escribió
        nada y el corte tampoco lo dice, se usa el respaldo y se avisa: nunca
        se cuela un número de fábrica sin que se sepa de dónde salió.
        """
        sug = ((motor.resumen or {}).get("sugerencias_corte") or {}).get(clave)
        # EN MULTIPISOS MANDA EL PLANO (v66). El campo de «2 · Decisiones» ya
        # no existe en ese carril: lo que hubiera ahí pisaba lo medido y era
        # la raíz de que una planta se levantara con la altura de otra.
        if nivel_activo.get("modo") == "edificio":
            if sug:
                return float(sug["valor"])
            return float(respaldo)
        txt = str(var.get() or "").replace(",", ".").strip()
        if txt:
            try:
                return float(txt)
            except ValueError:
                pass
        if sug:
            return float(sug["valor"])
        return float(respaldo)

    var_carp = tk.BooleanVar(value=False)

    tk.Label(p2, text="Altura de muros (m)", font=("Segoe UI", 9)).grid(
        row=0, column=0, sticky="w")
    tk.Entry(p2, textvariable=var_altura, width=8).grid(row=0, column=1, sticky="e")
    tk.Label(p2, text="Espesor losa/techo (m, 0 = sin techo)",
             font=("Segoe UI", 9)).grid(row=1, column=0, sticky="w")
    tk.Entry(p2, textvariable=var_losa, width=8).grid(row=1, column=1, sticky="e")
    chk_carp = tk.Checkbutton(p2, text="Carpintería en vanos",
                              variable=var_carp, font=("Segoe UI", 9))
    chk_carp.grid(row=2, column=0, columnspan=2, sticky="w")
    # FASE C: desde dónde se mide la altura de cada muro
    tk.Label(p2, text="La altura del muro se mide desde:",
             font=("Segoe UI", 9)).grid(row=3, column=0, columnspan=2,
                                        sticky="w", pady=(6, 0))
    var_altura_desde = tk.StringVar(value="NPT de cada ambiente")
    ttk.Combobox(p2, textvariable=var_altura_desde, state="readonly", width=24,
                 values=["NPT de cada ambiente", "Piso general (techo parejo)"]
                 ).grid(row=4, column=0, columnspan=2, sticky="we")
    tk.Label(p2, text="NPT de cada ambiente = altura libre real (techo escalonado)",
             font=("Segoe UI", 7)).grid(row=5, column=0, columnspan=2, sticky="w")
    p2.columnconfigure(0, weight=1)

    # escalera (aparece si se detecta)
    p_esc = tk.LabelFrame(izq, text="  Escalera detectada  ",
                          font=("Segoe UI", 10, "bold"), bd=1, relief="solid",
                          padx=10, pady=8)
    var_esc = tk.BooleanVar(value=False)
    var_esc_tipo = tk.StringVar(value="RECTA")
    var_esc_pasos = tk.StringVar(value="16")
    var_esc_ancho = tk.StringVar(value="1.00")
    var_esc_desc = tk.BooleanVar(value=False)
    var_esc_lado = tk.StringVar(value="IZQUIERDA")
    chk_esc = tk.Checkbutton(p_esc, text="Generar escalera", variable=var_esc,
                             font=("Segoe UI", 9, "bold"))
    chk_esc.grid(row=0, column=0, columnspan=2, sticky="w")
    tk.Label(p_esc, text="Tipo", font=("Segoe UI", 9)).grid(row=1, column=0, sticky="w")
    ttk.Combobox(p_esc, textvariable=var_esc_tipo, width=8, state="readonly",
                 values=["RECTA", "L", "U"]).grid(row=1, column=1, sticky="e")
    tk.Label(p_esc, text="Contrahuellas al piso sup.",
             font=("Segoe UI", 9)).grid(row=2, column=0, sticky="w")
    tk.Entry(p_esc, textvariable=var_esc_pasos, width=8).grid(row=2, column=1, sticky="e")
    tk.Label(p_esc, text="Ancho (m)", font=("Segoe UI", 9)).grid(row=3, column=0, sticky="w")
    tk.Entry(p_esc, textvariable=var_esc_ancho, width=8).grid(row=3, column=1, sticky="e")
    tk.Checkbutton(p_esc, text="Descanso al medio", variable=var_esc_desc,
                   font=("Segoe UI", 9)).grid(row=4, column=0, sticky="w")
    ttk.Combobox(p_esc, textvariable=var_esc_lado, width=10, state="readonly",
                 values=["IZQUIERDA", "DERECHA"]).grid(row=4, column=1, sticky="e")
    # FASE E, punto 11: los dos tramos pueden tener distinta cantidad de pasos
    tk.Label(p_esc, text="Contrahuellas DESPUÉS del descanso",
             font=("Segoe UI", 9)).grid(row=5, column=0, sticky="w")
    var_esc_pasos2 = tk.StringVar(value="0")
    tk.Entry(p_esc, textvariable=var_esc_pasos2, width=8).grid(row=5, column=1, sticky="e")
    tk.Label(p_esc, text="0 = repartir el total mitad y mitad",
             font=("Segoe UI", 7)).grid(row=6, column=0, columnspan=2, sticky="w")
    p_esc.columnconfigure(0, weight=1)

    # cuadro de vanos manual (aparece si hay bloques sin medidas)
    p_cv = tk.LabelFrame(izq, text="  Vanos sin medidas (confirma una vez)  ",
                         font=("Segoe UI", 10, "bold"), bd=1, relief="solid",
                         padx=8, pady=6)
    filas_cv = []  # (bloque, var_tipo, var_cod, var_an, var_al, var_alf)

    # ---------- 3 · FASES (Fase B, punto 4): revisar por partes ----------
    # CAMBIO (sesión de calibración post-v21, decisión de Willy): Muros+Pisos
    # se confirma y CONGELA primero, como unidad definitiva e intocable.
    # Vanos pasa a ser un paso propio DESPUÉS. Antes, muros+vanos+pisos se
    # generaban y congelaban juntos en un solo paso: si el muro cambiaba de
    # medida y el hueco se cortaba en la misma pasada, el corte terminaba
    # relativo a una Z que todavía podía moverse. Ahora el muro queda 100%
    # definitivo (congelado) ANTES de tocarle un hueco — el paso de Vanos
    # siempre corta contra la Z ya confirmada, nunca contra una que cambie
    # después. Pisos se queda junto a Muros: el muro arranca desde el NPT de
    # su piso, y verlos por separado escondía si el escalonado calzaba.
    # Mobiliario queda FUERA a propósito (se mete cuando todo lo demás esté
    # estable).
    # Vigas va DESPUÉS de Techo: la cara superior de la viga se enrasa con la
    # losa, así que primero hay que tener la losa confirmada.
    # Imágenes que Willy adjunta a mano a la evidencia, por plano.
    evidencia_extra = {}
    FASES = [("muros_pisos", "🧱🟫 Muros + Pisos"),
             ("vanos", "🚪 Vanos"),
             ("columnas", "🏛️ Columnas"), ("techo", "🟦 Techo/Losa"),
             ("vigas", "🏗️ Vigas"),
             ("escalera", "🪜 Escalera")]
    _ETIQ_PASO = {c: e for c, e in FASES}

    def _olvidar_todo_de_verdad(limpiar_todo):
        """Borra TODO lo que ORA recuerda, no solo una parte.

        Antes «Olvidar todo» vaciaba `memoria_elementos.json` y nada más. La
        lista de plantas del edificio vive en otro archivo, así que Willy la
        borraba, cerraba ORA, volvía a abrir… y los planos seguían cargados.
        Un botón que dice «todo» tiene que borrar todo.
        """
        n = limpiar_todo()
        estado["edificio"] = []
        _guardar_edificio_en_disco([])
        refrescar_etiqueta_edificio()
        try:
            import evidencia as _ev
            _ev.limpiar_cache()
        except Exception:
            pass
        return n

    def _repeticiones_de(nivel):
        """Los niveles que son COPIA de una típica ya levantada.

        La tabla de ensamble ya marca cada fila con `repetido`: el nivel 2 es
        el dibujo y el 3, 4 y 5 son el mismo dibujo a otra cota. No hay nada
        que revisar cuatro veces.
        """
        return [f.get("nivel") for f in (edificio.get("tabla") or [])
                if f.get("repetido") and f.get("nivel") is not None]

    def _siguiente_nivel():
        """El nivel que toca después del actual, o None si era el último.

        SE SALTAN LAS COPIAS DE LA TÍPICA (v56). Willy lo dijo con todas las
        letras: «si ya marqué que la planta 2 es típica, ¿por qué me manda al
        piso 3 a volver a levantarlo?». Antes esto cogía sin más la siguiente
        fila y le hacía recorrer 3, 4 y 5 uno por uno, revisando cuatro veces
        el mismo dibujo — con la ocasión de equivocarse cuatro veces.
        """
        if nivel_activo.get("modo") != "edificio":
            return None
        tabla = edificio.get("tabla") or []
        act = nivel_activo.get("piso") or 0
        copias = set(_repeticiones_de(act))
        sig = next((f for f in tabla
                    if (f.get("nivel") or 0) > act
                    and f.get("nivel") not in copias), None)
        if not sig:
            return None
        _cl = str(sig.get("clase") or "").lower()
        etiq = {"azotea": "Azotea", "sotano": "Sótano",
                "semisotano": "Semisótano"}.get(_cl)
        if not etiq:
            etiq = (f"Piso {sig['nivel']} (típica)" if _cl == "tipica"
                    else f"Piso {sig['nivel']}")
        return {"nivel": sig["nivel"], "etiqueta": etiq}

    def _rotulo_progreso(i, total):
        """«Piso 1 · Paso 3 de 6», para saber SIEMPRE qué se está avanzando.

        Antes decía solo «Paso 3 de 6» y en un edificio de seis niveles no
        había forma de saber de qué planta se hablaba. La cadena es: se
        terminan los seis pasos de un piso, y recién entonces se pasa al
        siguiente.
        """
        base = f"Paso {i} de {total}"
        if nivel_activo.get("modo") != "edificio":
            return base
        n = nivel_activo.get("piso") or 0
        cuantos = len(edificio.get("tabla") or [])
        return (f"Piso {n}" + (f" de {cuantos}" if cuantos else "")
                + f"  ·  {base}")
    CATEGORIAS_DE_FASE = {"muros_pisos": ["muros", "pisos"],
                          # 'vanos' arrastra 'muros' (DEPENDENCIAS en
                          # exportar_sketchup.py): para cortar el hueco hay
                          # que regenerar el grupo del muro, pero ahora se
                          # regenera con su medida YA CONGELADA del paso
                          # anterior, no con la del DXF.
                          "vanos": ["muros", "vanos"],
                          "columnas": ["columnas"], "techo": ["techo"],
                          "vigas": ["vigas"],
                          "escalera": ["escalera"]}
    AYUDA_FASE = {
        "muros_pisos": "Revisa los muros MACIZOS (todavía sin puertas/ventanas "
                       "cortadas) y cada piso a su NPT real (de ahí arranca cada "
                       "muro). Al confirmar quedan fijos: el paso de Vanos va a "
                       "cortar los huecos sobre esta medida ya definitiva.",
        "vanos": "Se cortan las puertas y ventanas sobre los muros ya "
                 "confirmados en el paso anterior. Si un muro no calzaba bien, "
                 "vuelve al paso anterior antes de continuar — de aquí en "
                 "adelante el corte usa esa medida como definitiva.",
        "columnas": "Revisa las columnas.",
        "techo": "Revisa la losa y los huecos de patio.",
        "vigas": "Revisa el peralte de cada viga y a qué altura queda su cara "
                 "superior. Las que no traigan peralte en el plano quedan sin "
                 "levantar hasta que lo escribas: ORA no lo inventa.",
        "escalera": "Revisa que suba en el sentido correcto y llegue al piso de arriba.",
    }
    # ------------------------------------------------------------------
    # 3 · ASISTENTE GUIADO — un paso a la vez, sin poder saltarse ninguno.
    # ------------------------------------------------------------------
    p_fases = tk.LabelFrame(izq, text="  3 · Asistente guiado  ",
                            font=("Segoe UI", 10, "bold"), bd=1, relief="solid",
                            padx=10, pady=8)
    p_fases.pack(fill="x", pady=(0, 8))
    estado_fases = {clave: False for clave, _ in FASES}
    paso_actual = {"i": 0, "enviado": False}
    # Sub-estado del paso de Vanos: primero se muestra la PREVIA (cajas
    # translúcidas al lado del muro, sin perforar nada) para revisar dónde va
    # a caer cada hueco y moverlo si hace falta; recién después se corta.
    previa_vanos = {"mostrada": False, "aprobada": False}
    previa_vigas = {"mostrada": False, "aprobada": False}
    previa_base = {}   # posicion original de cada caja de previa
    var_rapido = tk.BooleanVar(value=False)

    # DÓNDE ESTOY (v55). Pedido de Willy: «si estoy haciendo sótano, tiene
    # que aparecer SÓTANO, grande, en todo momento y en todos los pasos».
    # El rótulo pequeño de progreso decía «Piso -1 de 7» en cuerpo 8 y se
    # perdía entre el resto del panel: en un edificio de siete niveles, con
    # seis pasos cada uno, hay que saber siempre en qué planta se está
    # trabajando sin buscarlo.
    fr_nivel = tk.Frame(p_fases, bg="#1e6fd9")
    lbl_nivel = tk.Label(fr_nivel, text="", font=("Segoe UI", 14, "bold"),
                         bg="#1e6fd9", fg="white", anchor="w", padx=10, pady=5)
    lbl_nivel.pack(fill="x")
    lbl_nivel_sub = tk.Label(fr_nivel, text="", font=("Segoe UI", 8),
                             bg="#1e6fd9", fg="#d6e6ff", anchor="w",
                             padx=10, pady=(0))
    lbl_nivel_sub.pack(fill="x", pady=(0, 4))

    def _pintar_nivel_grande():
        """El cartel del nivel. En un plano suelto no estorba: se esconde."""
        if nivel_activo.get("modo") != "edificio":
            fr_nivel.pack_forget()
            return
        n = nivel_activo.get("piso")
        fila = None
        for f in (edificio.get("tabla") or []):
            if f.get("nivel") == n:
                fila = f
                break
        etq = (fila or {}).get("nombre") or ""
        if not etq:
            _cl = str((fila or {}).get("clase") or "").lower()
            etq = {"sotano": "SÓTANO", "semisotano": "SEMISÓTANO",
                   "cisterna": "CISTERNA", "azotea": "AZOTEA"}.get(
                       _cl, f"PISO {n}" if n is not None else "PLANTA")
        etq = str(etq).upper()
        if n is not None and n < 0 and "SÓTANO" not in etq and "CISTERNA" not in etq:
            etq = f"SÓTANO {abs(n)} · {etq}"
        lbl_nivel.configure(text=f"📍  {etq}")
        # Se cuentan las plantas QUE HAY QUE REVISAR, no los niveles del
        # edificio: una típica del 2 al 5 es una sola revisión, no cuatro.
        _revisables = [f for f in (edificio.get("tabla") or [])
                       if not f.get("repetido")]
        cuantos = len(_revisables)
        _cual = next((i + 1 for i, f in enumerate(_revisables)
                      if f.get("nivel") == n), None)
        npt = (fila or {}).get("npt")
        _sub = (f"planta {_cual} de {cuantos}" if _cual and cuantos
                else f"nivel {n}")
        _rep = [f.get("nivel") for f in (edificio.get("tabla") or [])
                if f.get("repetido")]
        if (fila or {}).get("clase") == "tipica" and _rep:
            _sub += f"   ·   se repite en {', '.join(str(x) for x in _rep)}"
        if npt is not None:
            _sub += f"   ·   NPT {float(npt):+.2f} m"
        lbl_nivel_sub.configure(text=_sub)
        fr_nivel.pack(fill="x", pady=(0, 6), before=lbl_progreso)

    lbl_progreso = tk.Label(p_fases, text="", font=("Segoe UI", 8))
    lbl_progreso.pack(anchor="w")
    lbl_paso = tk.Label(p_fases, text="", font=("Segoe UI", 11, "bold"),
                        anchor="w", justify="left")
    lbl_paso.pack(anchor="w", pady=(2, 0))
    lbl_ayuda = tk.Label(p_fases, text="", font=("Segoe UI", 8), anchor="w",
                         justify="left", wraplength=265)
    lbl_ayuda.pack(anchor="w", pady=(0, 6))

    # Sub-panel propio de la escalera (solo aparece en su paso)
    fr_esc_paso = tk.Frame(p_fases)
    tk.Label(fr_esc_paso, text="Contrahuella (m):", font=("Segoe UI", 9)
             ).grid(row=0, column=0, sticky="w")
    var_contrahuella = tk.StringVar(value="0.15")
    tk.Entry(fr_esc_paso, textvariable=var_contrahuella, width=9
             ).grid(row=0, column=1, sticky="e")

    def _calcular_contrahuella(silencioso=False):
        """Contrahuella EXACTA = altura a salvar ÷ número de contrahuellas.

        Es como se hace en obra: la escalera tiene que llegar clavada al piso
        de arriba, así que la contrahuella casi nunca es un número redondo
        (0.1647, 0.175, 0.17323…). Antes había que calcularla aparte y
        escribirla a mano, y cualquier redondeo dejaba la escalera corta o
        pasada.

        Número de CONTRAHUELLAS = pasos dibujados + 1: el último tramo vertical
        es el que apoya en la losa de arriba, y no tiene huella dibujada.
        """
        esc = (motor.resumen or {}).get("escalera") or {}
        n = int(esc.get("pasos") or 0)
        if not n:
            if not silencioso:
                log("Todavía no hay peldaños detectados: analiza el plano "
                    "primero.", "warn")
            return None
        try:
            h_muro = _medida_decidida(var_altura, "altura_muro", 2.60)
            e_losa = _medida_decidida(var_losa, "espesor_losa", 0.20)
        except ValueError:
            if not silencioso:
                log("Revisa la altura de muro y el espesor de losa.", "warn")
            return None
        # El NPT que MANDA: lo que escribió el usuario; si no, lo leído del
        # plano. Nunca un 0.0 de relleno: si no hay dato, se dice y se para.
        _arr = esc.get("arranque") or {}
        _escrito = _num_o(var_esc_npt, None)
        npt = _escrito if _escrito is not None else _arr.get("npt")
        if npt is None:
            if not silencioso:
                log("No se sabe de qué NPT arranca la escalera: escríbelo en "
                    "«NPT donde arranca» y vuelve a calcular.", "warn")
            return None
        npt = float(npt)
        # Altura a salvar: del NPT de arranque hasta el piso terminado de
        # arriba (altura libre del muro + el canto de la losa).
        subida = h_muro + e_losa - npt
        ch = subida / (n + 1)
        var_contrahuella.set(f"{ch:.4f}")
        log(f"📐 Contrahuella = {subida:.4f} m ÷ {n + 1} contrahuellas "
            f"= {ch:.4f} m (arranca en NPT {npt:+.2f}). "
            f"{n} peldaños dibujados + el último a la losa.", "ok")
        return ch

    tk.Button(fr_esc_paso, text="📐 Calcular exacta (llega justo arriba)",
              font=("Segoe UI", 8), cursor="hand2",
              command=_calcular_contrahuella
              ).grid(row=1, column=0, columnspan=2, sticky="we", pady=(2, 0))
    # ---- DE DÓNDE ARRANCA LA ESCALERA -------------------------------
    # SIEMPRE visible, ANTES de generar. Antes este panel solo salía cuando
    # el plano no traía ambientes, y el campo venía con "0.00" escrito de
    # fábrica: ese 0.00 se mandaba siempre y PISABA el NPT leído del plano.
    # Resultado: el análisis detectaba "SALA, NPT +0.15" y la escalera se
    # levantaba igual desde 0.000, sin que nadie lo notara.
    # Ahora el campo arranca VACÍO: vacío = usa lo del plano.
    fr_esc_contexto = tk.Frame(fr_esc_paso)
    lbl_esc_origen = tk.Label(fr_esc_contexto, text="", justify="left",
                              wraplength=260, font=("Segoe UI", 8, "bold"))
    lbl_esc_origen.grid(row=0, column=0, columnspan=2, sticky="w")
    tk.Label(fr_esc_contexto, text="NPT donde arranca (m):",
             font=("Segoe UI", 8)).grid(row=1, column=0, sticky="w")
    var_esc_npt = tk.StringVar(value="")
    ent_esc_npt = tk.Entry(fr_esc_contexto, textvariable=var_esc_npt, width=8)
    ent_esc_npt.grid(row=1, column=1, sticky="e")
    tk.Label(fr_esc_contexto, text="Piso de arriba llega a (m):",
             font=("Segoe UI", 8)).grid(row=2, column=0, sticky="w")
    var_esc_llegada = tk.StringVar(value="")
    tk.Entry(fr_esc_contexto, textvariable=var_esc_llegada, width=8
             ).grid(row=2, column=1, sticky="e")
    tk.Label(fr_esc_contexto, font=("Segoe UI", 7), justify="left",
             wraplength=250,
             text="Déjalos vacíos para usar lo que dice el plano. La "
                  "contrahuella sale de (llegada − arranque) entre el número "
                  "de peldaños + 1."
             ).grid(row=3, column=0, columnspan=2, sticky="w")
    fr_esc_contexto.columnconfigure(1, weight=1)

    # v29: el panel de "tipo constructivo / losa inclinada / peldaños macizos /
    # acabado" se ELIMINÓ junto con la geometría fina de escalera. ORA levanta
    # un solo volumen por escalera; el detalle lo hacen mejor los plugins de
    # SketchUp. Los números de metrado (garganta, Hm) se siguen reportando en
    # los avisos.

    var_invertir = tk.BooleanVar(value=False)
    tk.Checkbutton(fr_esc_paso, text="↕ Invertir sentido de subida",
                   variable=var_invertir, font=("Segoe UI", 8)
                   ).grid(row=4, column=0, columnspan=2, sticky="w")
    lbl_esc_info = tk.Label(fr_esc_paso, text="", font=("Segoe UI", 7),
                            justify="left", wraplength=260)
    lbl_esc_info.grid(row=5, column=0, columnspan=2, sticky="w")
    fr_esc_paso.columnconfigure(1, weight=1)

    # ---- AVISOS ACCIONABLES DEL PASO ----------------------------------
    # Antes ORA te decía "PS-1 mide 3.25 en el dibujo y 3.00 en el cuadro"
    # en el informe de análisis, y ahí moría: te informaba y te dejaba solo.
    # Un aviso que no puedes resolver donde lo lees no sirve de nada. Ahora
    # cada aviso aparece DENTRO de su paso, con su botón para resolverlo,
    # antes de mandar nada a SketchUp.
    # Pasos que el asistente saltó por no haber nada de esa categoría, con
    # su botón para mostrarlos igual (bloque 4).
    fr_saltados = tk.Frame(p_fases)
    fr_avisos = tk.Frame(p_fases)
    lbl_avisos_tit = tk.Label(fr_avisos, text="", font=("Segoe UI", 9, "bold"),
                              anchor="w", justify="left", fg="#b45309")
    lbl_avisos_tit.pack(anchor="w")
    fr_avisos_lista = tk.Frame(fr_avisos)
    fr_avisos_lista.pack(fill="x")

    # ---- PREVIA DE VANOS ----------------------------------------------
    fr_previa = tk.Frame(p_fases)
    tk.Label(fr_previa, text="👁️ Previa en SketchUp (cajas naranjas)",
             font=("Segoe UI", 9, "bold"), anchor="w").pack(anchor="w")
    tk.Label(fr_previa, wraplength=265, justify="left", font=("Segoe UI", 8),
             text="Todavía no se perforó ningún muro. Si una caja no cae donde "
                  "va el hueco, muévela en SketchUp y pulsa «Aprender "
                  "posiciones». Cuando estén todas bien, corta."
             ).pack(anchor="w", pady=(0, 4))
    btn_aprender_previa = tk.Button(fr_previa, text="📌 Aprender posiciones que moví",
                                    font=("Segoe UI", 8), cursor="hand2")
    btn_aprender_previa.pack(fill="x", pady=1)
    btn_cortar_vanos = tk.Button(fr_previa, text="✂️ Cortar vanos (ahora sí perfora)",
                                 font=("Segoe UI", 9, "bold"), cursor="hand2")
    btn_cortar_vanos.pack(fill="x", pady=1)

    # PREVIA DE VIGAS — mismo criterio que la de vanos: primero se ven
    # ENTERAS y sin recortar, para revisar peralte y posición; recién después
    # se aplica el recorte con muros y losa. Antes el recorte se hacía de una
    # y no había forma de comprobar nada.
    fr_previa_vg = tk.Frame(p_fases)
    tk.Label(fr_previa_vg, text="👁️ Previa de vigas (sin recortar)",
             font=("Segoe UI", 9, "bold"), anchor="w").pack(anchor="w")
    tk.Label(fr_previa_vg, wraplength=265, justify="left", font=("Segoe UI", 8),
             text="Las vigas están ENTERAS, con su peralte completo. Revisa "
                  "que cada una esté donde va y con el peralte correcto. Si "
                  "alguna está mal, corrígela en la tabla o muévela en "
                  "SketchUp. Cuando estén bien, recorta."
             ).pack(anchor="w", pady=(0, 4))
    btn_aprender_previa_vg = tk.Button(
        fr_previa_vg, text="📌 Aprender posiciones que moví",
        font=("Segoe UI", 8), cursor="hand2")
    btn_aprender_previa_vg.pack(fill="x", pady=1)
    btn_recortar_vigas = tk.Button(
        fr_previa_vg, text="✂️ Recortar vigas (muros y losa como molde)",
        font=("Segoe UI", 9, "bold"), cursor="hand2")
    btn_recortar_vigas.pack(fill="x", pady=1)

    # ---- PERALTE EN LOTE ----
    # Willy: «usualmente son la misma medida en peralte; tiene que darme la
    # opción de la lista de vigas para aplicarlas a todas, y no pasar uno por
    # uno». Con 20 vigas, responder 20 avisos idénticos es perder la tarde.
    fr_lote_vg = tk.LabelFrame(p_fases, text="  📏 Peralte en lote  ",
                               font=("Segoe UI", 9, "bold"))
    tk.Label(fr_lote_vg, font=("Segoe UI", 8), justify="left", wraplength=280,
             text="Marca las que compartan peralte, escribe la medida una "
                  "sola vez y se aplica a todas. Doble clic en una para ver "
                  "dónde cae."
             ).pack(anchor="w", padx=4)
    _cnv_vg = tk.Canvas(fr_lote_vg, height=150, highlightthickness=0)
    _scr_vg = ttk.Scrollbar(fr_lote_vg, orient="vertical",
                            command=_cnv_vg.yview)
    lista_vigas = tk.Frame(_cnv_vg)
    lista_vigas.bind("<Configure>",
                     lambda e: _cnv_vg.configure(
                         scrollregion=_cnv_vg.bbox("all")))
    _cnv_vg.create_window((0, 0), window=lista_vigas, anchor="nw")
    _cnv_vg.configure(yscrollcommand=_scr_vg.set)
    _cnv_vg.pack(side="left", fill="both", expand=True, padx=(4, 0))
    _scr_vg.pack(side="right", fill="y")
    marcas_vigas = {}
    fr_aplicar_vg = tk.Frame(p_fases)
    var_peralte_lote = tk.StringVar()
    tk.Label(fr_aplicar_vg, text="Peralte (m):", font=("Segoe UI", 8)
             ).pack(side="left", padx=(4, 2))
    tk.Entry(fr_aplicar_vg, textvariable=var_peralte_lote, width=8,
             justify="center").pack(side="left")
    btn_peralte_lote = tk.Button(fr_aplicar_vg,
                                 text="✔ Aplicar a las marcadas",
                                 font=("Segoe UI", 8, "bold"), cursor="hand2")
    btn_peralte_lote.pack(side="left", padx=6)
    btn_marcar_todas = tk.Button(fr_aplicar_vg, text="Marcar todas",
                                 font=("Segoe UI", 8), cursor="hand2")
    btn_marcar_todas.pack(side="left")

    btn_enviar_paso = tk.Button(p_fases, text="", font=("Segoe UI", 10, "bold"),
                                cursor="hand2", pady=4)
    btn_enviar_paso.pack(fill="x", pady=(2, 4))

    fr_confirmar = tk.Frame(p_fases)
    btn_confirmar = tk.Button(fr_confirmar, text="✅ Confirmar y guardar",
                              font=("Segoe UI", 9, "bold"), cursor="hand2")
    btn_confirmar.pack(fill="x", pady=1)
    btn_reintentar = tk.Button(fr_confirmar, text="↺ Reintentar (ajustar y reenviar)",
                               font=("Segoe UI", 8), cursor="hand2")
    btn_reintentar.pack(fill="x", pady=1)
    btn_descartar = tk.Button(fr_confirmar, text="❌ Me quedo con mi versión de SketchUp",
                              font=("Segoe UI", 8), cursor="hand2")
    btn_descartar.pack(fill="x", pady=1)

    fr_atras = tk.Frame(p_fases)
    fr_atras.pack(fill="x")
    btn_atras = tk.Button(fr_atras, text="← Paso anterior", font=("Segoe UI", 8),
                          cursor="hand2")
    btn_atras.pack(side="left")
    tk.Checkbutton(fr_atras, text="Modo rápido", variable=var_rapido,
                   font=("Segoe UI", 8),
                   command=lambda: refrescar_fases()).pack(side="right")

    # ---------- Ficha del elemento SELECCIONADO en SketchUp (tiempo real) ----------
    p_sel = tk.LabelFrame(izq, text="  🔎 Seleccionado en SketchUp  ",
                          font=("Segoe UI", 10, "bold"), bd=1, relief="solid",
                          padx=10, pady=6)
    p_sel.pack(fill="x", pady=(0, 8))
    var_ficha = tk.StringVar(value="Selecciona un muro en SketchUp y aquí verás\n"
                                   "exactamente qué es y qué estás modificando.")
    lbl_ficha = tk.Label(p_sel, textvariable=var_ficha, justify="left", anchor="w",
                         font=("Segoe UI", 8), wraplength=280)
    lbl_ficha.pack(fill="x")

    # ---- Editar el elemento seleccionado, desde ORA ----
    fr_edit = tk.Frame(p_sel)
    fr_edit.pack(fill="x", pady=(6, 0))
    tk.Label(fr_edit, text="Alto (m):", font=("Segoe UI", 8)).grid(row=0, column=0, sticky="w")
    var_ed_alto = tk.StringVar()
    tk.Entry(fr_edit, textvariable=var_ed_alto, width=7).grid(row=0, column=1, sticky="w")
    tk.Label(fr_edit, text="Subir/bajar Z (m):", font=("Segoe UI", 8)
             ).grid(row=1, column=0, sticky="w")
    var_ed_z = tk.StringVar(value="0")
    tk.Entry(fr_edit, textvariable=var_ed_z, width=7).grid(row=1, column=1, sticky="w")
    tk.Label(fr_edit, text="Mover X / Y (m):", font=("Segoe UI", 8)
             ).grid(row=2, column=0, sticky="w")
    fr_xy = tk.Frame(fr_edit)
    fr_xy.grid(row=2, column=1, sticky="w")
    var_ed_x = tk.StringVar(value="0")
    var_ed_y = tk.StringVar(value="0")
    tk.Entry(fr_xy, textvariable=var_ed_x, width=5).pack(side="left")
    tk.Entry(fr_xy, textvariable=var_ed_y, width=5).pack(side="left", padx=(2, 0))
    # --- v27: campos que faltaban para editar VARIOS elementos de una vez ---
    # Antes solo se podía cambiar alto y mover en X/Y/Z. Estos tres se aplican
    # igual al lote seleccionado, sin repetir la operación uno por uno.
    tk.Label(fr_edit, text="NPT / cota base (m):", font=("Segoe UI", 8)
             ).grid(row=3, column=0, sticky="w")
    var_ed_npt = tk.StringVar()
    tk.Entry(fr_edit, textvariable=var_ed_npt, width=7).grid(row=3, column=1, sticky="w")
    tk.Label(fr_edit, text="Rotar (grados):", font=("Segoe UI", 8)
             ).grid(row=4, column=0, sticky="w")
    var_ed_rot = tk.StringVar(value="0")
    tk.Entry(fr_edit, textvariable=var_ed_rot, width=7).grid(row=4, column=1, sticky="w")
    tk.Label(fr_edit, text="Material:", font=("Segoe UI", 8)
             ).grid(row=5, column=0, sticky="w")
    var_ed_mat = tk.StringVar(value="")
    MATERIALES_ORA = ["", "blanco", "gris", "concreto", "ladrillo", "madera",
                      "vidrio", "aluminio", "ceramico", "porcelanato",
                      "adoquin", "jardin", "negro"]
    ttk.Combobox(fr_edit, textvariable=var_ed_mat, values=MATERIALES_ORA,
                 width=12, state="readonly").grid(row=5, column=1, sticky="w")
    btn_aplicar_edit = tk.Button(fr_edit, text="✔ Aplicar en SketchUp",
                                 font=("Segoe UI", 8, "bold"), cursor="hand2")
    btn_aplicar_edit.grid(row=6, column=0, columnspan=2, sticky="we", pady=(4, 0))
    tk.Label(fr_edit, text="Z, X, Y y Rotar son desplazamientos (+ / −). "
                           "Alto y NPT son la medida final. Todo se aplica a "
                           "TODOS los elementos seleccionados.",
             font=("Segoe UI", 7), wraplength=260, justify="left"
             ).grid(row=7, column=0, columnspan=2, sticky="w")
    fr_edit.columnconfigure(1, weight=1)

    p3 = tk.Frame(izq)
    p3.pack(fill="x", side="bottom", pady=(8, 0))
    p3.pack_propagate(True)
    btn_vivo = tk.Button(p3, text="🔴  APLICAR EN VIVO (SketchUp abierto)",
                         font=("Segoe UI", 10, "bold"), bg="#b91c1c", fg="white",
                         cursor="hand2", command=lambda: aplicar_en_vivo(),
                         # Sin plano analizado no hay nada que aplicar: el
                         # botón se ve APAGADO en vez de dejarte pulsarlo y
                         # devolverte un error. Se enciende solo al terminar
                         # ANALIZAR PLANO.
                         state="disabled")
    btn_vivo.pack(fill="x", pady=(0, 6))
    btn_generar = tk.Button(p3, text="🏗️  GENERAR 3D Y ABRIR SKETCHUP",
                            font=("Segoe UI", 11, "bold"), cursor="hand2",
                            pady=8, state="disabled")
    btn_generar.pack(fill="x")
    btn_split = tk.Button(p3, text="📋 Ver/editar lista de elementos",
                          font=("Segoe UI", 9), cursor="hand2",
                          command=lambda: alternar_modo_split())
    btn_split.pack(fill="x", pady=(6, 0))

    # ---------- panel derecho: informe (modo normal) ----------
    lbl_der = tk.Label(der, text="Informe del análisis",
                       font=("Segoe UI", 11, "bold"))
    lbl_der.pack(anchor="w")
    txt = tk.Text(der, wrap="word", font=("Consolas", 9), bd=1,
                  relief="solid", padx=10, pady=8)
    txt.pack(fill="both", expand=True, pady=(4, 0))

    # ---------- panel derecho: lista de elementos editable (modo split) ----------
    p_elem = tk.Frame(der)
    modo_split = {"activo": False}
    var_piso_sel = tk.StringVar(value="Piso 1")
    fila_elementos = []  # (nombre, level_idx, entrada_ancho, entrada_alto, frame_fila)

    # Tipo de entidad -> categoría de fase (para filtrar la tabla por paso).
    CAT_DE_TIPO_GUI = {"wall": "muros", "column": "columnas", "slab": "techo",
                       "stair": "escalera", "beam": "vigas",
                       "furniture": "mobiliario"}

    # ---------- v88 · UNA SOLA FUENTE PARA LA TABLA (Fase 2) ----------
    # Estas dos funciones son código EXTRAÍDO de `poblar_lista_elementos`,
    # no lógica nueva: el mismo cálculo, movido a un sitio desde donde lo
    # pueden usar los dos que lo necesitan — la ventana de siempre (que lo
    # pinta con widgets) y el puente de la maqueta (que lo manda como JSON).
    #
    # POR QUÉ SE EXTRAE en vez de copiarlo: si el cálculo viviera en dos
    # lados, el día que se corrija una medida en uno de ellos el otro se
    # queda mintiendo, y acabas con la tabla de ORA diciendo una cosa y la
    # de la maqueta otra. Es exactamente el bug «una cosa en dos sitios»
    # que ya costó caro con la altura de los muros. Un dato, un solo lugar.
    def _categoria_de_entidad(e):
        pr_ = e.get("properties") or {}
        sub = pr_.get("subtipo")
        if sub == "mobiliario":
            return "mobiliario"
        if e["type"] in ("door", "window"):
            return "vanos"
        # PISO y TECHO son los dos 'slab' en el kernel, pero son de PASOS
        # DISTINTOS: el piso se revisa en «Muros + Pisos» (paso 1) y el
        # techo en «Techo/Losa» (paso 4).
        if e["type"] == "slab":
            return "pisos" if sub == "piso" else "techo"
        return CAT_DE_TIPO_GUI.get(e["type"], "muros")

    def _medidas_de_entidad(ent, nombre):
        """Ancho / largo / alto de un elemento, tal como se muestran.

        Devuelve también el nombre del grupo de SketchUp al que apunta la
        fila, porque durante la previa un vano vive como caja naranja
        (`ORA_PREVIA_<nombre>`) y el grupo definitivo aún no existe.
        """
        nom_grupo = f"ORA_{nombre}"
        if ent["type"] in ("door", "window"):
            _pv = f"ORA_PREVIA_{nombre}"
            if _pv in estado_vivo or nom_grupo not in estado_vivo:
                nom_grupo = _pv
        vivo = estado_vivo.get(nom_grupo) or {}
        pr = ent.get("properties") or {}
        # ANCHO: el espesor medido del DXF manda, porque no depende de cómo
        # esté orientado el muro. Lo de SketchUp solo si ORA no tiene dato.
        if ent["type"] in ("door", "window") and isinstance(pr.get("ancho"), (int, float)):
            ancho = pr["ancho"]
        elif isinstance(ent.get("thickness"), (int, float)) and ent["thickness"]:
            ancho = ent["thickness"]
        else:
            ancho = vivo.get("ancho")
        # LARGO y ALTO: la medida real de SketchUp; si aún no llegó, la del plano.
        largo = vivo.get("largo")
        if largo is None:
            pts = (ent.get("geometry") or {}).get("outer") or []
            if pts:
                xs = [q[0] for q in pts]; ys = [q[1] for q in pts]
                largo = max(max(xs) - min(xs), max(ys) - min(ys))
        alto = vivo.get("alto", ent.get("height", 0))
        # v84 · para una viga o un peldaño, `height` es la COTA ABSOLUTA de
        # su cara superior, no su peralte. Se hace la MISMA resta que ya
        # hace el exportador al dibujar, para que la tabla diga lo mismo
        # que sale en SketchUp.
        if vivo.get("alto") is None and ent["type"] in ("beam", "stair"):
            _npt_b = pr.get("npt_base")
            if isinstance(_npt_b, (int, float)) and isinstance(alto, (int, float)):
                alto = round(float(alto) - float(_npt_b), 4)
        return ancho, largo, alto, nom_grupo

    def _elementos_del_paso():
        """Los elementos que toca mostrar AHORA: el nivel activo, filtrados
        por el paso en curso. Devuelve [(ent_id, ent), ...] o [] si todavía
        no hay modelo."""
        modelo = motor.kernel.to_dict() if getattr(motor, "kernel", None) else None
        if not modelo:
            return [], None, []
        niveles = sorted(modelo["levels"].items(), key=lambda kv: kv[1]["elevation"])
        nombres_piso = [f"Piso {i+1}" for i in range(len(niveles))] or ["Piso 1"]
        idx_piso = (nombres_piso.index(var_piso_sel.get())
                    if var_piso_sel.get() in nombres_piso else 0)
        lvl_id = niveles[idx_piso][0] if niveles else None

        _cats_paso = None
        try:
            if not var_rapido.get():
                _fases_disp = _fase_disponible()
                _i = paso_actual["i"]
                if _i < len(_fases_disp):
                    _cats_paso = set(CATEGORIAS_DE_FASE.get(_fases_disp[_i][0], []))
        except Exception:
            _cats_paso = None

        items = [(k2, v2) for k2, v2 in modelo["entities"].items()
                 if v2["level_id"] == lvl_id]
        if _cats_paso:
            vis = [x for x in items if _categoria_de_entidad(x[1]) in _cats_paso]
            # En Vanos, 'muros' viaja como dependencia técnica (hay que
            # regenerar el muro para cortarle el hueco), pero el usuario ya
            # los confirmó: no deben volver a aparecer en la lista.
            if "vanos" in _cats_paso and len(_cats_paso) > 1:
                vis = [x for x in vis if _categoria_de_entidad(x[1]) == "vanos"]
            items = vis
        return items, lvl_id, nombres_piso

    def poblar_lista_elementos():
        for w in list(p_elem.winfo_children())[1:]:
            w.destroy()
        fila_elementos.clear()
        modelo = motor.kernel.to_dict() if getattr(motor, "kernel", None) else None
        if not modelo:
            return
        niveles = sorted(modelo["levels"].items(), key=lambda kv: kv[1]["elevation"])
        nombres_piso = [f"Piso {i+1}" for i in range(len(niveles))] or ["Piso 1"]
        combo_piso["values"] = nombres_piso
        if var_piso_sel.get() not in nombres_piso:
            var_piso_sel.set(nombres_piso[0])
        idx_piso = nombres_piso.index(var_piso_sel.get())
        # La memoria se lee con la MISMA clave con la que se escribe: el nivel
        # real en un edificio, el índice del desplegable en un plano suelto.
        motor.piso_activo = (int(nivel_activo.get("piso") or 0)
                             if nivel_activo.get("modo") == "edificio"
                             else idx_piso)
        lvl_id = niveles[idx_piso][0] if niveles else None

        cont = tk.Frame(p_elem)
        cont.pack(fill="both", expand=True)
        # El encabezado usa EXACTAMENTE los mismos anchos que las filas de
        # datos; antes eran dos grillas independientes y los títulos no
        # calzaban con su columna.
        ANCHO_NOMBRE, ANCHO_MEDIDA, ANCHO_BOTON = 22, 6, 2
        cab = tk.Frame(cont); cab.pack(fill="x")
        for c, (t, w) in enumerate((("Elemento", ANCHO_NOMBRE),
                                    ("Ancho", ANCHO_MEDIDA),
                                    ("Largo", ANCHO_MEDIDA),
                                    ("Alto", ANCHO_MEDIDA),
                                    ("", ANCHO_BOTON), ("", ANCHO_BOTON),
                                    ("", ANCHO_BOTON))):
            tk.Label(cab, text=t, font=("Segoe UI", 8, "bold"), width=w,
                     anchor="w").grid(row=0, column=c, padx=4, pady=2)
        canvas = tk.Canvas(cont, highlightthickness=0)
        scroll = ttk.Scrollbar(cont, orient="vertical", command=canvas.yview)
        tabla = tk.Frame(canvas)
        tabla.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=tabla, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        def _rueda(event):
            delta = -1 if (getattr(event, "num", 0) == 5 or event.delta < 0) else 1
            canvas.yview_scroll(-delta, "units")
            return "break"
        # Al pasar el mouse por la tabla, la rueda scrollea ESTA lista
        # (bind local, no global: no interfiere con el resto de la GUI).
        for w in (canvas, tabla):
            w.bind("<MouseWheel>", _rueda)      # Windows / Mac
            w.bind("<Button-4>", _rueda)        # Linux arriba
            w.bind("<Button-5>", _rueda)        # Linux abajo
        def _bind_hijos(widget):
            for ch in widget.winfo_children():
                ch.bind("<MouseWheel>", _rueda)
                ch.bind("<Button-4>", _rueda)
                ch.bind("<Button-5>", _rueda)
                _bind_hijos(ch)
        tabla.after(50, lambda: _bind_hijos(tabla))

        # FILTRO POR PASO: la tabla muestra SOLO lo del paso en curso. En
        # Muros+Pisos se ven muros y pisos; al pasar a Vanos, los muros ya
        # quedaron confirmados y desaparecen, y solo se ven los vanos.
        # v88 · el cálculo vive ahora en `_elementos_del_paso`, arriba, para
        # que la maqueta muestre EXACTAMENTE lo mismo. Aquí solo se pinta.
        _cat_de_entidad = _categoria_de_entidad

        _items, _, _ = _elementos_del_paso()
        for i, (ent_id, ent) in enumerate(_items):
            nombre = (ent.get("properties") or {}).get("nombre") or ent_id
            fr = tk.Frame(tabla); fr.pack(fill="x")
            lbl = tk.Label(fr, text=f"{ent['type']}: {nombre}", anchor="w", width=22,
                          font=("Segoe UI", 8), cursor="hand2")
            lbl.grid(row=0, column=0, sticky="w", padx=4, pady=2)
            # EVIDENCIA EN TODOS LOS ELEMENTOS, sin excepción: doble clic en el
            # nombre y salen sus dos recortes (plano limpio y de información).
            # La regla de Willy: nada de «asumí 1.10 m» sin poder comprobarlo.
            lbl.bind("<Double-Button-1>",
                     lambda _e, _n=nombre: _ventana_evidencia(
                         f"{_n} — evidencia en los planos",
                         poly=_contorno_de(_n), nombre=_n))
            nom_grupo = f"ORA_{nombre}"
            # v88 · el cálculo de las tres medidas vive ahora en
            # `_medidas_de_entidad`, arriba — el mismo que usa la maqueta.
            # Aquí solo se recogen los valores y se pintan.
            #
            # (Lo que resuelve esa función, que antes estaba aquí: el ancho
            # sale del espesor del DXF porque no depende de la orientación
            # del muro; largo y alto salen de SketchUp si ya llegaron, y si
            # no, del plano; y en vigas y peldaños se resta el NPT porque
            # `height` es la cota absoluta de la cara superior, no el
            # peralte — la misma resta que hace el exportador al dibujar.)
            ancho_actual, largo_actual, alto_actual, nom_grupo = \
                _medidas_de_entidad(ent, nombre)
            vivo = estado_vivo.get(nom_grupo) or {}
            pr = ent.get("properties") or {}

            def _mk(valor, col, ancho=6):
                var = tk.StringVar(value=f"{valor:.2f}"
                                   if isinstance(valor, (int, float)) else "")
                e = tk.Entry(fr, textvariable=var, width=ancho)
                e.grid(row=0, column=col, padx=4)
                return var, e

            va, ea = _mk(ancho_actual, 1)
            vl, el_ = _mk(largo_actual, 2)
            vh, eh = _mk(alto_actual, 3)

            def _aplicar_campo(n, var, campo):
                """Escribes la medida y ENTER/botón: se aplica en SketchUp.

                Si en SketchUp hay VARIOS elementos seleccionados y este es
                uno de ellos, la medida se aplica a TODOS de una vez.
                Antes se aplicaba solo a la fila donde escribiste, aunque
                tuvieras 6 muros seleccionados: escribías la altura y solo
                cambiaba uno. El botón de abajo sí lo hacía, pero nadie tiene
                por qué adivinar que hay dos caminos distintos.
                """
                try:
                    valor = float(str(var.get()).replace(",", "."))
                except ValueError:
                    log("Escribe un número (ej. 2.75).", "warn")
                    return
                if valor <= 0:
                    log("La medida debe ser mayor que cero.", "warn")
                    return
                objetivos = seleccion_actual.get("varios") or []
                if len(objetivos) > 1 and n in objetivos:
                    enviar_edicion(objetivos, campo, round(valor, 4))
                    log(f"✏️ {campo} = {valor} aplicado a los "
                        f"{len(objetivos)} seleccionados.", "ok")
                    # La tabla refleja el cambio en todas las filas del lote.
                    for _f in fila_elementos:
                        if _f["nombre"] in objetivos:
                            _f[f"var_{campo}"].set(f"{valor:.2f}")
                else:
                    enviar_edicion(n, campo, round(valor, 4))

            for _col, (_e, _v, _campo) in enumerate(
                    ((ea, va, "ancho"), (el_, vl, "largo"), (eh, vh, "alto"))):
                _e.bind("<Return>", lambda ev, n=nom_grupo, v=_v, c=_campo:
                        _aplicar_campo(n, v, c))
                tk.Button(fr, text="✔", font=("Segoe UI", 7), width=2, cursor="hand2",
                          command=lambda n=nom_grupo, v=_v, c=_campo:
                          _aplicar_campo(n, v, c)
                          ).grid(row=0, column=4 + _col, padx=(0, 2))
            lbl.bind("<Button-1>",
                     lambda e, n=nom_grupo: seleccionar_en_sketchup(n))
            fila_elementos.append({"nombre": nom_grupo, "label": lbl, "frame": fr,
                                   "bg": fr.cget("bg"), "var_alto": vh,
                                   "var_ancho": va, "var_largo": vl})

    fr_sel = tk.Frame(p_elem); fr_sel.pack(fill="x", pady=(0, 6))
    tk.Label(fr_sel, text="Piso:", font=("Segoe UI", 9)).pack(side="left")
    combo_piso = ttk.Combobox(fr_sel, textvariable=var_piso_sel, state="readonly", width=10)
    combo_piso.pack(side="left", padx=6)
    combo_piso.bind("<<ComboboxSelected>>", lambda e: poblar_lista_elementos())
    # PLANTA ACTIVA (modo edificio). Aparece solo si se detectaron varios
    # niveles; en modo un piso ni se ve.
    var_planta = tk.StringVar(value="")
    lbl_planta = tk.Label(fr_sel, text="  Planta:", font=("Segoe UI", 9))
    combo_planta = ttk.Combobox(fr_sel, textvariable=var_planta,
                                state="readonly", width=26)

    def _cambiar_planta(_e=None):
        t = var_planta.get()
        if not t:
            return
        try:
            _n = int(str(t).split("·")[0].replace("Nivel", "").strip())
        except Exception:
            return
        # Cambiar de planta re-analiza SU plano: cada nivel es independiente
        # hasta el ensamble.
        _aplicar_nivel(_n, analizar=True)

    combo_planta.bind("<<ComboboxSelected>>", _cambiar_planta)

    def _ventana_insertar_mobiliario():
        """Apartado B — v95.

        Junta los vanos ya confirmados de TODOS los pisos del edificio
        (usa lo congelado en SketchUp cuando existe — lo confirmado
        manda sobre el DXF, tal como pidió Willy), los agrupa por medida
        real (no por código de plano) y sugiere una ficha de la
        Biblioteca por grupo. Willy resuelve cada grupo UNA vez.

        Al final genera un .rb SUELTO (no usa el pulso en vivo, que
        borra y reconstruye — esto es aditivo, nunca toca lo que ya
        está armado) para pegar a mano en la consola de SketchUp, con el
        edificio ya abierto.
        """
        import biblioteca_datos as bd
        import insertar_mobiliario as im
        if not edificio["tabla"]:
            messagebox.showinfo("ORA", "Todavía no hay un edificio detectado.\n\n"
                                "Analiza los planos de todas las plantas primero.")
            return
        if not getattr(motor, "kernel", None):
            messagebox.showinfo("ORA", "No hay un modelo cargado todavía.")
            return

        t = tk.Toplevel(root)
        t.title("Insertar Mobiliario — ORA Modeler")
        t.geometry("900x600")
        tk.Label(t, text="Vanos de todo el edificio, agrupados por medida real.",
                font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=14, pady=(12, 2))
        tk.Label(t, text="Cada fila es una MEDIDA (no un vano): resuélvela una vez y "
                        "se aplica a todos los vanos de esa medida, en cualquier piso. "
                        "Lo confirmado en SketchUp manda sobre el DXF.",
                font=("Segoe UI", 9), fg="#555", wraplength=860, justify="left"
                ).pack(anchor="w", padx=14, pady=(0, 8))

        cont = tk.Frame(t)
        cont.pack(fill="both", expand=True, padx=14)
        estado_grupos = {"grupos": [], "asignacion": {}}  # idx_grupo -> codigo o None

        def _recolectar():
            firma = _firma_actual()
            modelo = motor.kernel.to_dict()
            vanos = im.recolectar_vanos(modelo, firma,
                                        obtener_congelados=(
                                            __import__("memoria_elementos").congelados_de))
            insertables = [v for v in vanos if im.vano_insertable(v)]
            faltantes = len(vanos) - len(insertables)
            grupos = im.agrupar_por_medida(insertables)
            estado_grupos["grupos"] = grupos
            estado_grupos["asignacion"] = {
                i: (g["sugerencias"][0]["codigo"] if g["sugerencias"] else None)
                for i, g in enumerate(grupos)}
            return faltantes

        def _refrescar_tabla():
            for w in cont.winfo_children():
                w.destroy()
            faltantes = _recolectar()
            if faltantes:
                tk.Label(cont, text=f"⚠️ {faltantes} vano(s) sin suficiente "
                                    "geometría para insertar (se listan igual "
                                    "en su piso; no se tocan).",
                        fg="#b45309", font=("Segoe UI", 8)).pack(anchor="w")

            canvas = tk.Canvas(cont, highlightthickness=0)
            scroll = ttk.Scrollbar(cont, orient="vertical", command=canvas.yview)
            tabla = tk.Frame(canvas)
            tabla.bind("<Configure>",
                      lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
            canvas.create_window((0, 0), window=tabla, anchor="nw")
            canvas.configure(yscrollcommand=scroll.set)
            canvas.pack(side="left", fill="both", expand=True)
            scroll.pack(side="right", fill="y")

            cab = tk.Frame(tabla); cab.pack(fill="x")
            for c, (txt, w) in enumerate((("Tipo", 9), ("Medida (ancho×alto, m)", 20),
                                          ("Alféizar", 8), ("Cant.", 5),
                                          ("Pisos", 12), ("Ficha sugerida", 30))):
                tk.Label(cab, text=txt, font=("Segoe UI", 8, "bold"), width=w,
                        anchor="w").grid(row=0, column=c, padx=3, pady=2)

            if not estado_grupos["grupos"]:
                tk.Label(tabla, text="No hay vanos confirmados todavía en ningún "
                                     "piso, o no encontré geometría suficiente "
                                     "para agruparlos.",
                        font=("Segoe UI", 9)).pack(anchor="w", pady=10)

            for i, g in enumerate(estado_grupos["grupos"]):
                fr = tk.Frame(tabla); fr.pack(fill="x")
                pisos_txt = ",".join(str((p or 0) + 1) for p in
                                     sorted(set(v["piso"] for v in g["vanos"])))
                vals = (g["tipo"], f'{g["ancho"]:.2f} × {g["alto"]:.2f}',
                       f'{g["alfeizar"]:.2f}', str(len(g["vanos"])), pisos_txt)
                for c, (v, w) in enumerate(zip(vals, (9, 20, 8, 5, 12))):
                    tk.Label(fr, text=v, width=w, anchor="w",
                            font=("Segoe UI", 8)).grid(row=0, column=c, padx=3, pady=1)

                opciones = ["— no insertar —"]
                mapa_opcion_codigo = {0: None}
                todas_del_tipo = [f for f in bd.listar_vanos()
                                  if f.get("tipo") == g["tipo"]]
                cods_sugeridos = {s["codigo"] for s in g["sugerencias"]}
                orden = (g["sugerencias"]
                        + [{"codigo": f["codigo"], "ficha": f}
                           for f in todas_del_tipo if f["codigo"] not in cods_sugeridos])
                for s in orden:
                    f = s["ficha"]
                    etiqueta = (f"{f['codigo']}  ({f['ancho']:.2f}×{f['alto']:.2f}"
                               f"{'  ✅ recomendada' if s['codigo'] in cods_sugeridos else ''})")
                    mapa_opcion_codigo[len(opciones)] = s["codigo"]
                    opciones.append(etiqueta)

                var_sel = tk.StringVar()
                actual = estado_grupos["asignacion"].get(i)
                idx_actual = next((k for k, v in mapa_opcion_codigo.items()
                                   if v == actual), 0)
                var_sel.set(opciones[idx_actual])
                combo = ttk.Combobox(fr, textvariable=var_sel, values=opciones,
                                     state="readonly", width=32)
                combo.grid(row=0, column=5, padx=3)

                def _al_elegir(_e, i=i, opciones=opciones,
                               mapa=mapa_opcion_codigo, var_sel=var_sel):
                    idx = opciones.index(var_sel.get())
                    estado_grupos["asignacion"][i] = mapa[idx]
                combo.bind("<<ComboboxSelected>>", _al_elegir)

        def _generar():
            asignados = []
            sin_biblioteca = 0
            for i, g in enumerate(estado_grupos["grupos"]):
                codigo = estado_grupos["asignacion"].get(i)
                if not codigo:
                    continue
                ficha = next((f for f in bd.listar_vanos()
                             if f["codigo"] == codigo), None)
                if not ficha:
                    continue
                if not ficha.get("tiene_skp"):
                    sin_biblioteca += 1
                for v in g["vanos"]:
                    v = dict(v)
                    v["archivo_skp"] = ficha["archivo"]
                    asignados.append(v)
            if not asignados:
                messagebox.showinfo("ORA", "No hay ninguna medida resuelta con "
                                    "una ficha de biblioteca todavía.", parent=t)
                return
            ruta = im.guardar_ruby(asignados)
            aviso = (f"Listo: {len(asignados)} vano(s) resueltos.\n\n"
                    f"Archivo generado:\n{ruta}\n\n"
                    "Para aplicarlo: abre ese archivo con el Bloc de notas, "
                    "copia TODO, y pégalo en Ventana > Consola Ruby de "
                    "SketchUp — con el edificio ya abierto ahí.\n\n"
                    "Es aditivo: solo agrega lo que falta, no toca ni borra "
                    "nada de lo que ya está construido.")
            if sin_biblioteca:
                aviso += (f"\n\n⚠️ {sin_biblioteca} ficha(s) elegidas todavía no "
                         "tienen su archivo .skp en la carpeta biblioteca/ — "
                         "esos vanos quedarán como hueco limpio hasta que lo "
                         "agregues.")
            messagebox.showinfo("ORA", aviso, parent=t)

        pie = tk.Frame(t); pie.pack(fill="x", padx=14, pady=12)
        tk.Button(pie, text="↻ Recalcular", command=_refrescar_tabla).pack(side="left")
        tk.Button(pie, text="Generar Ruby de inserción", command=_generar,
                 font=("Segoe UI", 9, "bold")).pack(side="right")
        tk.Button(pie, text="Cerrar", command=t.destroy).pack(side="right", padx=8)

        _refrescar_tabla()
        t.lift()

    def _ventana_ensamble():
        """M5 — un botón: Ensamblar. Con la tabla delante y editable.

        Se enseña qué se va a mover ANTES de moverlo. Si falta un NPT o no se
        pudo alinear un nivel, no se ensambla y se dice cuál.
        """
        from ensamblar import plan_de_ensamble, ruby_ensamble, resumen_texto
        if not edificio["tabla"]:
            messagebox.showinfo("ORA", "Todavía no hay un edificio detectado.\n\n"
                                "Analiza los planos de todas las plantas primero.")
            return
        t = tk.Toplevel(root)
        t.title("ORA — Ensamblar el edificio")
        t.transient(root)
        tk.Label(t, text="Cada piso se coloca moviendo SOLO su grupo. Lo que "
                         "hay dentro no se toca.", font=("Segoe UI", 9),
                 wraplength=560, justify="left").pack(anchor="w", padx=10,
                                                      pady=(10, 4))
        fr = tk.Frame(t)
        fr.pack(fill="x", padx=10)
        for j, cab in enumerate(("Nivel", "NPT (m)", "Llegada", "Libre")):
            tk.Label(fr, text=cab, font=("Segoe UI", 8, "bold")).grid(
                row=0, column=j, padx=4, sticky="w")
        campos = {}
        for i, f in enumerate(edificio["tabla"], 1):
            tk.Label(fr, text=str(f["nivel"])).grid(row=i, column=0, sticky="w",
                                                    padx=4)
            v = tk.StringVar(value=("" if f.get("npt") is None
                                    else f"{f['npt']:.2f}"))
            tk.Entry(fr, textvariable=v, width=8).grid(row=i, column=1, padx=4)
            campos[f["nivel"]] = v
            f["_lbl_lleg"] = tk.Label(fr, text="—")
            f["_lbl_lleg"].grid(row=i, column=2, sticky="w", padx=4)
            f["_lbl_libre"] = tk.Label(fr, text="—")
            f["_lbl_libre"].grid(row=i, column=3, sticky="w", padx=4)
        # ---- ELEVACIÓN EN VIVO (v57) ----------------------------------
        # Pedido de Willy: «que el usuario vea a qué nivel va a entrar cada
        # planta, una elevación gráfica en vivo, bloquecitos, minimalista, con
        # posibilidad de trasladar pisos si puse el sótano donde va el 2».
        # Hasta ahora el ensamble era una tabla de números: se aceptaba a
        # ciegas y el error solo se veía ya en SketchUp.
        fr_ele = tk.Frame(t)
        fr_ele.pack(fill="x", padx=10, pady=(6, 0))
        tk.Label(fr_ele, text="Así va a quedar  ·  usa ▲▼ para mover una "
                              "planta a otro nivel",
                 font=("Segoe UI", 8), fg="#64748b").pack(anchor="w")
        cv = tk.Canvas(fr_ele, height=190, bg="#f8fafc",
                       highlightthickness=1, highlightbackground="#e2e8f0")
        cv.pack(fill="x")
        sel_ele = {"nivel": None}

        def _pintar_elevacion(plan):
            cv.delete("all")
            pasos = sorted(plan.get("pasos") or [], key=lambda x: x["nivel"])
            if not pasos:
                cv.create_text(12, 20, anchor="w", fill="#b45309",
                               font=("Segoe UI", 9),
                               text="Falta el NPT de alguna planta.")
                return
            zs = [p["z"] for p in pasos]
            _lleg = {f["nivel"]: f.get("llegada") for f in edificio["tabla"]}
            top = max((_lleg.get(p["nivel"]) or p["z"] + 2.6) for p in pasos)
            bot = min(zs)
            span = max(top - bot, 0.5)
            H, M = 170.0, 12
            def _y(z):
                return M + (top - z) / span * (H - 2 * M)
            for p in pasos:
                z0 = p["z"]
                z1 = _lleg.get(p["nivel"])
                if z1 is None:
                    z1 = z0 + 2.6
                y0, y1 = _y(z1), _y(z0)
                marcado = sel_ele["nivel"] == p["nivel"]
                copia = bool(p.get("copia_de"))
                cv.create_rectangle(
                    120, y0, 430, y1,
                    fill=("#c7ddfb" if marcado else
                          "#eef2f7" if copia else "#dbeafe"),
                    outline=("#1e6fd9" if marcado else "#94a3b8"),
                    width=(2 if marcado else 1),
                    tags=("blq", f"n{p['nivel']}"))
                cv.create_text(114, (y0 + y1) / 2, anchor="e",
                               font=("Segoe UI", 8, "bold"),
                               text=_nombre_nivel(p["nivel"]))
                cv.create_text(436, (y0 + y1) / 2, anchor="w",
                               font=("Consolas", 8), fill="#475569",
                               text=f"{z0:+.2f} → {z1:+.2f}"
                                    + ("   (copia)" if copia else ""))
            cv.create_line(120, _y(0.0), 430, _y(0.0), fill="#dc2626",
                           dash=(3, 2))
            cv.create_text(116, _y(0.0), anchor="e", fill="#dc2626",
                           font=("Segoe UI", 7), text="0.00")

        def _nombre_nivel(n):
            for f in edificio["tabla"]:
                if f.get("nivel") != n:
                    continue
                cl = str(f.get("clase") or "").lower()
                return {"sotano": "SÓTANO", "semisotano": "SEMISÓTANO",
                        "azotea": "AZOTEA"}.get(cl, f"PISO {n}")
            return f"PISO {n}"

        def _clic_bloque(ev):
            for it in cv.find_overlapping(ev.x, ev.y, ev.x, ev.y):
                for tg in cv.gettags(it):
                    if tg.startswith("n") and tg[1:].lstrip("-").isdigit():
                        sel_ele["nivel"] = int(tg[1:])
                        _recalcular()
                        return
        cv.bind("<Button-1>", _clic_bloque)

        def _mover_planta(paso):
            """Sube o baja la planta marcada un nivel entero.

            Intercambia su NPT con el de la vecina: es lo que Willy quiere
            cuando puso el sótano donde iba el piso 2. Lo de dentro de cada
            grupo no se toca — solo cambia a qué cota entra.
            """
            n = sel_ele.get("nivel")
            if n is None:
                log("Marca primero una planta en el dibujo.", "warn")
                return
            orden = sorted(edificio["tabla"], key=lambda x: x["nivel"])
            i = next((k for k, f in enumerate(orden) if f["nivel"] == n), None)
            j = (i or 0) + paso
            if i is None or j < 0 or j >= len(orden):
                return
            a, b = orden[i], orden[j]
            campos[a["nivel"]].set("" if b.get("npt") is None
                                   else f"{b['npt']:.2f}")
            campos[b["nivel"]].set("" if a.get("npt") is None
                                   else f"{a['npt']:.2f}")
            sel_ele["nivel"] = b["nivel"]
            _recalcular()

        fr_mov = tk.Frame(fr_ele)
        fr_mov.pack(anchor="w", pady=(4, 0))
        tk.Button(fr_mov, text="▲ subir", font=("Segoe UI", 8), cursor="hand2",
                  command=lambda: _mover_planta(1)).pack(side="left")
        tk.Button(fr_mov, text="▼ bajar", font=("Segoe UI", 8), cursor="hand2",
                  command=lambda: _mover_planta(-1)).pack(side="left", padx=4)

        txt = tk.Text(t, height=8, width=78, font=("Consolas", 8))
        txt.pack(fill="both", expand=True, padx=10, pady=6)

        def _esp():
            try:
                return float(str(var_losa.get()).replace(",", ".") or 0.20)
            except Exception:
                return 0.20

        def _recalcular(*_a):
            """Cambiar un NPT recalcula TODA la tabla, como debe ser."""
            for f in edificio["tabla"]:
                try:
                    f["npt"] = float(str(campos[f["nivel"]].get())
                                     .replace(",", ".")) if \
                        campos[f["nivel"]].get().strip() else None
                except ValueError:
                    f["npt"] = None
            e = _esp()
            orden = sorted(edificio["tabla"], key=lambda x: x["nivel"])
            for i, f in enumerate(orden):
                sig = orden[i + 1] if i + 1 < len(orden) else None
                f["llegada"] = (round(sig["npt"] - e, 4)
                                if sig and sig.get("npt") is not None else None)
                f["altura_libre"] = (round(f["llegada"] - f["npt"], 4)
                                     if (f.get("llegada") is not None
                                         and f.get("npt") is not None) else None)
                f["_lbl_lleg"].configure(
                    text="—" if f["llegada"] is None else f"{f['llegada']:.2f}")
                f["_lbl_libre"].configure(
                    text="—" if f["altura_libre"] is None
                    else f"{f['altura_libre']:.2f}")
            plan = plan_de_ensamble(edificio["tabla"],
                                    edificio["deteccion"], e)
            txt.delete("1.0", "end")
            txt.insert("1.0", resumen_texto(plan, e))
            try:
                _pintar_elevacion(plan)
            except Exception:
                pass
            btn_ok.configure(state=("disabled" if plan.get("faltan")
                                   else "normal"))
            return plan

        for v in campos.values():
            v.trace_add("write", _recalcular)

        def _ensamblar():
            plan = _recalcular()
            if plan.get("faltan"):
                return
            os.makedirs("salidas", exist_ok=True)
            n, _f = ruby_ensamble(plan, "salidas/ensamble.rb")
            try:
                from sincronizacion_vivo import emitir_pulso
                emitir_pulso(os.path.abspath("salidas/ensamble.rb"))
                log(f"Ensamblando {n} niveles en SketchUp. Solo se mueven los "
                    "grupos: lo de dentro queda como lo dejaste.", "ok")
            except Exception as ex:
                log(f"No se pudo enviar el ensamble: {ex}", "warn")
            t.destroy()

        fr2 = tk.Frame(t)
        fr2.pack(fill="x", padx=10, pady=(0, 10))
        btn_ok = tk.Button(fr2, text="🏢  ENSAMBLAR", font=("Segoe UI", 10, "bold"),
                           cursor="hand2", command=_ensamblar)
        btn_ok.pack(side="left")
        tk.Button(fr2, text="Cancelar", command=t.destroy).pack(side="left",
                                                                padx=8)
        _recalcular()
        t.lift()

    def _mostrar_selector_planta():
        if not edificio["tabla"]:
            lbl_planta.pack_forget()
            combo_planta.pack_forget()
            return
        opciones = [f"Nivel {f['nivel']} · NPT {f['npt']:+.2f}"
                    if f.get("npt") is not None else f"Nivel {f['nivel']}"
                    for f in edificio["tabla"]]
        combo_planta["values"] = opciones
        if not var_planta.get() and opciones:
            var_planta.set(opciones[0])
        lbl_planta.pack(side="left")
        combo_planta.pack(side="left", padx=4)
        btn_ensamblar.pack(side="left", padx=(8, 0))
        btn_insertar_mob.pack(side="left", padx=(8, 0))

    btn_ensamblar = tk.Button(fr_sel, text="🏢 Ensamblar edificio",
                              font=("Segoe UI", 8), cursor="hand2",
                              command=lambda: _ventana_ensamble())
    # v95 · Apartado B — junto a Ensamblar porque es la MISMA clase de
    # acción: algo que se hace UNA vez para todo el edificio junto, no un
    # paso que se repite piso por piso (esos van en «3 · Asistente
    # guiado»). Willy lo confirmó así.
    btn_insertar_mob = tk.Button(fr_sel, text="🛋️ Insertar Mobiliario",
                                 font=("Segoe UI", 8), cursor="hand2",
                                 command=lambda: _ventana_insertar_mobiliario())
    tk.Button(fr_sel, text="⇔ Acoplar ventanas", font=("Segoe UI", 8),
             command=lambda: acoplar_ventanas()).pack(side="right")
    p_elem.pack(fill="both", expand=True, pady=(4, 0))

    def acoplar_ventanas():
        from acople_ventanas import acoplar
        ok, msg = acoplar()
        log(("🪟 " if ok else "⚠️ ") + msg, "ok" if ok else "warn")

    ultima_seleccion = {"txt": None}
    estado_vivo = {}          # nombre -> {ancho, largo, alto, z} medido en SketchUp
    ultimo_estado_txt = {"v": None}

    # NIVEL ACTIVO. En modo un piso vale 0 y nada cambia. En modo edificio
    # dice sobre qué planta se está trabajando: filtra el estado en vivo, la
    # memoria y el grupo de SketchUp al que se le habla.
    nivel_activo = {"piso": 0, "modo": "un_piso", "nombre": "", "npt": None,
                    "llegada": None, "cuelga": False, "paso_techo": True,
                    "grupo": None}
    # Detección de niveles (M1). Vacío = modo un piso.
    edificio = {"deteccion": None, "tabla": [], "confirmado": False}
    # Qué hace cada subtipo de muro que NO es el estándar del nivel. Lo
    # declara el usuario en el paso de Muros y manda sobre la altura genérica.
    #   {"MURO CISTERNA": {"modo": "cota", "alto": 1.80, "z": -1.80}}
    subtipos_declarados = {}

    def _recuperar_subtipos():
        """
        LO QUE YA CONTESTASTE, NO SE VUELVE A PREGUNTAR (v66).

        Willy: «contestas una altura, cierras ORA y te la vuelve a preguntar».
        Cierto: la respuesta se guardaba en disco con `guardar_decision` y
        `subtipos_declarados` arrancaba vacío en cada sesión. Nadie la releía
        nunca. Ahora se recupera al analizar, por firma de plano y por piso.
        """
        try:
            from memoria_elementos import decisiones_de
            _f = getattr(motor, "firma_memoria", None) or motor.firma_plano
            _p = int(getattr(motor, "piso_activo", 0) or 0)
            _rec = decisiones_de(_f, _p) or {}
        except Exception:
            return 0
        _n = 0
        for _id, _val in _rec.items():
            if not str(_id).startswith("subtipo::"):
                continue
            _sub = str(_id).split("::", 1)[1]
            if _sub in subtipos_declarados or not isinstance(_val, dict):
                continue
            subtipos_declarados[_sub] = _val
            _n += 1
        if _n:
            log(f"🧠 {_n} altura(s) de muro que ya habías confirmado se "
                f"recuperaron de la memoria: no se vuelven a preguntar.", "ok")
        return _n
    # Cisternas/sótanos leídos del adjunto de cada planta, por nombre de DXF
    # limpio: {"sin_cotas-PISO_1.dxf": {"fondo": -1.80, "alto": 1.95, ...}}.
    # `leer_bajo_nivel()` existía desde la v41 y NADIE la llamaba: el aviso de
    # «MURO CISTERNA» salía con el campo en blanco aunque el dato estuviera
    # escrito en el plano.
    bajo_nivel = {}

    def _nace_en_terreno(edificio, idx_nivel):
        """¿Esta planta apoya en el terreno? Lo dice la TABLA, no la cota."""
        filas = [f for f in (edificio.get("tabla") or [])
                 if f.get("nivel") is not None and f.get("npt") is not None]
        if not filas:
            return True
        try:
            npt_aqui = float(next(float(f["npt"]) for f in filas
                                  if int(f["nivel"]) == int(idx_nivel)))
        except StopIteration:
            return False
        npts = sorted(float(f["npt"]) for f in filas)
        # la planta baja: la más baja que no está enterrada
        sobre = [n for n in npts if n >= -0.001]
        baja = sobre[0] if sobre else npts[0]
        return npt_aqui <= baja + 0.001

    def _aplicar_nivel(idx_nivel, analizar=False, cabecera=""):
        # Antes de saltar de planta se guarda lo que el usuario escribió para
        # la que deja: al volver, lo encuentra donde lo dejó (v66).
        try:
            _recordar_altura_mano()
        except Exception:
            pass
        """Pone la planta `idx_nivel` como activa y ajusta sus dos cotas.

        Cada nivel se levanta EN SU SITIO, con su NPT de arranque y su cota de
        llegada. El grupo de SketchUp al que se le habla también cambia, así
        que un nivel nunca pisa a otro.
        """
        fila = next((f for f in edificio["tabla"]
                     if f.get("nivel") == idx_nivel), None)
        if not fila:
            return
        det = edificio["deteccion"] or {}
        nv = next((n for n in (det.get("niveles") or [])
                   if n.get("nombre") == fila.get("nombre")), {})
        nivel_activo.update({
            "piso": int(idx_nivel), "modo": "edificio",
            "nombre": fila.get("nombre") or "", "npt": fila.get("npt"),
            "llegada": fila.get("llegada"),
            "cuelga": bool(idx_nivel > 1),
            # SOBRE TERRENO = solo la planta más baja del edificio. Es la
            # única cuyo piso rellena hasta su NPT (los 15 cm del piso 1);
            # todas las demás llevan losa estructural. Sin esto la típica
            # dibujaba una losa de 2.75 m de espesor.
            "sobre_terreno": bool(
                int(idx_nivel) == min(
                    (int(f["nivel"]) for f in (edificio.get("tabla") or [])
                     if f.get("nivel") is not None), default=int(idx_nivel))),
            # NACE EN EL TERRENO (v65.4) — la regla de Willy, sin candados
            # de cota. La planta baja es la más baja que NO está enterrada;
            # ella y todo lo que quede por debajo (sótanos, cisterna) nacen
            # en el terreno. De la segunda para arriba el muro se apoya
            # sobre la losa, siempre.
            #
            # Antes esto se decidía con «el NPT está entre 0.00 y 0.60»,
            # un parche para que la azotea no bajara sus muros. Con una
            # planta baja a +0.80 se rompía, y la cisterna quedaba fuera.
            "nace_en_terreno": _nace_en_terreno(edificio, idx_nivel),
            "paso_techo": bool(nv.get("tiene_paso_techo", True)),
            "grupo": f"PISO_{int(idx_nivel)}"})
        # ---- v85 · CADA PLANTA, SU PROPIA PREVIA DE VIGAS -----------------
        # Willy: «lo que pasa en el primer piso queda en el primer piso».
        # `previa_vigas` se creaba UNA sola vez al abrir ORA y no se tocaba
        # nunca más. Al aprobar la previa del piso 1, quedaba aprobada para
        # la típica y para la azotea: esas plantas se saltaban el paso de
        # revisión y las vigas llegaban YA RECORTADAS sin haberlo pedido.
        #
        # Se ve en su propia consola:
        #   PISO 1   vigas 20 -> 7.3376 m3   (previa entera)
        #            vigas 38 -> 6.3004 m3   (recortada)     <- DOS pasos
        #   TIPICA   vigas 21 -> 3.0180 m3   (ya recortada)  <- previa saltada
        # y en la interfaz: el panel de Vigas de la típica no mostraba ni la
        # sección «Previa de vigas (sin recortar)» ni el botón «Recortar».
        #
        # Al activar una planta se vuelve a cero. Nada más: el resto del
        # mecanismo de la previa (mostrar, aprender posiciones, recortar) no
        # se toca, sigue exactamente igual que en el piso 1.
        previa_vigas["mostrada"] = False
        previa_vigas["aprobada"] = False
        # La memoria se indexa por el nivel real DESDE YA: si se deja para
        # cuando se repinta la tabla, lo primero que llegue de SketchUp cae
        # en la bolsa del piso anterior.
        _piso_anterior_trace = getattr(motor, "piso_activo", None)
        motor.piso_activo = int(idx_nivel)
        # EL DESPLEGABLE SIGUE AL ASISTENTE (v66). Antes se quedaba clavado en
        # la primera fila —la cisterna— y hacía dudar de todo lo demás.
        try:
            _op = (f"Nivel {fila['nivel']} · NPT {fila['npt']:+.2f}"
                   if fila.get("npt") is not None else f"Nivel {fila['nivel']}")
            if _op in (combo_planta["values"] or ()):
                var_planta.set(_op)
        except Exception:
            pass
        # Y la MISMA etiqueta con la que se va a leer después.
        motor.firma_memoria = _firma_del_edificio()
        # ---- TRACE: transición de piso -------------------------------
        # Justo en el punto exacto que el REGLAMENTO señala como la única
        # llave que distingue un piso de otro en toda la memoria del
        # sistema. Si alguna vez motor.piso_activo queda desfasado de
        # nivel_activo["piso"], esto lo marca solo, en el momento en que
        # ocurre — no hay que esperar a ver el síntoma en una viga.
        trace_forense.cambio_piso(
            piso_anterior=_piso_anterior_trace, piso_nuevo=int(idx_nivel),
            nivel_activo_piso=nivel_activo.get("piso"),
            motor_piso_activo=motor.piso_activo,
            modo=nivel_activo.get("modo"), firma=motor.firma_memoria,
            nombre_nivel=fila.get("nombre"), npt=fila.get("npt"),
            grupo=nivel_activo.get("grupo"))
        log(f"Planta activa: nivel {idx_nivel} · NPT {fila.get('npt')} → "
            f"llegada {fila.get('llegada')}. Se levanta en su sitio, dentro "
            f"del grupo ORA_PISO_{idx_nivel}.", "ok")
        if not analizar:
            return
        # Cada planta se analiza con SU par de planos. Nada de la otra planta
        # entra aquí: es lo que permite aislar las fallas.
        limpio = nv.get("archivo")
        info = nv.get("info")
        if not limpio:
            log("Esa planta no tiene DXF limpio asociado.", "warn")
            return
        btn_analizar.configure(state="disabled")
        log(f"Analizando la planta del nivel {idx_nivel}...", "warn")

        def _trabajo_nivel():
            try:
                # EL CORTE PROPIO DE LA PLANTA MANDA SOBRE EL GENERAL (v63).
                # Willy: «tiene cortes individualmente para cada piso, pero
                # faltaría uno a nivel general para que lo pueda leer de
                # todos». Los dos conviven: si esta planta trae el suyo, ese
                # gana; si no, el del edificio entero.
                cortes = None
                for _a in (nv.get("adjuntos") or []):
                    if str(_a.get("que") or "").lower().startswith("corte"):
                        _r = str(_a.get("ruta") or "").strip()
                        if _r:
                            cortes = _r
                            break
                cortes = cortes or (var_cortes.get().strip() or None)
                if cortes:
                    log(f"Corte en uso para esta planta: "
                        f"{os.path.basename(cortes)}", "ok")
                motor.analizar(limpio, var_unidad.get(), None,
                               archivo_specs=info, archivo_cortes=cortes,
                               # CADA PLANTA ARRANCA EN 0.00 LOCAL (v58).
                               #
                               # Aquí se le pasaba el NPT del nivel como cota
                               # de arranque, así que la planta se DIBUJABA ya
                               # a su cota dentro del grupo `ORA_PISO_n`… y
                               # después «Ensamblar edificio» subía ese mismo
                               # grupo otra vez a su NPT. La cota se sumaba
                               # dos veces:
                               #
                               #   piso 1    0.15 + 0.15  = +0.30
                               #   típica    2.75 + 2.75  = +5.50
                               #   cisterna -1.60 + -1.60 = -3.20
                               #
                               # Era justo lo contrario de lo decidido en la
                               # v57 («cada piso se levanta como si fuera el
                               # primero, desde 0.00; el ensamble lo sube»).
                               # Se cambió el motor de cotas y esta línea
                               # quedó viva. El NPT del nivel sigue llegando
                               # al generador por `dec["nivel"]["npt"]`, que
                               # es lo que hace falta para las medidas
                               # relativas — esto solo fijaba el cero.
                               z_base=0.0)
                informe = (cabecera or "") + "\n\n" + motor.informe()

                def _fin():
                    mostrar_informe(informe)
                    # LA ESCALERA, TAMBIÉN EN MULTIPISOS (v52).
                    #
                    # `var_esc` es lo que le dice al motor «genera la
                    # escalera». Se encendía SOLO en el camino de un plano
                    # suelto: en un edificio nunca se activaba, así que el
                    # paso de Escalera se recorría entero, se confirmaba… y
                    # en SketchUp no aparecía ni un peldaño. Los 14 escalones
                    # del plano de Willy estaban detectados y nadie los
                    # mandaba a construir.
                    _esc = (motor.resumen or {}).get("escalera")
                    if _esc or ((motor.resumen or {}).get("escaleras") or []):
                        var_esc.set(True)
                        if _esc and not _esc.get("real"):
                            var_esc_pasos.set(str(_esc["pasos"] + 1))
                    montar_cuadro_manual(
                        (motor.resumen or {}).get("vanos_incompletos") or [])
                    # EL EDIFICIO TAMBIÉN SE RELLENA CON LO DEL CORTE (v63).
                    #
                    # Esto solo pasaba en el carril de un piso. En multipisos
                    # se leía el corte y las medidas se quedaban ahí sin
                    # llegar a las casillas — una razón más de que Willy
                    # siguiera viendo 2.60 después de que ORA hubiera leído
                    # 2.40 del plano.
                    _recuperar_subtipos()
                    _aplicar_sugerencias_corte(motor.resumen)
                    _pintar_medido(motor.resumen)
                    btn_generar.configure(state="normal")
                    btn_vivo.configure(state="normal")
                    for clave in estado_fases:
                        estado_fases[clave] = False
                    refrescar_fases()
                    btn_analizar.configure(state="normal")
                root.after(0, _fin)
            except Exception as ex:
                root.after(0, lambda _m=str(ex): (
                    messagebox.showerror("ORA", f"Error al analizar la "
                                                f"planta:\n{_m}"),
                    btn_analizar.configure(state="normal")))
        threading.Thread(target=_trabajo_nivel, daemon=True).start()

    def _leer_estado_vivo():
        from memoria_elementos import partir_clave_piso
        """LÍNEA 1 (continua): lee lo que SketchUp publica cada instante.

        Esto es PROVISIONAL: sirve para que ORA nunca muestre datos viejos
        mientras trabajas. Lo definitivo se aprende al guardar (línea 2)."""
        try:
            import tempfile
            ruta = os.path.join(tempfile.gettempdir(), "ora_estado_vivo.txt")
            if not os.path.exists(ruta):
                return False
            with open(ruta, encoding="utf-8") as f:
                txt = f.read()
            if txt == ultimo_estado_txt["v"]:
                return False
            ultimo_estado_txt["v"] = txt
            estado_vivo.clear()
            for linea in txt.splitlines():
                partes = linea.strip().split("|")
                if len(partes) >= 5:
                    # En modo edificio el plugin manda «P2::ORA_M01». Aquí solo
                    # interesa el nivel que se está trabajando: los demás no se
                    # mezclan en el estado en vivo.
                    _pl, _nom = partir_clave_piso(partes[0])
                    if _pl is not None and _pl != (nivel_activo.get("piso") or 0):
                        continue
                    try:
                        estado_vivo[_nom] = {
                            "ancho": float(partes[1]), "largo": float(partes[2]),
                            "alto": float(partes[3]), "z": float(partes[4]),
                            # x/y solo los manda el plugin nuevo (previa de
                            # vanos); con el viejo quedan en 0 y no se rompe.
                            "x": float(partes[5]) if len(partes) > 5 else 0.0,
                            "y": float(partes[6]) if len(partes) > 6 else 0.0,
                            # ang: giro en planta, lo manda el plugin 4.2+.
                            # Sirve para aprender que giraste una caja de previa.
                            "ang": float(partes[7]) if len(partes) > 7 else 0.0}
                    except ValueError:
                        continue
            return True
        except Exception:
            return False

    seleccion_actual = {"nombre": None, "varios": []}

    def aplicar_edicion_ficha():
        """Aplica alto / desplazamiento Z / X-Y a lo seleccionado en SketchUp.

        SELECCIÓN MÚLTIPLE (pedido de Willy): si hay varios grupos
        seleccionados, la misma orden se aplica a TODOS. Sirve para bajar seis
        muros de golpe o ponerle la misma altura a todas las columnas, en vez
        de repetir la operación uno por uno.
        """
        objetivos = seleccion_actual.get("varios") or (
            [seleccion_actual["nombre"]] if seleccion_actual["nombre"] else [])
        if not objetivos:
            log("Selecciona primero uno o varios elementos en SketchUp.", "warn")
            return
        nombre = objetivos[0]

        def _num(var, obligatorio=False):
            txt = str(var.get()).replace(",", ".").strip()
            if not txt and not obligatorio:
                return None
            try:
                return float(txt)
            except ValueError:
                return None

        hecho = []
        # UNA orden por campo, con TODOS los objetivos dentro. Nunca un bucle
        # de órdenes sueltas: se pisan en el archivo compartido.
        alto = _num(var_ed_alto)
        if alto is not None and alto > 0:
            enviar_edicion(objetivos, "alto", round(alto, 4))
            hecho.append(f"alto {alto:.3f}")
        # NPT / cota base: medida FINAL (lleva la base a esa cota), no un delta.
        npt = _num(var_ed_npt)
        if npt is not None:
            enviar_edicion(objetivos, "npt", round(npt, 4))
            hecho.append(f"NPT {npt:+.3f}")
            var_ed_npt.set("")
        for var, campo, etiqueta in ((var_ed_z, "mover_z", "Z"),
                                     (var_ed_x, "mover_x", "X"),
                                     (var_ed_y, "mover_y", "Y"),
                                     (var_ed_rot, "rotacion", "rotación")):
            d = _num(var)
            if d:                      # 0 o vacío = no mover
                enviar_edicion(objetivos, campo, round(d, 4))
                hecho.append(f"{etiqueta} {d:+.3f}")
                var.set("0")
        # Material: valor de TEXTO, no numérico (el plugin lo resuelve por nombre).
        mat = str(var_ed_mat.get() or "").strip()
        if mat:
            enviar_edicion(objetivos, "material", mat)
            hecho.append(f"material {mat}")
        if not hecho:
            log("Escribe un alto, un NPT, un desplazamiento o elige un material.", "warn")
        elif len(objetivos) == 1:
            log(f"✏️ {nombre}: {', '.join(hecho)}", "ok")
        else:
            log(f"✏️ {len(objetivos)} elementos a la vez: {', '.join(hecho)}", "ok")

    ultimo_resultado_edicion = {"txt": None}

    def enviar_edicion(nombre_grupo, campo, valor):
        """ORA -> SketchUp: aplicar una medida a UNO o VARIOS elementos.

        `nombre_grupo` puede ser un nombre suelto o una lista. Los varios van
        en UNA sola orden separados por ';'.

        BUG QUE ESTO CORRIGE: antes se llamaba a esta función una vez por
        elemento, y las 6 órdenes se escribían en el MISMO archivo. Como el
        plugin lo lee cada 0.5 s, las órdenes se pisaban entre sí antes de
        que alcanzara a leerlas: el usuario seleccionaba 6 muros, escribía la
        altura y solo cambiaba uno.
        """
        try:
            import tempfile
            nombres = ([nombre_grupo] if isinstance(nombre_grupo, str)
                       else list(nombre_grupo))
            nombres = [n for n in nombres if n]
            if not nombres:
                return
            etiqueta = (nombres[0] if len(nombres) == 1
                        else f"{len(nombres)} elementos")
            sello = f"{time.time():.3f}"
            # v85 · EL AMBITO: el grupo del piso activo (PISO_1, PISO_2...).
            # Va como 5º campo de la orden. Sin él, el plugin buscaba el
            # nombre en TODO el modelo y, con el edificio ensamblado, el M07
            # de la típica acababa siendo el M07 del piso 1 (los nombres
            # M01..M14 se repiten en las dos plantas). En modo UN PISO no hay
            # grupo de piso: va vacío y el plugin se comporta como siempre.
            # v86 · `nivel_activo["grupo"]` guarda el piso PELADO ("PISO_2"),
            # sin el prefijo "ORA_" — así lo espera `nombre_piso` cuando lo
            # usa el exportador para NOMBRAR el contenedor (ahí el propio
            # exportador le antepone "ORA_"; si aquí también se lo pusiéramos,
            # el contenedor real habría salido duplicado: "ORA_ORA_PISO_2").
            #
            # Pero el contenedor que existe DE VERDAD en SketchUp se llama
            # "ORA_PISO_2" (con el prefijo — lo confirma el propio patrón que
            # usa el plugin para reconocerlo: `/\AORA_PISO_-?\d+\z/`). Y
            # `buscar_grupo_ora_ambito`, del lado de Ruby, busca por IGUALDAD
            # EXACTA de texto. Se le mandaba "PISO_2" pelado, nunca calzaba
            # con "ORA_PISO_2", y la búsqueda por piso fallaba SIEMPRE — caía
            # de vuelta al buscador viejo (el primer M07 que encontrara en
            # todo el modelo, el del piso 1). Por eso una edición como M07 en
            # la típica nunca se quedaba: no es que no se aplicara, es que se
            # aplicaba al gemelo equivocado.
            #
            # Aquí, y SOLO aquí (variable local, no toca `nombre_piso` ni
            # nada que ya funcione), se arma el nombre CON el prefijo, igual
            # que existe en SketchUp.
            _ambito = ""
            try:
                if nivel_activo.get("modo") == "edificio":
                    _grupo = str(nivel_activo.get("grupo") or "")
                    _ambito = f"ORA_{_grupo}" if _grupo else ""
            except Exception:
                _ambito = ""
            ruta = os.path.join(tempfile.gettempdir(), "ora_orden_edicion.txt")
            with open(ruta, "w", encoding="utf-8") as f:
                f.write(f"{';'.join(nombres)}|{campo}|{valor}|{sello}|{_ambito}")
            nombre_grupo = etiqueta
            log(f"✏️ {etiqueta}: {campo} = {valor} m enviado, esperando SketchUp...", "warn")

            def _revisar(intentos=15):
                try:
                    ruta_r = os.path.join(tempfile.gettempdir(), "ora_resultado_edicion.txt")
                    if os.path.exists(ruta_r):
                        with open(ruta_r, encoding="utf-8") as f:
                            txt = f.read().strip()
                        if txt != ultimo_resultado_edicion["txt"] and sello in txt:
                            ultimo_resultado_edicion["txt"] = txt
                            partes = txt.split("|")
                            error_part = next((p for p in partes if p.startswith("error:")), None)
                            if error_part is not None:
                                res = error_part
                            else:
                                res = partes[3] if len(partes) > 3 else txt
                            if res == "ok":
                                log(f"✅ {nombre_grupo}: {campo} = {valor} m aplicado en SketchUp.", "ok")
                            elif str(res).startswith("parcial:"):
                                log(f"⚠️ {nombre_grupo}: solo {res.split(':')[1]} se "
                                    "aplicaron. Los demás no se encontraron en "
                                    "SketchUp.", "warn")
                            elif res == "no encontrado":
                                log(f"❌ {nombre_grupo} no se encontró en SketchUp (¿está "
                                    "abierto ese modelo?).", "warn")
                            elif res == "sin cambio":
                                log(f"ℹ️ {nombre_grupo}: {campo} ya medía eso.", "ok")
                            else:
                                log(f"⚠️ {nombre_grupo}: {res}", "warn")
                            return
                except Exception:
                    pass
                if intentos > 0:
                    root.after(400, lambda: _revisar(intentos - 1))
                else:
                    log(f"⚠️ {nombre_grupo}: no hubo respuesta de SketchUp. Revisa que "
                        "esté abierto y con el plugin v5.0 instalado.", "warn")
            root.after(400, lambda: _revisar())
        except Exception as ex:
            log(f"No se pudo enviar la medida: {ex}", "warn")

    def seleccionar_en_sketchup(nombre_grupo, zoom=True):
        """ORA -> SketchUp: al hacer clic en un elemento de la lista, el plugin
        lo selecciona y hace zoom en el modelo."""
        try:
            import tempfile
            ruta = os.path.join(tempfile.gettempdir(), "ora_sel_desde_ora.txt")
            with open(ruta, "w", encoding="utf-8") as f:
                f.write(f"{nombre_grupo}|{'1' if zoom else '0'}|{time.time():.3f}")
            var_ficha.set(motor.ficha_de(nombre_grupo) or nombre_grupo)
            log(f"👉 {nombre_grupo} marcado en SketchUp.", "ok")
        except Exception as ex:
            log(f"No se pudo marcar en SketchUp: {ex}", "warn")

    def _refrescar_medidas_vivas():
        """Actualiza los campos de la tabla con lo que mide SketchUp AHORA."""
        for fila in fila_elementos:
            vivo = estado_vivo.get(fila["nombre"])
            if not vivo:
                continue
            try:
                for clave, campo in (("var_alto", "alto"), ("var_largo", "largo")):
                    var = fila.get(clave)
                    if var is None or campo not in vivo:
                        continue
                    nuevo_txt = f"{vivo[campo]:.2f}"
                    if var.get() != nuevo_txt and not fila.get("editando"):
                        var.set(nuevo_txt)
            except Exception:
                continue

    def _poll_seleccion():
        """SketchUp -> ORA, en tiempo real: lo que seleccionas allá se resalta
        aquí y se muestra su ficha (qué es exactamente lo que vas a modificar)."""
        if _leer_estado_vivo():
            _refrescar_medidas_vivas()
        try:
            import tempfile
            ruta = os.path.join(tempfile.gettempdir(), "ora_seleccion.txt")
            seleccionados = []
            if os.path.exists(ruta):
                with open(ruta, encoding="utf-8") as f:
                    seleccionados = [l.strip() for l in f if l.strip()]
            marcados = set(seleccionados)
            # Un vano puede existir en SketchUp con dos nombres según el paso:
            # 'ORA_PREVIA_X' mientras es caja naranja y 'ORA_X' una vez cortado.
            # Se aceptan LOS DOS para resaltar la fila, así seleccionar la caja
            # naranja en SketchUp ilumina su fila en ORA y se puede editar en
            # lote igual que un muro o una columna.
            for _s in list(marcados):
                if _s.startswith("ORA_PREVIA_"):
                    marcados.add("ORA_" + _s[len("ORA_PREVIA_"):])
                elif _s.startswith("ORA_"):
                    marcados.add("ORA_PREVIA_" + _s[len("ORA_"):])
            for fila in fila_elementos:
                try:
                    if fila["nombre"] in marcados:
                        fila["frame"].configure(bg="#fde68a")      # resaltado ámbar
                        fila["label"].configure(bg="#fde68a",
                                                font=("Segoe UI", 8, "bold"))
                    else:
                        fila["frame"].configure(bg=fila["bg"])
                        fila["label"].configure(bg=fila["bg"], font=("Segoe UI", 8))
                except Exception:
                    continue
            clave = "|".join(seleccionados)
            if clave != ultima_seleccion["txt"]:
                ultima_seleccion["txt"] = clave
                seleccion_actual["varios"] = list(seleccionados)
                if not seleccionados:
                    seleccion_actual["nombre"] = None
                    var_ficha.set("Nada seleccionado en SketchUp.")
                elif len(seleccionados) == 1:
                    nom = seleccionados[0]
                    seleccion_actual["nombre"] = nom
                    ficha = motor.ficha_de(nom) or nom
                    vivo = estado_vivo.get(nom)
                    if vivo:
                        ficha += (f"\n📐 En SketchUp ahora: alto {vivo['alto']:.3f} m · "
                                  f"ancho {vivo['ancho']:.3f} m · largo {vivo['largo']:.3f} m")
                        var_ed_alto.set(f"{vivo['alto']:.3f}")
                    var_ficha.set(ficha)
                else:
                    # FICHA AGRUPADA: en vez de listar uno por uno, se resume
                    # por tipo y se muestra la medida común. Así se ve de un
                    # vistazo qué se va a cambiar y a cuántos.
                    from collections import Counter
                    def _tipo(n):
                        b = n[4:] if n.startswith("ORA_") else n
                        if b.startswith("Piso_"):
                            return "piso"
                        if b.startswith("Techo") or b.startswith("Losa"):
                            return "techo"
                        if b.startswith("Peldano") or b.startswith("Escalera"):
                            return "escalera"
                        if re.match(r"^VG\d", b) or b.startswith("Viga"):
                            return "viga"
                        if re.match(r"^(P\d+-)?C\d+$", b) or b.startswith("Columna"):
                            return "columna"
                        if re.search(r"-(P|V|M|PS|VA)-?\d", b):
                            return "vano"
                        return "muro"
                    conteo = Counter(_tipo(n) for n in seleccionados)
                    resumen_tipos = " · ".join(
                        f"{c} {t}{'s' if c > 1 and not t.endswith('s') else ''}"
                        for t, c in conteo.most_common())
                    fichas_txt = [resumen_tipos]
                    # Si TODOS comparten la misma medida, se precarga el campo:
                    # así se ve el valor actual del conjunto antes de cambiarlo.
                    vivos = [estado_vivo.get(n) for n in seleccionados]
                    vivos = [v for v in vivos if v]
                    if len(vivos) == len(seleccionados) and vivos:
                        for clave, etiq in (("alto", "alto"), ("ancho", "ancho"),
                                            ("largo", "largo")):
                            vals = {round(float(v[clave]), 3) for v in vivos}
                            if len(vals) == 1:
                                fichas_txt.append(
                                    f"📐 Todos con {etiq} {vals.pop():.3f} m")
                            else:
                                fichas_txt.append(
                                    f"📐 {etiq}: {len(vals)} medidas distintas")
                        altos = {round(float(v["alto"]), 3) for v in vivos}
                        var_ed_alto.set(f"{altos.pop():.3f}" if len(altos) == 1 else "")
                    fichas_txt.append(
                        f"\n✏️ Lo que escribas abajo se aplica a los "
                        f"{len(seleccionados)} DE UNA VEZ.")
                    seleccion_actual["nombre"] = seleccionados[0]
                    var_ficha.set(f"{len(seleccionados)} elementos seleccionados\n"
                                  + "\n".join(fichas_txt))
        except Exception:
            pass
        root.after(400, _poll_seleccion)   # cada 0.4 s, siempre

    def alternar_modo_split():
        modo_split["activo"] = not modo_split["activo"]
        if modo_split["activo"]:
            lbl_der.pack_forget()
            txt.pack_forget()
            poblar_lista_elementos()
            p_elem.pack(fill="both", expand=True, pady=(4, 0))
            btn_split.configure(text="📄 Volver al informe de análisis")
            acoplar_ventanas()
        else:
            p_elem.pack_forget()
            lbl_der.pack(anchor="w")
            txt.pack(fill="both", expand=True, pady=(4, 0))
            btn_split.configure(text="📋 Ver/editar lista de elementos")
    p_elem.pack_forget()  # oculto hasta que el usuario active el modo split
    txt.insert("1.0", "Bienvenido a ORA Modeler.\n\n"
               "En '1 · Plano' hay TRES campos — no confundirlos:\n"
               "  ①  DXF LIMPIO (obligatorio) — la GEOMETRÍA: muros, vanos,\n"
               "      columnas, pisos, techo. Es el plano que se convierte en 3D.\n"
               "  ②  DXF DE DATOS (opcional) — la FICHA del mismo proyecto:\n"
               "      cuadro de vanos, NPT por ambiente, acabados. NO es otra\n"
               "      geometría: son las medidas que le faltan al ①.\n"
               "  ③  DXF DE CORTES (opcional) — alturas reales por ambiente,\n"
               "      rotulado 'CORTE A - A''.\n\n"
               "1. Elige tu DXF limpio (① es el único obligatorio).\n"
               "2. Presiona ANALIZAR PLANO y revisa el informe aquí.\n"
               "3. Ajusta las decisiones y presiona GENERAR 3D.\n\n"
               "SketchUp se abrirá solo y el modelo se construirá solo\n"
               "(instala una vez el plugin sketchup_plugin/ora_importer.rbz).")
    txt.configure(state="disabled")
    barra = tk.Label(root, text="Listo.", anchor="w", font=("Segoe UI", 9),
                     bd=1, relief="solid", padx=8, pady=4)
    barra.pack(fill="x", side="bottom")

    # ---------- lógica ----------
    def log(msg, tipo="info"):
        colores = {"info": T()["texto"], "ok": T()["ok"], "warn": T()["warn"]}
        barra.configure(text=msg, fg=colores.get(tipo, T()["texto"]))
        root.update_idletasks()

    def mostrar_informe(texto):
        txt.configure(state="normal")
        txt.delete("1.0", "end")
        txt.insert("1.0", texto)
        txt.configure(state="disabled")

    def elegir_archivo():
        ruta = filedialog.askopenfilename(
            title="① DXF LIMPIO — la geometría (muros, vanos, columnas)",
            filetypes=[("Planos DXF", "*.dxf"), ("Todos", "*.*")],
            initialdir=os.path.join(BASE, "ejemplos"))
        if ruta:
            var_archivo.set(ruta)

    def elegir_specs():
        ruta = filedialog.askopenfilename(
            title="② DXF DE DATOS — cuadro de vanos, NPT (opcional)",
            filetypes=[("Planos DXF", "*.dxf"), ("Todos", "*.*")],
            initialdir=os.path.join(BASE, "ejemplos"))
        if ruta:
            var_specs.set(ruta)

    def montar_cuadro_manual(bloques, vanos_ricos=None):
        for w in p_cv.winfo_children():
            w.destroy()
        filas_cv.clear()
        if not bloques:
            p_cv.pack_forget()
            return
        # Área con scroll propio: la tabla nunca vuelve a tapar el botón GENERAR
        cv_canvas = tk.Canvas(p_cv, height=190, highlightthickness=0)
        cv_scroll = ttk.Scrollbar(p_cv, orient="vertical", command=cv_canvas.yview)
        tabla = tk.Frame(cv_canvas)
        tabla.bind("<Configure>",
                   lambda e: cv_canvas.configure(scrollregion=cv_canvas.bbox("all")))
        cv_canvas.create_window((0, 0), window=tabla, anchor="nw")
        cv_canvas.configure(yscrollcommand=cv_scroll.set)
        cv_canvas.pack(side="left", fill="both", expand=True)
        cv_scroll.pack(side="right", fill="y")

        cab = ("Capa / vano", "Cant.", "Tipo", "Código", "Ancho", "Alto", "Alféizar")
        for c, t in enumerate(cab):
            tk.Label(tabla, text=t, font=("Segoe UI", 8, "bold")).grid(
                row=0, column=c, padx=2)
        ricos = {v["bloque"]: v for v in (vanos_ricos or [])}
        for i, nb in enumerate(bloques, 1):
            info = ricos.get(nb, {})
            etiqueta = info.get("capa", nb).replace("ORA_", "")[:18]
            tk.Label(tabla, text=etiqueta, font=("Segoe UI", 8)).grid(
                row=i, column=0, padx=2, sticky="w")
            tk.Label(tabla, text=f"×{info.get('cantidad', 1)}",
                     font=("Segoe UI", 8)).grid(row=i, column=1)
            vt = tk.StringVar(value="V" if info.get("tipo") == "window" else "P")
            ttk.Combobox(tabla, textvariable=vt, values=["P", "V"], width=3,
                         state="readonly").grid(row=i, column=2, padx=2)
            vc = tk.StringVar(value=("V" if info.get("tipo") == "window" else "P") + f"-{i}")
            tk.Entry(tabla, textvariable=vc, width=5).grid(row=i, column=3, padx=2)
            va = tk.StringVar(value=f"{info.get('ancho', 0.90):.2f}")
            tk.Entry(tabla, textvariable=va, width=5).grid(row=i, column=4, padx=2)
            vh = tk.StringVar(value=f"{info.get('alto', 2.10):.2f}")
            tk.Entry(tabla, textvariable=vh, width=5).grid(row=i, column=5, padx=2)
            vf = tk.StringVar(value=f"{info.get('alfeizar', 0.0):.2f}")
            tk.Entry(tabla, textvariable=vf, width=5).grid(row=i, column=6, padx=2)
            filas_cv.append((nb, vt, vc, va, vh, vf))
        tk.Button(tabla, text="✨ Sugerir con IA", command=sugerir_con_ia,
                  font=("Segoe UI", 9), cursor="hand2").grid(
            row=len(bloques) + 1, column=0, columnspan=7, sticky="we",
            padx=2, pady=(6, 2))
        p_cv.pack(fill="x", pady=(0, 8), before=p3)

    def leer_cuadro_manual():
        if not filas_cv:
            return None
        por_bloque = {}
        for nb, vt, vc, va, vh, vf in filas_cv:
            try:
                por_bloque[nb] = {
                    "tipo": "door" if vt.get() == "P" else "window",
                    "codigo": vc.get().strip().upper() or None,
                    "ancho": float(va.get().replace(",", ".")),
                    "alto": float(vh.get().replace(",", ".")),
                    "alfeizar": float(vf.get().replace(",", ".")),
                }
            except ValueError:
                pass
        cuadro = {"por_bloque": por_bloque}
        os.makedirs("salidas", exist_ok=True)
        with open("salidas/cuadro_vanos_manual.json", "w", encoding="utf-8") as f:
            json.dump(cuadro, f, ensure_ascii=False, indent=2)
        return cuadro


    FAMILIAS_FICHA = [("muro", "Muro (piso a techo)"), ("muro_bajo", "Muro bajo"),
                      ("muro_vista", "Elemento en vista"), ("puerta", "Puerta"),
                      ("ventana", "Ventana"), ("mampara", "Mampara"),
                      ("porton", "Portón"), ("columna", "Columna"),
                      ("piso", "Piso"), ("techo", "Techo"), ("escalera", "Escalera"),
                      ("baranda", "Baranda"), ("proyeccion", "Proyección (referencia)"),
                      ("mobiliario", "Mobiliario"), ("referencia", "Referencia (ignorar)")]

    def ficha_registro_capas(pendientes, firma, al_confirmar):
        """Ficha de registro (estándar §4): por cada capa no reconocida, el
        usuario elige la familia (la sugerencia de ORA viene preseleccionada) y
        una altura opcional. Se guarda en la memoria de oficina y se re-analiza."""
        from clasificador_capas import guardar_mapeo_memoria
        win = tk.Toplevel(root)
        win.title("ORA — Capas por confirmar")
        win.transient(root); win.grab_set()
        tk.Label(win, text="Encontré capas que no están en el catálogo.\n"
                           "Dime qué es cada una (se recordará para tus próximos planos):",
                 justify="left", padx=12, pady=8).pack(anchor="w")
        filas = []
        etiquetas = {k: v for k, v in FAMILIAS_FICHA}
        claves = [k for k, _ in FAMILIAS_FICHA]
        for p in pendientes:
            fr = tk.Frame(win); fr.pack(fill="x", padx=12, pady=3)
            tk.Label(fr, text=p["capa"], width=32, anchor="w",
                     font=("Segoe UI", 9, "bold")).pack(side="left")
            var_f = tk.StringVar(value=etiquetas.get(p.get("sugerencia") or "referencia",
                                                     "Referencia (ignorar)"))
            cb = ttk.Combobox(fr, textvariable=var_f, state="readonly", width=24,
                              values=[v for _, v in FAMILIAS_FICHA])
            cb.pack(side="left", padx=6)
            tk.Label(fr, text="Altura (m):").pack(side="left")
            var_h = tk.StringVar(value="")
            tk.Entry(fr, textvariable=var_h, width=6).pack(side="left", padx=(2, 0))
            filas.append((p["capa"], var_f, var_h))

        def confirmar():
            inversa = {v: k for k, v in FAMILIAS_FICHA}
            for capa, var_f, var_h in filas:
                fam = inversa.get(var_f.get(), "referencia")
                extra = {}
                try:
                    if var_h.get().strip():
                        extra["altura"] = float(var_h.get().replace(",", "."))
                except ValueError:
                    pass
                guardar_mapeo_memoria(firma, capa, fam, extra)
            win.destroy()
            log("Capas registradas en la memoria. Re-analizando...", "ok")
            al_confirmar()

        fr_b = tk.Frame(win); fr_b.pack(fill="x", pady=10, padx=12)
        tk.Button(fr_b, text="Confirmar y re-analizar", command=confirmar,
                  bg="#1f6feb", fg="white", padx=10).pack(side="right")
        tk.Button(fr_b, text="Después", command=win.destroy).pack(side="right", padx=8)


    # ---------------- FASE D: gestor de pisos del edificio ----------------
    # La lista de plantas vive en %APPDATA%\ORA_Modeler\edificio.json, no en
    # memoria. Antes se perdía al cerrar ORA y había que volver a cargar seis
    # rutas a mano cada vez que se abría el programa.
    def _ruta_edificio_json():
        from rutas_datos import carpeta_datos_app
        return os.path.join(carpeta_datos_app(), "edificio.json")

    def _guardar_edificio_en_disco(pisos):
        try:
            ruta = _ruta_edificio_json()
            trace_forense.escritura(
                archivo=ruta, funcion="_guardar_edificio_en_disco",
                firma=_firma_del_edificio(), piso="(proyecto)",
                elemento="estado[edificio]", campo="lista_pisos",
                valor=[os.path.basename(p.get("dxf") or "") for p in (pisos or [])])
            if not pisos:
                if os.path.exists(ruta):
                    os.remove(ruta)
                return
            with open(ruta, "w", encoding="utf-8") as f:
                json.dump(pisos, f, ensure_ascii=False, indent=2)
        except Exception as ex:
            trace_forense.excepcion(ex, funcion="_guardar_edificio_en_disco")
            log(f"No se pudo guardar la lista de plantas ({ex}). "
                "Sigue funcionando, pero se perderá al cerrar.", "warn")

    def _cargar_edificio_de_disco():
        """Devuelve las plantas guardadas cuyos archivos sigan existiendo."""
        try:
            ruta = _ruta_edificio_json()
            if not os.path.exists(ruta):
                return []
            with open(ruta, encoding="utf-8") as f:
                pisos = json.load(f)
            vivos = [p for p in pisos
                     if p.get("dxf") and os.path.exists(p["dxf"])]
            # ---- TRACE: qué había persistido ANTES de que el usuario -----
            # tocara nada en esta sesión — exactamente lo que el encargo
            # (sección 14) pedía: el propio TRACE debe registrar qué
            # memoria/archivos estaban presentes al comenzar, sin asumir
            # que el entorno arranca limpio.
            trace_forense.lectura(
                archivo=ruta, funcion="_cargar_edificio_de_disco",
                firma=None, piso="(proyecto)", elemento="estado[edificio]",
                campo="lista_pisos_al_abrir",
                valor=[os.path.basename(p.get("dxf") or "") for p in vivos])
            if len(vivos) != len(pisos):
                log(f"{len(pisos) - len(vivos)} planta(s) guardadas ya no "
                    "están en su carpeta: se quitaron de la lista.", "warn")
            return vivos
        except Exception:
            return []

    estado["edificio"] = []      # lista de dicts: un DXF por piso/sótano

    def refrescar_etiqueta_edificio():
        pisos = estado["edificio"]
        if not pisos:
            lbl_edificio.configure(text="")
            return
        n = sum(max(1, int(p.get("repeticiones", 1))) for p in pisos)
        sot = sum(max(1, int(p.get("repeticiones", 1))) for p in pisos if p.get("sotano"))
        lbl_edificio.configure(
            text=f"✔ Edificio de {n} nivel(es)"
                 + (f", {sot} sótano(s)" if sot else "")
                 + " — ANALIZAR PLANO usará esta lista")

    # Al abrir ORA, se recupera la lista de plantas de la sesión anterior.
    #
    # v93 · Y AHORA SE DICE, en vez de aparecer sin más.
    # Willy: «¿por qué se sigue autocargando solito planta limpia, planta de
    # datos, cortes, si yo nunca he cargado un DXF?». Sí los había cargado —
    # en una sesión anterior — y ORA los guarda en
    # %APPDATA%\ORA_Modeler\edificio.json para no hacerle repetir seis rutas
    # cada vez. La función está bien; lo que estaba mal es que lo hacía en
    # SILENCIO, y parecía que el programa se inventaba un proyecto solo.
    estado["edificio"] = _cargar_edificio_de_disco()
    if estado["edificio"]:
        log(f"📂 Recuperé las {len(estado['edificio'])} planta(s) que "
            "cargaste la última vez (quedan guardadas para no repetir las "
            "rutas cada vez). Si vas a empezar otro proyecto, pulsa «Varios "
            "pisos» y ahí «Quitar edificio (un solo plano)».", "warn")
    refrescar_etiqueta_edificio()

    # -----------------------------------------------------------------
    # «Edificio por pisos» (v44)
    # -----------------------------------------------------------------
    # Qué cambió respecto de la v43: la v40 quitó las columnas Altura, Losa,
    # Repite, Sótano y Cota — con razón, porque pedían números antes de que
    # ORA hubiera visto un solo plano — pero no puso nada a cambio. Si ORA
    # leía mal el rótulo, no había forma de corregirlo, y no existía manera
    # de decir «esta lámina es la azotea» ni de adjuntar el plano de techos o
    # el de la cisterna.
    #
    # Ahora: eliges el DXF, ORA lo lee al momento (≈1 s) y escribe en la fila
    # lo que entendió, con su evidencia debajo. Si acertó no tocas nada; si se
    # equivocó lo corriges y LO TUYO MANDA.
    TIPOS_PLANTA = [("Piso", "piso"), ("Planta típica", "tipica"),
                    ("Azotea", "azotea"), ("Sótano", "sotano"),
                    ("Semisótano", "semisotano")]
    ADJ_TIPOS = [("Cisterna / sótano interior", "cisterna"),
                 ("Techos", "techos"), ("Cuadro de vanos", "vanos"),
                 ("Cortes de esta planta", "cortes"),
                 ("Otro (lo pregunto)", "otro")]

    def _etiq_tipo(clave):
        return next((e for e, c in TIPOS_PLANTA if c == clave), "Piso")

    def _clave_tipo(etiqueta):
        return next((c for e, c in TIPOS_PLANTA if e == etiqueta), "piso")

    def _etiq_adj(clave):
        return next((e for e, c in ADJ_TIPOS if c == clave), ADJ_TIPOS[0][0])

    def _clave_adj(etiqueta):
        return next((c for e, c in ADJ_TIPOS if e == etiqueta), "otro")

    def abrir_edificio():
        t = TEMAS[estado["tema"]]
        win = tk.Toplevel(root)
        win.title("Edificio por pisos — ORA Modeler")
        win.configure(bg=t["bg"])
        win.geometry("1120x640")
        win.minsize(900, 460)
        win.transient(root)

        cont = tk.Frame(win, bg=t["bg"])
        cont.pack(fill="both", expand=True, padx=12, pady=(10, 0))

        ayuda = tk.Label(
            cont, bg=t["bg"], fg=t["texto"], justify="left", anchor="w",
            wraplength=1060, font=("Segoe UI", 9),
            text="Elige los planos y ORA los lee al momento: te dice qué nivel "
                 "entendió que es cada uno y de dónde lo sacó. Si acertó no "
                 "toques nada; si se equivocó, corrígelo aquí y manda lo que "
                 "tú pongas.\nOrdena con ▲▼: los de abajo primero.")
        ayuda.pack(fill="x", pady=(0, 8))

        # ── EL CORTE DE TODO EL EDIFICIO (v63) ────────────────────────────
        #
        # Esto es lo que faltaba, y era culpa de ORA, no de Willy.
        #
        # La casilla del corte vivía en «1 · Plano», en la fila 10. Y esa fila
        # entra en `campos_un_piso`, que al pulsar «Varios pisos» se oculta
        # entero con `grid_remove()`. O sea: EN MODO EDIFICIO LA CASILLA DEL
        # CORTE DESAPARECÍA DE LA PANTALLA, y encima el texto de esta misma
        # ventana lo mandaba a buscarla ahí.
        #
        # Consecuencia: en multifamiliar ORA NUNCA leyó una sola cota. Ni la
        # altura de muro (2.40), ni el peralte de las vigas, ni el desnivel
        # del clóset. Todo el trabajo de las cotas existía y no se ejecutaba
        # nunca en su carril.
        #
        # Se comparte `var_cortes` a propósito: es la misma variable que lee
        # el análisis, así que el corte llega solo, sin tocar nada más.
        fr_corte = tk.LabelFrame(
            cont, bg=t["bg"], fg=t["acento"], font=("Segoe UI", 9, "bold"),
            text="  ✂️  CORTES del edificio entero (para todas las plantas)  ")
        fr_corte.pack(fill="x", pady=(0, 10))
        tk.Label(fr_corte, bg=t["bg"], fg=t["texto"], justify="left",
                 font=("Segoe UI", 8), wraplength=1040, anchor="w",
                 text="De aquí salen la altura de muros, el espesor de losa y "
                      "el peralte de las vigas. ORA sabe a qué piso y a qué "
                      "ambiente pertenece cada cota, así que aplica a cada "
                      "planta solo lo suyo — y en su 0.00 local, no en la "
                      "cota del edificio.\nSi una planta tiene su propio corte "
                      "(«Cortes de esta planta»), ese manda sobre este."
                 ).pack(fill="x", padx=8, pady=(4, 4))
        fr_c2 = tk.Frame(fr_corte, bg=t["bg"])
        fr_c2.pack(fill="x", padx=8, pady=(0, 8))
        tk.Entry(fr_c2, textvariable=var_cortes, font=("Segoe UI", 9)
                 ).pack(side="left", fill="x", expand=True)

        def _elegir_corte_general():
            ruta = filedialog.askopenfilename(
                title="DXF de CORTES del edificio",
                filetypes=[("DXF", "*.dxf"), ("Todos", "*.*")])
            if ruta:
                var_cortes.set(ruta)
                _leer_corte_general()

        lbl_corte = tk.Label(fr_corte, bg=t["bg"], fg=t["texto"],
                             font=("Segoe UI", 8), anchor="w", justify="left",
                             wraplength=1040)
        lbl_corte.pack(fill="x", padx=8, pady=(0, 6))

        def _leer_corte_general():
            """Dice ahí mismo qué sacó del corte, sin esperar a generar."""
            ruta = (var_cortes.get() or "").strip()
            if not ruta or not os.path.exists(ruta):
                lbl_corte.configure(text="")
                return
            try:
                import ezdxf as _ez
                from adaptador_dwg import cotas_del_plano
                from emparejador_cortes import mapa_de_cortes
                _msp = _ez.readfile(ruta).modelspace()
                _cot = cotas_del_plano(_msp)
                _map = mapa_de_cortes(_msp)
                from collections import Counter as _C
                def _dom(a, b):
                    v = [c["valor"] for c in _cot if a <= c["valor"] <= b]
                    return _C(v).most_common(1)[0] if v else (None, 0)
                _h, _nh = _dom(2.00, 3.60)
                _l, _nl = _dom(0.10, 0.35)
                partes = [f"{len(_cot)} cotas leídas",
                          f"cortes: {', '.join(sorted(_map)) or 'sin rótulo'}"]
                if _h:
                    partes.append(f"altura de muros {_h:.2f} m ({_nh} veces)")
                if _l:
                    partes.append(f"espesor de losa {_l:.2f} m ({_nl} veces)")
                lbl_corte.configure(text="✅ " + " · ".join(partes))
            except Exception as ex:
                lbl_corte.configure(text=f"⚠️ No pude leer ese corte: {ex}")

        tk.Button(fr_c2, text="✂️  Elegir DXF de cortes...", cursor="hand2",
                  font=("Segoe UI", 9), command=_elegir_corte_general
                  ).pack(side="left", padx=(6, 0))
        _leer_corte_general()

        cab = tk.Frame(cont, bg=t["bg"])
        cab.pack(fill="x")
        for txt, ancho in (("", 6), ("Tipo", 15), ("📂 DXF limpio", 30),
                           ("📐 Información de ESA planta", 30),
                           ("Nivel(es)", 15), ("NPT", 7), ("Losa", 6)):
            tk.Label(cab, text=txt, width=ancho, anchor="w", bg=t["bg"],
                     fg=t["texto"], font=("Segoe UI", 8, "bold")
                     ).pack(side="left", padx=1)

        marco = tk.Frame(cont, bg=t["bg"])
        marco.pack(fill="both", expand=True)
        canvas = tk.Canvas(marco, bg=t["bg"], highlightthickness=0)
        scroll = ttk.Scrollbar(marco, orient="vertical", command=canvas.yview)
        tabla = tk.Frame(canvas, bg=t["bg"])
        tabla.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=tabla, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        filas = []
        btn_guardar = None
        pie_aviso = None      # se crea al final; `_revisar` puede correr antes

        # ---------- utilidades ----------
        def _buscar(var, titulo):
            ruta = filedialog.askopenfilename(
                title=titulo, parent=win,
                filetypes=[("Planos DXF", "*.dxf"), ("Todos", "*.*")],
                initialdir=os.path.join(BASE, "ejemplos"))
            if ruta:
                var.set(ruta)

        def _cinta(reg, texto, duda=False):
            reg["cinta"].configure(
                text=("  " + texto) if texto else "",
                bg=("#fdf3e3" if duda else "#e6f4ec") if texto else t["bg"],
                fg=("#7c3c05" if duda else "#14532d") if texto else t["texto"])
            reg["cinta"].pack_forget()
            if texto:
                reg["cinta"].pack(fill="x", padx=(58, 4), pady=(2, 0))

        # ---------- lectura del rótulo, al elegir el archivo ----------
        def _leer_rotulo(reg):
            ruta = reg["dxf"].get().strip()
            if not ruta or not os.path.exists(ruta) or reg.get("leyendo"):
                return
            if reg.get("leido") == ruta:
                return
            reg["leyendo"] = True
            _cinta(reg, "leyendo el plano…")

            def trabajo():
                dato, err = None, None
                try:
                    from niveles import analizar_archivo
                    dato = analizar_archivo(ruta)
                except Exception as ex:
                    err = str(ex)
                root.after(0, lambda: aplicar(dato, err))

            def aplicar(dato, err):
                reg["leyendo"] = False
                reg["leido"] = ruta
                if not reg["frame"].winfo_exists():
                    return
                if err or not dato:
                    _cinta(reg, f"no pude leerlo: {err}", duda=True)
                    return
                reg["capas"] = dato.get("capas") or []
                # Solo se rellena lo que el usuario NO haya tocado: si ya
                # corrigió algo, no se le pisa.
                if not reg["tocado_tipo"] and dato.get("clase"):
                    reg["tipo"].set(_etiq_tipo(dato["clase"]))
                    _cambio_tipo(reg)
                if not reg["tocado_nivel"]:
                    if dato.get("rango"):
                        reg["desde"].set(str(dato["rango"][0]))
                        reg["hasta"].set(str(dato["rango"][-1]))
                    if dato.get("nivel") is not None:
                        reg["nivel"].set(str(dato["nivel"]))
                partes = [p for p in (dato.get("evidencia") or []) if p][:3]
                if dato.get("muros"):
                    partes.append(f"{dato['muros']} muro(s), "
                                  f"{dato.get('columnas', 0)} columna(s)")
                cist = [c for c in reg["capas"]
                        if "CISTERNA" in c.upper() or "SOTANO" in c.upper()
                        or "SÓTANO" in c.upper()]
                if cist:
                    partes.append(f"trae dentro la capa «{cist[0]}»")
                    _asegurar_adjunto(reg, "cisterna")
                if reg["tipo"].get() == "Azotea":
                    _asegurar_adjunto(reg, "techos")
                _cinta(reg, " · ".join(partes) if partes
                       else "no encontré rótulo ni piso en las capas: "
                            "dime tú qué nivel es",
                       duda=not partes)
                _revisar()

            threading.Thread(target=trabajo, daemon=True).start()

        # ---------- adjuntos ----------
        def _asegurar_adjunto(reg, clave):
            for a in reg["adjuntos"]:
                if _clave_adj(a["que"].get()) == clave:
                    return
            _adjuntar(reg, {"que": clave, "ruta": ""})

        def _adjuntar(reg, datos=None):
            datos = datos or {}
            fr = tk.Frame(reg["caja_adj"], bg=t["bg"])
            fr.pack(fill="x", pady=1)
            v_que = tk.StringVar(value=_etiq_adj(datos.get("que", "otro")))
            v_ruta = tk.StringVar(value=datos.get("ruta", "") or "")
            ttk.Combobox(fr, textvariable=v_que, state="readonly", width=24,
                         values=[e for e, _c in ADJ_TIPOS]
                         ).pack(side="left", padx=(0, 3))
            tk.Entry(fr, textvariable=v_ruta, width=46).pack(side="left", padx=2)
            tk.Button(fr, text="📐", font=("Segoe UI", 8),
                      command=lambda: _buscar(v_ruta, "Plano adjunto")
                      ).pack(side="left")
            adj = {"que": v_que, "ruta": v_ruta, "frame": fr}

            def quitar_adj():
                fr.destroy()
                if adj in reg["adjuntos"]:
                    reg["adjuntos"].remove(adj)
                _revisar()
            tk.Button(fr, text="✕", font=("Segoe UI", 8), fg="#b91c1c",
                      command=quitar_adj).pack(side="left", padx=2)
            v_ruta.trace_add("write", lambda *a: _revisar())
            v_que.trace_add("write", lambda *a: _revisar())
            reg["adjuntos"].append(adj)
            reg["caja_adj"].pack(fill="x", padx=(58, 4), pady=(3, 0))

        # ---------- tipo ----------
        def _cambio_tipo(reg):
            # CAMBIAR EL TIPO OBLIGA A RELEER (v57). Willy: «si me confundo y
            # pongo azotea donde va sótano, y lo cambio, se queda congelado
            # lo que ya escogí». La lectura anterior era de otra cosa: se
            # descarta y se vuelve a leer ese plano con el tipo nuevo.
            _tipo_nuevo = reg["tipo"].get()
            _cambio_real = (reg.get("leido") is not None
                            and reg.get("tipo_leido") not in (None, _tipo_nuevo))
            if _cambio_real:
                reg["leido"] = None
                reg["capas"] = []
            reg["tipo_leido"] = _tipo_nuevo
            es_tipica = reg["tipo"].get() == "Planta típica"
            reg["caja_nivel"].pack_forget()
            reg["caja_rango"].pack_forget()
            (reg["caja_rango"] if es_tipica else reg["caja_nivel"]).pack(
                side="left", in_=reg["hueco_nivel"])
            if reg["tipo"].get() == "Azotea":
                _asegurar_adjunto(reg, "techos")
            # Y se relee de verdad, no solo se olvida. Con pestillo: leer
            # vuelve a escribir el tipo, y eso dispararía otra lectura.
            if (_cambio_real and (reg["dxf"].get() or "").strip()
                    and not reg.get("releyendo")):
                reg["releyendo"] = True
                try:
                    _leer_rotulo(reg)
                finally:
                    reg["releyendo"] = False
            _revisar()

        # ---------- conflicto de cisterna repetida ----------
        def _revisar():
            """Avisa de lo que huele raro. NUNCA bloquea.

            Antes esto apagaba el botón Guardar y Willy se quedaba encerrado:
            la fila de la cisterna chocaba CONSIGO MISMA (su plano trae capas
            «ORA_MURO CISTERNA» y a la vez se llama CISTERNA), así que el
            conflicto no se podía deshacer borrando nada. Se quedaba sin
            guardar y sin poder analizar el multifamiliar.

            Regla: ORA dice lo que ve, y Willy decide. Un aviso es un aviso.
            """
            avisos = []
            # La cisterna está DOS VECES solo si son DOS FILAS distintas: una
            # con la capa dibujada dentro y otra cargada como lámina aparte.
            # Una sola fila que cumple las dos cosas es la misma cisterna.
            dentro = [r for r in filas
                      if any("CISTERNA" in c.upper() for c in (r.get("capas") or []))]
            lamina = [r for r in filas
                      if _clave_tipo(r["tipo"].get()) in ("sotano", "semisotano")
                      and "CISTERN" in (r["dxf"].get() or "").upper()]
            otros = [r for r in dentro if r not in lamina]
            if otros and lamina:
                avisos.append(
                    "La cisterna aparece dos veces: como planta propia "
                    f"(«{os.path.basename(lamina[0]['dxf'].get())}») y "
                    "dibujada dentro de "
                    f"«{os.path.basename(otros[0]['dxf'].get())}». Se "
                    "levantaría duplicada: quita una fila, o déjala así si "
                    "sabes que son cosas distintas.")
            # Sótano o semisótano sin número de nivel: se le pone uno solo,
            # y se dice. Sin número, el análisis moría al abrir la planta.
            for k, r in enumerate(_sin_nivel()):
                r["nivel"].set(str(-1 - k))
                r["tocado_nivel"] = False
            sin_info = [r for r in filas
                        if r["dxf"].get().strip() and not r["datos"].get().strip()]
            if sin_info:
                avisos.append(
                    f"{len(sin_info)} planta(s) sin plano de información: sin "
                    "él no puedo leer su NPT y lo tendrás que escribir a mano.")
            if pie_aviso is not None:
                pie_aviso.configure(text="  ·  ".join(avisos),
                                    fg="#b45309" if avisos else t["texto"])
            if btn_guardar is not None:
                btn_guardar.configure(state="normal")

        def _sin_nivel():
            """Sótanos/semisótanos a los que hay que poner número bajo cero.

            Dos casos, y los dos daban problema:
              · sin número → `int(None)` mataba ANALIZAR nada más abrir.
              · con número POSITIVO heredado de una fila guardada antes (la
                lista queda en disco) → el sótano se ensamblaba por encima
                del piso 1. Solo se corrige si Willy no lo escribió él: lo
                que él pone, manda.
            """
            fuera = []
            for r in filas:
                if _clave_tipo(r["tipo"].get()) not in ("sotano", "semisotano"):
                    continue
                if not r["dxf"].get().strip():
                    continue
                v = (r["nivel"].get() or "").strip()
                if not v:
                    fuera.append(r)
                    continue
                if r.get("tocado_nivel"):
                    continue      # lo escribió él
                try:
                    if float(v) >= 0:
                        fuera.append(r)
                except ValueError:
                    fuera.append(r)
            return fuera

        # ---------- orden ----------
        def _repintar():
            for r in filas:
                r["frame"].pack_forget()
            for r in filas:
                r["frame"].pack(fill="x", pady=(4, 0))

        def _mover(reg, delta):
            i = filas.index(reg)
            j = i + delta
            if 0 <= j < len(filas):
                filas[i], filas[j] = filas[j], filas[i]
                _repintar()

        # ---------- la fila ----------
        def agregar_fila(datos=None):
            datos = datos or {}
            fr = tk.Frame(tabla, bg=t["bg"], highlightthickness=1,
                          highlightbackground=t.get("borde", "#c4c4c4"))
            fr.pack(fill="x", pady=(4, 0))
            linea = tk.Frame(fr, bg=t["bg"])
            linea.pack(fill="x", pady=2)

            reg = {"frame": fr, "adjuntos": [], "capas": datos.get("capas") or [],
                   "tocado_tipo": False, "tocado_nivel": False, "leido": None}

            mov = tk.Frame(linea, bg=t["bg"])
            mov.pack(side="left", padx=(2, 2))
            tk.Button(mov, text="▲", font=("Segoe UI", 6), width=2,
                      command=lambda: _mover(reg, -1)).pack()
            tk.Button(mov, text="▼", font=("Segoe UI", 6), width=2,
                      command=lambda: _mover(reg, 1)).pack()

            reg["tipo"] = tk.StringVar(
                value=_etiq_tipo(datos.get("tipo")
                                 or ("sotano" if datos.get("sotano") else "piso")))
            cb = ttk.Combobox(linea, textvariable=reg["tipo"], state="readonly",
                              width=13, values=[e for e, _c in TIPOS_PLANTA])
            cb.pack(side="left", padx=1)

            def al_cambiar_tipo(_e=None):
                reg["tocado_tipo"] = True
                _cambio_tipo(reg)
            cb.bind("<<ComboboxSelected>>", al_cambiar_tipo)

            reg["dxf"] = tk.StringVar(value=datos.get("dxf", ""))
            reg["datos"] = tk.StringVar(value=datos.get("dxf_datos", "") or "")
            f_l = tk.Frame(linea, bg=t["bg"])
            f_l.pack(side="left", padx=1)
            tk.Entry(f_l, textvariable=reg["dxf"], width=26).pack(side="left")
            tk.Button(f_l, text="📂", font=("Segoe UI", 8),
                      command=lambda: _buscar(reg["dxf"],
                                              "DXF LIMPIO de esta planta")
                      ).pack(side="left")
            f_i = tk.Frame(linea, bg=t["bg"])
            f_i.pack(side="left", padx=1)
            tk.Entry(f_i, textvariable=reg["datos"], width=26).pack(side="left")
            tk.Button(f_i, text="📐", font=("Segoe UI", 8),
                      command=lambda: _buscar(reg["datos"],
                                              "DXF de INFORMACIÓN de esta planta")
                      ).pack(side="left")

            reg["hueco_nivel"] = tk.Frame(linea, bg=t["bg"], width=112)
            reg["hueco_nivel"].pack(side="left", padx=1)
            reg["nivel"] = tk.StringVar(
                value=("" if datos.get("nivel") is None
                       else str(datos.get("nivel"))))
            _rg = datos.get("rango") or []
            reg["desde"] = tk.StringVar(value=str(_rg[0]) if _rg else "")
            reg["hasta"] = tk.StringVar(value=str(_rg[-1]) if _rg else "")
            reg["caja_nivel"] = tk.Frame(linea, bg=t["bg"])
            tk.Label(reg["caja_nivel"], text="Nivel", bg=t["bg"], fg=t["texto"],
                     font=("Segoe UI", 8)).pack(side="left")
            tk.Entry(reg["caja_nivel"], textvariable=reg["nivel"], width=4,
                     justify="center").pack(side="left", padx=2)
            reg["caja_rango"] = tk.Frame(linea, bg=t["bg"])
            tk.Label(reg["caja_rango"], text="del", bg=t["bg"], fg=t["texto"],
                     font=("Segoe UI", 8)).pack(side="left")
            tk.Entry(reg["caja_rango"], textvariable=reg["desde"], width=3,
                     justify="center").pack(side="left", padx=1)
            tk.Label(reg["caja_rango"], text="al", bg=t["bg"], fg=t["texto"],
                     font=("Segoe UI", 8)).pack(side="left")
            tk.Entry(reg["caja_rango"], textvariable=reg["hasta"], width=3,
                     justify="center").pack(side="left", padx=1)

            reg["npt"] = tk.StringVar(
                value=("" if datos.get("npt") is None
                       else f"{float(datos['npt']):+.2f}"))
            tk.Entry(linea, textvariable=reg["npt"], width=7,
                     justify="center").pack(side="left", padx=1)
            reg["losa"] = tk.StringVar(
                # SIN 0.20 ESCRITO EN LA CASILLA (v63). Willy lo veía al
                # agregar una planta y tenía que borrarlo a mano. El espesor
                # sale del corte; si el corte no lo dice, ORA pregunta.
                value=str(datos.get("losa") or datos.get("espesor_losa") or ""))
            tk.Entry(linea, textvariable=reg["losa"], width=6,
                     justify="center").pack(side="left", padx=1)

            def quitar():
                fr.destroy()
                if reg in filas:
                    filas.remove(reg)
                _revisar()
            tk.Button(linea, text="✕", font=("Segoe UI", 8), fg="#b91c1c",
                      command=quitar).pack(side="left", padx=3)

            reg["cinta"] = tk.Label(fr, text="", anchor="w", justify="left",
                                    bg=t["bg"], fg=t["texto"], wraplength=1000,
                                    font=("Segoe UI", 8))
            reg["caja_adj"] = tk.Frame(fr, bg=t["bg"])

            f_mas = tk.Frame(fr, bg=t["bg"])
            f_mas.pack(fill="x", padx=(58, 4), pady=(2, 3))
            tk.Button(f_mas, text="📎 Adjuntar plano a esta planta",
                      font=("Segoe UI", 8),
                      command=lambda: _adjuntar(reg)).pack(side="left")

            for a in (datos.get("adjuntos") or []):
                _adjuntar(reg, a)
            for v in ("nivel", "desde", "hasta"):
                reg[v].trace_add(
                    "write",
                    lambda *a, r=reg: r.update({"tocado_nivel": True}))
            reg["dxf"].trace_add("write", lambda *a: _leer_rotulo(reg))
            reg["datos"].trace_add("write", lambda *a: _revisar())
            filas.append(reg)
            _cambio_tipo(reg)
            if reg["dxf"].get().strip():
                _leer_rotulo(reg)
            return reg

        for p_cfg in (estado["edificio"] or []):
            agregar_fila(p_cfg)
        if not filas:
            agregar_fila()

        pie_aviso = tk.Label(win, text="", bg=t["bg"], fg=t["texto"],
                             anchor="w", justify="left", wraplength=1060,
                             font=("Segoe UI", 9))
        pie_aviso.pack(fill="x", padx=12, pady=(6, 0))

        barra_b = tk.Frame(win, bg=t["bg"])
        barra_b.pack(fill="x", padx=12, pady=10)
        tk.Button(barra_b, text="➕ Agregar planta",
                  command=lambda: agregar_fila()).pack(side="left")

        def releer_todo():
            for r in filas:
                r["leido"] = None
                _leer_rotulo(r)
        tk.Button(barra_b, text="🔄 Volver a leer los rótulos",
                  command=releer_todo).pack(side="left", padx=6)

        def guardar_edificio():
            pisos = []
            for reg in filas:
                dxf = reg["dxf"].get().strip()
                if not dxf:
                    continue
                if not os.path.exists(dxf):
                    messagebox.showwarning("ORA", f"No existe el archivo:\n{dxf}",
                                           parent=win)
                    return
                datos = reg["datos"].get().strip()
                if datos and not os.path.exists(datos):
                    messagebox.showwarning("ORA", f"No existe el archivo:\n{datos}",
                                           parent=win)
                    return

                def num(var, cual):
                    txt = (var.get() or "").strip().replace(",", ".").lstrip("+")
                    if not txt:
                        return None
                    try:
                        return float(txt)
                    except ValueError:
                        raise ValueError(cual)

                def ent(var):
                    txt = (var.get() or "").strip()
                    try:
                        return int(float(txt)) if txt else None
                    except ValueError:
                        return None

                try:
                    npt = num(reg["npt"], "el NPT")
                    losa = num(reg["losa"], "el espesor de losa")
                except ValueError as ex:
                    messagebox.showwarning(
                        "ORA", f"Revisa {ex} de «{os.path.basename(dxf)}»: "
                               "tiene que ser un número.", parent=win)
                    return
                tipo = _clave_tipo(reg["tipo"].get())
                d, h = ent(reg["desde"]), ent(reg["hasta"])
                rango = (list(range(d, h + 1))
                         if (tipo == "tipica" and d is not None
                             and h is not None and h >= d) else None)
                adjuntos = [{"que": _clave_adj(a["que"].get()),
                             "ruta": a["ruta"].get().strip()}
                            for a in reg["adjuntos"] if a["ruta"].get().strip()]
                pisos.append({
                    "nombre": None, "dxf": dxf, "dxf_datos": datos or None,
                    "tipo": tipo,
                    "nivel": (rango[0] if rango else ent(reg["nivel"])),
                    "rango": rango, "npt": npt,
                    # SIN 0.20 DE REGALO (v62). Willy: «elimina el 2.60 y el
                    # 0.20 que vienen por defecto en multifamiliar; eso se lee
                    # de los planos y se confirma». Si la fila no trae medida,
                    # se deja en None y el generador usa la que leyó del corte.
                    "losa": losa,
                    "adjuntos": adjuntos,
                    # compatibilidad con proyectos guardados antes
                    "espesor_losa": losa,
                    "sotano": tipo in ("sotano", "semisotano"),
                    "repeticiones": len(rango) if rango else 1,
                    "z_base_manual": None,
                })
            _firma_anterior_trace = _firma_del_edificio()
            estado["edificio"] = pisos
            _firma_nueva_trace = _firma_del_edificio()
            trace_forense.cambio_proyecto(
                proyecto_anterior=_firma_anterior_trace,
                proyecto_nuevo=_firma_nueva_trace,
                firma_nueva=_firma_nueva_trace,
                archivos_nuevo=[os.path.basename(p.get("dxf") or "")
                                for p in pisos],
                motivo="Guardar edificio (asistente de plantas)")
            _guardar_edificio_en_disco(pisos)
            refrescar_etiqueta_edificio()
            win.destroy()
            if pisos:
                log(f"{len(pisos)} planta(s) cargadas y guardadas. Presiona "
                    "ANALIZAR PLANO y revisa lo que entendí.", "ok")
            else:
                log("Edificio vacío: vuelve al modo de un solo plano.", "warn")

        def limpiar():
            trace_forense.cambio_proyecto(
                proyecto_anterior=_firma_del_edificio(), proyecto_nuevo=None,
                firma_nueva=None, motivo="Quitar edificio (un solo plano)")
            estado["edificio"] = []
            _guardar_edificio_en_disco([])
            refrescar_etiqueta_edificio()
            win.destroy()
            log("Modo edificio desactivado: se analiza un solo plano.", "warn")

        btn_guardar = tk.Button(barra_b, text="Guardar", command=guardar_edificio,
                                bg=t["acento"], fg=t["acento_txt"], relief="flat",
                                padx=18, pady=6, font=("Segoe UI", 10, "bold"))
        btn_guardar.pack(side="right")
        tk.Button(barra_b, text="Quitar edificio (un solo plano)",
                  command=limpiar).pack(side="right", padx=8)
        win._ora_edificio = {"filas": filas, "agregar": agregar_fila,
                             "guardar": guardar_edificio, "revisar": _revisar,
                             "adjuntar": _adjuntar, "mover": _mover,
                             "cambio_tipo": _cambio_tipo,
                             "btn_guardar": btn_guardar, "aviso": pie_aviso,
                             "leer_rotulo": _leer_rotulo}
        root._ora_win_edificio = win
        _revisar()


    def _volver_a_un_piso():
        """Deja el estado exactamente como en un proyecto de un solo plano."""
        edificio["tabla"] = []
        nivel_activo.update({"piso": 0, "modo": "un_piso", "nombre": "",
                             "npt": None, "llegada": None, "cuelga": False,
                             "sobre_terreno": True,
                             "paso_techo": True, "grupo": None})
        # Un plano suelto vuelve a su firma por plano: aquí sí es la correcta.
        motor.firma_memoria = None

    def _detectar_edificio(archivos, archivo_info, solo_informar=False,
                           declarado=None):
        """Lee los planos y dice si es un piso o un edificio (M1).

        Solo LEE: no genera nada. Devuelve el trozo de informe que se
        añade al del análisis, con la evidencia de dónde salió cada dato
        para que Willy confirme o corrija.

        `solo_informar=True` es el CANDADO DEL MODO (v43). Lo usa el camino de
        UN PISO: ahí ORA puede decir «oye, este plano parece de un edificio»,
        pero NO se cambia de modo solo. La puerta de entrada manda: entras a un
        plano suelto y se levanta como plano suelto; para la lógica de varios
        niveles hay que activar «Edificio por pisos». Antes, un plano con
        rótulo «PLANTA TIPICA 2º, 3º, 4º Y 5º» abierto en «1 · Plano» se iba
        solo a modo edificio, y desde ahí la geometría salía dentro de un grupo
        ORA_PISO_2 y la losa colgaba, sin que nadie lo hubiera pedido.
        """
        try:
            from niveles import detectar, tabla_de_ensamble
        except Exception as ex:
            return f"\n\n(no se pudo leer los niveles: {ex})"
        # `archivos` llega de DOS formas: rutas sueltas (un piso) o pares
        # (limpio, información), uno por planta, que es como los manda el modo
        # edificio. El filtro tiene que mirar SOLO la ruta del limpio: pasarle
        # la tupla entera a os.path.exists reventaba con «path should be
        # string, bytes, os.PathLike or integer, not tuple» y el análisis del
        # edificio moría antes de leer un solo plano.
        entradas, vistos = [], set()
        for a in archivos:
            ruta = a[0] if isinstance(a, (tuple, list)) and a else a
            if not ruta or ruta in vistos:
                continue
            if not os.path.exists(str(ruta)):
                continue
            vistos.add(ruta)
            entradas.append(a)
        if not entradas:
            return ""
        try:
            det = detectar(entradas, archivo_info,
                           declarado=declarado or {})
        except Exception as ex:
            return f"\n\n(no se pudo leer los niveles: {ex})"
        if det.get("modo") != "edificio":
            edificio["deteccion"] = det
            _volver_a_un_piso()
            return ""
        if solo_informar:
            # Se avisa, no se cambia nada. El proyecto sigue siendo de un piso.
            edificio["deteccion"] = None
            _volver_a_un_piso()
            _niv = [n for n in (det.get("niveles") or []) if n.get("habitable")]
            _pistas = [e for n in _niv for e in (n.get("evidencia") or []) if e]
            L = ["", "=" * 58, "ESTE PLANO PARECE DE UN EDIFICIO", "=" * 58,
                 f"Lo leído apunta a {det.get('total_niveles')} nivel(es):"]
            L += [f"   · {p}" for p in _pistas[:4]]
            L += ["",
                  "ORA sigue en modo UN PISO, porque es lo que elegiste: este "
                  "plano se levanta solo, como siempre, sin grupo de piso y "
                  "sin losa colgada.",
                  "Si quieres levantarlo por niveles, usa «🏢 Edificio por "
                  "pisos (varios DXF)» y carga una planta por fila."]
            return "\n".join(L)
        # Es un edificio de verdad: se guarda la lectura completa. De aquí
        # sale, para cada nivel, con qué par de planos se analiza
        # (`_aplicar_nivel`). Sin esto la tabla de cotas aparece pero al
        # elegir una planta no hay nada que levantar.
        edificio["deteccion"] = det
        # EL ESPESOR Y EL RELLENO SALEN DEL CORTE (v66)
        #
        # Ya no del campo de «2 · Decisiones»: en multipisos ese campo dejó de
        # existir porque lo que hubiera escrito ahí pisaba lo medido, y ahí
        # nacían los 5 cm de más y las alturas de una planta metidas en otra.
        _rel_npt, esp = {}, None
        try:
            import cotador as _cot
            _archivo_corte = None
            try:
                _archivo_corte = (var_cortes.get() or "").strip() or None
            except Exception:
                pass
            if _archivo_corte:
                _med, _ = _cot.medidas_por_nivel(_archivo_corte)
                for _npt, _f in (_med or {}).items():
                    if _f.get("relleno_piso") is not None:
                        _rel_npt[float(_npt)] = float(_f["relleno_piso"])
                    if esp is None and _f.get("espesor_losa") is not None:
                        esp = float(_f["espesor_losa"])
        except Exception as _e_rel:
            log(f"No pude medir el corte para la tabla: {_e_rel}", "warn")
        if esp is None:
            esp = 0.20
        edificio["tabla"] = tabla_de_ensamble(det, esp, _rel_npt)
        L = ["", "=" * 58, "EDIFICIO DETECTADO — confirma antes de seguir",
             "=" * 58,
             f"{det['total_niveles']} niveles. Referencia del ensamble: "
             f"{det.get('referencia')} (no se mueve)."]
        for n in det.get("niveles") or []:
            if not n.get("habitable"):
                continue
            L.append("")
            L.append(f"· {n.get('rotulo') or n['nombre']}")
            for e in n.get("evidencia") or []:
                L.append(f"    {e}")
            if n.get("npt") is not None:
                L.append(f"    NPT {n['npt']:+.2f} — {n.get('npt_evidencia','')}")
            if n.get("rango") and len(n["rango"]) > 1:
                L.append(f"    planta típica, niveles {n['rango']}")
            L.append(f"    alineación: {(n.get('desfase') or {}).get('evidencia','')}")
            _t = [l for l in (n.get("losas") or []) if l.get("rol") == "techo"]
            L.append("    paso de Techo: "
                     + (f"sí, {len(_t)} techo(s) sin nivel encima"
                        if _t else "no — su techo es el piso del nivel de arriba"))
        L.append("")
        L.append(f"Cotas de cada nivel (losa {esp:.2f} m):")
        for f in edificio["tabla"]:
            _n = f"{f['npt']:+.2f}" if f.get("npt") is not None else "?"
            _l = f"{f['llegada']:.2f}" if f.get("llegada") is not None else "—"
            _a = (f"{f['altura_libre']:.2f}"
                  if f.get("altura_libre") is not None else "—")
            L.append(f"   nivel {f['nivel']:>2}   NPT {_n}   llegada {_l}"
                     f"   libre {_a}")
        if det.get("dudas"):
            L.append("")
            L.append("Por revisar:")
            for d in det["dudas"]:
                L.append(f"   · {d}")
        L.append("")
        L.append("Cada planta se levanta EN SU SITIO y en su propio grupo "
                 "(ORA_PISO_n). El ensamble viene después.")
        return "\n".join(L)

    def analizar():
        if estado["edificio"]:
            return analizar_edificio_ahora()
        archivo = var_archivo.get().strip()
        if not archivo or not os.path.exists(archivo):
            messagebox.showwarning("ORA", "Elige primero un archivo DXF válido.")
            return
        btn_analizar.configure(state="disabled")
        log("Analizando el plano...", "warn")

        def trabajo():
            try:
                cuadro = None
                if os.path.exists("salidas/cuadro_vanos_manual.json"):
                    with open("salidas/cuadro_vanos_manual.json",
                              encoding="utf-8") as f:
                        cuadro = json.load(f)
                specs = var_specs.get().strip() or None
                cortes = var_cortes.get().strip() or None
                # Proyecto nuevo = mesa limpia: se borra todo rastro de la
                # sesión anterior. Antes, al activar la sincronización en un
                # SketchUp recién abierto, se cargaba el modelo del proyecto
                # pasado porque su "pulso" seguía en el disco.
                try:
                    from sincronizacion_vivo import limpiar_todo_el_puente
                    limpiar_todo_el_puente()
                    try:
                        import evidencia as _ev
                        _ev.olvidar_cache()   # planos del proyecto anterior
                    except Exception:
                        pass
                    estado_vivo.clear()
                    ultimo_estado_txt["v"] = None
                    ultima_seleccion["txt"] = None
                    seleccion_actual["nombre"] = None
                    # ---- TRACE: "mesa limpia" de un proyecto de un solo --
                    # plano. Es el equivalente, en este modo, del cambio de
                    # proyecto que en modo edificio pasa por guardar_edificio/
                    # limpiar(). Willy pidió poder demostrar si un proyecto B
                    # llega a usar datos del proyecto A: esto deja marcado el
                    # instante exacto en que ORA declaró "empiezo de cero".
                    trace_forense.cambio_proyecto(
                        proyecto_anterior=None, proyecto_nuevo=archivo,
                        firma_nueva=None, archivos_nuevo=[archivo],
                        motivo="Analizar plano (un solo DXF)")
                except Exception:
                    pass
                r = motor.analizar(archivo, var_unidad.get(), cuadro,
                                   archivo_specs=specs, archivo_cortes=cortes)
                informe = motor.informe()
                # CANDADO DEL MODO (v43). Aquí estamos en el camino de UN
                # PISO: si el rótulo huele a edificio se DICE en el informe,
                # pero no se cambia nada. Para levantar por niveles hay que
                # entrar por «Edificio por pisos». La puerta de entrada manda.
                informe += _detectar_edificio([archivo], specs,
                                              solo_informar=True)

                def al_terminar():
                    _recuperar_subtipos()
                    _aplicar_sugerencias_corte(r)
                    _pintar_medido(r)
                    mostrar_informe(informe)
                    esc = r.get("escalera")
                    # El cuestionario de escalera SOLO aparece si el plano NO
                    # trae los peldaños dibujados. Si están dibujados, la forma
                    # ya es real y lo único que se pregunta es la contrahuella,
                    # en su propio paso del asistente.
                    if esc and not esc.get("real"):
                        var_esc_pasos.set(str(esc["pasos"] + 1))
                        p_esc.pack(fill="x", pady=(0, 8), before=p3)
                    else:
                        p_esc.pack_forget()
                    if esc:
                        var_esc.set(True)
                    montar_cuadro_manual(r.get("vanos_incompletos") or [],
                                         r.get("vanos_para_cuadro") or [])
                    btn_generar.configure(state="normal")
                    # Ya hay plano: EN VIVO deja de estar apagado.
                    btn_vivo.configure(state="normal")
                    _mostrar_selector_planta()
                    if edificio["tabla"]:
                        _aplicar_nivel(edificio["tabla"][0]["nivel"])
                    for clave in estado_fases:
                        estado_fases[clave] = False
                    paso_actual["i"] = 0
                    paso_actual["enviado"] = False
                    refrescar_fases()
                    _esc = r.get("escalera") or {}
                    if _esc.get("real"):
                        log(f"🪜 {_esc['pasos']} peldaños reales leídos del plano "
                            "(no se inventa la escalera).", "ok")
                    _avisos = r.get("alertas_npt") or []
                    if _avisos:
                        log(f"⚠️ {len(_avisos)} muro(s) apoyados en ambientes con NPT "
                            "distinto de 0.00: revisa el informe.", "warn")
                    _c = r.get("cortes") or {}
                    if _c.get("cortes_leidos"):
                        log("✂️ Cortes leídos: " + ", ".join(
                            f"{k}={v} m" for k, v in _c["cortes_leidos"].items()), "ok")
                    if getattr(motor, "nota_cruce", ""):
                        log(motor.nota_cruce, "ok")
                    _cc = r.get("clasificacion_capas") or {}
                    _pend = _cc.get("pendientes") or []
                    if _pend:
                        ficha_registro_capas(_pend, _cc.get("firma"),
                                             al_confirmar=lambda: analizar())
                    ndudas = len(r.get("dudas") or [])
                    log(f"Análisis listo: {r['muros']} muros, "
                        f"{r['puertas'] + r['ventanas']} vanos, "
                        f"{r['columnas']} columnas"
                        + (f" — {ndudas} duda(s), revisa el informe" if ndudas else ""),
                        "warn" if ndudas else "ok")
                    btn_analizar.configure(state="normal")
                root.after(0, al_terminar)
            except Exception as ex:
                trace_forense.excepcion(
                    ex, funcion="analizar():trabajo",
                    motor_piso_activo=getattr(motor, "piso_activo", None),
                    nivel_activo_piso=nivel_activo.get("piso"),
                    modo=nivel_activo.get("modo"), archivo=archivo)
                root.after(0, lambda _m=str(ex): (
                    messagebox.showerror("ORA", f"Error al analizar:\n{_m}"),
                    btn_analizar.configure(state="normal"),
                    log("Error en el análisis.", "warn")))
        threading.Thread(target=trabajo, daemon=True).start()

    def analizar_edificio_ahora():
        """EDIFICIO: se lee TODO, se levanta UNA planta a la vez.

        Antes esto llamaba a `apilar_pisos.apilar()`, que calcula las cotas
        sumando altura+losa nivel a nivel y lo genera todo de un tirón. Ese
        camino no pasaba nunca por `niveles.py` ni por `nivel_activo`, así que
        el grupo por piso, la cota de llegada y la losa que cuelga se quedaban
        dormidos aunque estuvieran implementados.

        Ahora: se detectan los niveles con su evidencia, se arma la tabla de
        cotas, y se analiza SOLO la planta activa — cada una en su sitio, con
        su propio DXF de información. El apilado llega al final, con el botón
        de Ensamblar, moviendo grupos.
        """
        btn_analizar.configure(state="disabled")
        log("Leyendo las plantas del edificio...", "warn")

        def trabajo():
            try:
                # Cada piso con SU DXF de información (decisión de Willy: así
                # se aíslan las fallas). Si alguno no lo trae, se usa el de
                # «2 · DXF DE DATOS» como respaldo.
                comun = var_specs.get().strip() or None
                pares, declarado = [], {}
                bajo_nivel.clear()
                for p_cfg in (estado["edificio"] or []):
                    limpio = (p_cfg.get("dxf") or "").strip()
                    if not limpio:
                        continue
                    pares.append((limpio, (p_cfg.get("dxf_datos") or comun)))
                    # LO QUE WILLY DECLARÓ EN LA TABLA MANDA sobre el rótulo.
                    d = {"clase": p_cfg.get("tipo") or None,
                         "nivel": p_cfg.get("nivel"),
                         "rango": p_cfg.get("rango") or None,
                         "npt": p_cfg.get("npt"),
                         "losa": p_cfg.get("losa")}
                    for adj in (p_cfg.get("adjuntos") or []):
                        ruta_a = (adj.get("ruta") or "").strip()
                        if not ruta_a or not os.path.exists(ruta_a):
                            continue
                        if adj.get("que") == "techos":
                            d["techos"] = ruta_a
                        elif adj.get("que") == "cisterna":
                            # El adjunto de cisterna no crea un nivel: da la
                            # PROFUNDIDAD del recinto que ya está dibujado
                            # dentro de esta planta. La geometría no se toca.
                            try:
                                from niveles import leer_bajo_nivel
                                b = leer_bajo_nivel(ruta_a)
                            except Exception:
                                b = {}
                            if b:
                                bajo_nivel[os.path.basename(limpio)] = b
                    declarado[limpio] = {k: v for k, v in d.items()
                                         if v not in (None, "")}
                if not pares:
                    raise RuntimeError("No hay ningún DXF limpio en la lista "
                                       "de pisos.")
                texto = _detectar_edificio(pares, comun, declarado=declarado)

                def al_terminar():
                    if not edificio["tabla"]:
                        mostrar_informe(
                            "No pude reconocer varios niveles en esos planos."
                            + (texto or "")
                            + "\n\nRevisa que cada DXF traiga su rótulo "
                              "(«PLANTA PRIMER PISO», «PLANTA TIPICA 2º…») o "
                              "el piso en el nombre de las capas.")
                        btn_analizar.configure(state="normal")
                        return
                    _mostrar_selector_planta()
                    log(f"{len(edificio['tabla'])} nivel(es) detectados. "
                        "Se levanta una planta a la vez; el apilado va al "
                        "final con «Ensamblar edificio».", "ok")
                    # Se arranca por la planta más baja y se analiza SU plano.
                    _aplicar_nivel(edificio["tabla"][0]["nivel"],
                                   analizar=True, cabecera=texto)
                    btn_analizar.configure(state="normal")
                root.after(0, al_terminar)
            except Exception as ex:
                root.after(0, lambda _m=str(ex): (
                    messagebox.showerror("ORA", f"Error al leer el edificio:\n{_m}"),
                    btn_analizar.configure(state="normal"),
                    log("Error al leer el edificio.", "warn")))
        threading.Thread(target=trabajo, daemon=True).start()

    def _construir_decisiones():
        return {
            "altura_muro": _medida_decidida(var_altura, "altura_muro", 2.60),
            "espesor_losa": _medida_decidida(var_losa, "espesor_losa", 0.20),
            "carpinteria": bool(var_carp.get()),
            "escalera": bool(var_esc.get()) and bool(motor.resumen.get("escalera")),
            "esc_tipo": var_esc_tipo.get(),
            "esc_pasos": int(float(var_esc_pasos.get() or 16)),
            "esc_ancho": float(var_esc_ancho.get().replace(",", ".") or 1.0),
            "esc_descanso": bool(var_esc_desc.get()) or var_esc_tipo.get() in ("L", "U"),
            "esc_lado": var_esc_lado.get(),
            "esc_pasos_tramo2": int(float(var_esc_pasos2.get() or 0)),
            "esc_contrahuella": float(str(var_contrahuella.get()).replace(",", ".") or 0.15),
            "esc_invertir": bool(var_invertir.get()),
            "altura_desde_npt": var_altura_desde.get().startswith("NPT"),
            # NIVEL ACTIVO (modo edificio). En modo un piso va todo a cero y
            # el motor se comporta exactamente igual que siempre.
            "nivel": dict(nivel_activo),
            "cota_llegada": nivel_activo.get("llegada"),
            "alturas_subtipo": dict(subtipos_declarados),
            # Modo de medición y losa YA CONFIRMADA en SketchUp: la escalera
            # tiene que llegar al piso de arriba REAL, no al genérico de
            # «2 · Decisiones». Si Willy dejó los muros en 2.75 y la losa quedó
            # de 2.75 a 2.95, la subida desde NPT +0.15 es 2.80 — y de ahí
            # salen los 0.175 de contrahuella.
            "altura_desde": ("npt" if var_altura_desde.get().startswith("NPT")
                             else "piso"),
            # Bloque 5: si el plano no trae contexto, estos campos mandan.
            "esc_npt": _num_o(var_esc_npt, None),
            "esc_llegada": _num_o(var_esc_llegada, None),
            # Cada losa confirmada con su NOMBRE, para poder emparejarla con
            # la huella del análisis. Sin la huella no se sabe QUÉ losa es, y
            # entonces no se puede decir qué viga va debajo de cuál.
            # LO CONFIRMADO MANDA — también en vigas. Se pasa lo que el
            # usuario dejó guardado para que el recorte se aplique SOBRE eso
            # y no sobre la viga del DXF.
            "vigas_confirmadas": {
                n: v for n, v in (_medidas_confirmadas() or {}).items()
                if "VG" in n or "Viga" in n},
            # LO ACEPTADO MANDA TAMBIÉN AQUÍ. Cuando el asistente llega a
            # Vigas, los muros ya se confirmaron en el paso 1 con su altura
            # real medida. El recorte de la viga tiene que leer ESA altura, no
            # recalcularla: si no, usa el relleno del kernel y borra la viga
            # entera donde pasa un muro, en vez de reducirla.
            "muros_confirmados": {
                n: v for n, v in (_medidas_confirmadas() or {}).items()
                if _RE_MURO.match(str(n))},
            # Las losas salen de lo CONGELADO, y lo que llegue en vivo solo
            # completa. Antes salían únicamente de `estado_vivo`: si el pulso
            # no traía nada en ese momento, la viga caía en la cota genérica
            # en vez de la que el usuario ya había aceptado.
            "techos_confirmados": _techos_confirmados(),
        }

    _RE_MURO = re.compile(r"^(ORA_)?M\d+$", re.I)

    def _techos_confirmados():
        """Cada losa con su cota real: primero la congelada, luego la viva."""
        salida = {}
        for n, v in (_medidas_confirmadas() or {}).items():
            if "Techo" in n and (v.get("alto") or 0) > 0:
                salida[n] = {"nombre": n, "z": v.get("z", 0),
                             "alto": v.get("alto", 0)}
        for n, v in (estado_vivo or {}).items():
            if "Techo" in n and (v.get("alto") or 0) > 0:
                salida[n] = {"nombre": n, "z": v.get("z", 0),
                             "alto": v.get("alto", 0)}
        return list(salida.values())

    def _medidas_confirmadas():
        """Lo que el usuario confirmó en SketchUp para el plano actual.

        Es la fuente de «lo confirmado manda»: mismo sitio del que ya beben
        muros, columnas y techo. Aquí se expone para que las vigas también lo
        respeten en vez de regenerarse desde el DXF.
        """
        try:
            from memoria_elementos import congelados_de
            f = _firma_actual()
            if not f:
                return {}
            return congelados_de(f, getattr(motor, "piso_activo", 0)) or {}
        except Exception:
            return {}

    def _num_o(var, defecto=None):
        """Número de un campo de texto, o `defecto` si está vacío o mal escrito."""
        try:
            t = str(var.get()).strip().replace(",", ".")
            return float(t) if t else defecto
        except (ValueError, AttributeError):
            return defecto

    def _inventario():
        """Cuántos elementos hay de cada tipo, para saber qué pasos aplican."""
        r = motor.resumen or {}
        m = motor.kernel.to_dict() if motor.kernel else {"entities": {}}
        ents = list(m.get("entities", {}).values())

        def _n(tipo, sub=None):
            return sum(1 for e in ents if e.get("type") == tipo
                       and (sub is None
                            or (e.get("properties") or {}).get("subtipo") == sub))
        return {
            "muros_pisos": _n("wall") + _n("slab", "piso"),
            "vanos": _n("door") + _n("window"),
            "columnas": _n("column"),
            # ---- v85 · LOS TECHOS SE CUENTAN DEL PLANO, NO DEL 3D --------
            # Antes decía `_n("slab", "techo")`: contaba las losas YA
            # CONSTRUIDAS. Y era una trampa cerrada, porque una losa de techo
            # solo se construye cuando corres el paso Techo... y el paso
            # Techo solo aparecía si ya había losas construidas. Nunca podía
            # aparecer.
            #
            # Willy: el piso 1 trae `ORA_TECHO EXTERIOR PISO 1` con TRES
            # polilíneas (los voladizos de la cochera) — el propio código las
            # menciona por su nombre unas líneas más abajo — y nunca se
            # levantaban. Su consola del piso 1 iba Muros, Vanos, Columnas,
            # Vigas, Escalera: ni rastro de Techo.
            #
            # Se cuentan los DECLARADOS por capa (`declarado: True`, que ya se
            # marca al leer el DXF), no todos los del resumen: cuando el plano
            # no trae capa de techo, ORA rellena una huella de respaldo con la
            # unión de muros y columnas, y contarla haría aparecer el paso en
            # TODAS las plantas. Con esto:
            #     piso 1  -> 3 declarados -> el paso aparece
            #     típica  -> 0            -> sigue oculto, como debe
            #     azotea  -> declarados   -> igual que hasta ahora
            # Es el mismo criterio que ya se usa dos líneas más abajo para las
            # vigas: cuenta lo LEÍDO del plano, no lo generado.
            "techo": (sum(1 for t in (r.get("techos") or [])
                          if isinstance(t, dict) and t.get("declarado"))
                      or _n("slab", "techo")),
            # Cuenta las LEÍDAS del plano, no las generadas: una viga sin
            # peralte todavía no existe en 3D pero el paso tiene que aparecer
            # igual — es justo ahí donde se escribe el peralte que falta.
            "vigas": len(r.get("vigas") or []),
            "escalera": (len(r.get("escaleras") or [])
                         or (1 if r.get("escalera") else 0)),
        }

    # Pasos que el usuario forzó a mostrar aunque ORA no detectara nada.
    # Es la válvula de escape para cuando la ausencia NO es real sino un fallo
    # de detección (una capa con nombre raro que no entró en el catálogo).
    fases_forzadas = set()

    def _pintar_lista_vigas():
        """Rellena la lista de vigas con su capa, su largo y su peralte."""
        for w in lista_vigas.winfo_children():
            w.destroy()
        marcas_vigas.clear()
        vgs = (getattr(motor, "resumen", None) or {}).get("vigas") or []
        if not vgs:
            tk.Label(lista_vigas, text="  (este plano no trae vigas)",
                     font=("Segoe UI", 8), fg="#64748b").pack(anchor="w")
            return
        for vg in vgs:
            nom = vg.get("nombre") or "?"
            per = vg.get("peralte")
            fr = tk.Frame(lista_vigas)
            fr.pack(fill="x")
            v = tk.BooleanVar(value=per in (None, 0))
            marcas_vigas[nom] = v
            tk.Checkbutton(fr, variable=v).pack(side="left")
            txt = (f"{nom}  ·  {vg.get('largo', 0):.2f} m"
                   + (f"  ·  peralte {per:.2f}" if per else "  ·  SIN PERALTE"))
            lb = tk.Label(fr, text=txt, font=("Segoe UI", 8), anchor="w",
                          cursor="hand2",
                          fg=("#b45309" if not per else "#1a1a1a"))
            lb.pack(side="left", fill="x", expand=True)
            lb.bind("<Double-Button-1>",
                    lambda _e, _n=nom: _ventana_evidencia(
                        f"{_n} — evidencia en los planos",
                        poly=_contorno_de_viga(_n), nombre=_n))

    def _aplicar_peralte_lote():
        """Escribe el mismo peralte en todas las vigas marcadas."""
        try:
            val = float(str(var_peralte_lote.get()).replace(",", "."))
        except (TypeError, ValueError):
            log("Escribe el peralte como 0.40 antes de aplicarlo.", "warn")
            return
        if not (0.05 <= val <= 3.0):
            log(f"{val} m no parece un peralte de viga.", "warn")
            return
        marcadas = [n for n, v in marcas_vigas.items() if v.get()]
        if not marcadas:
            log("No has marcado ninguna viga.", "warn")
            return
        n = 0
        for vg in ((getattr(motor, "resumen", None) or {}).get("vigas") or []):
            _nom = str(vg.get("nombre") or "")
            # UNA VIGA CORTADA EN TRAMOS SIGUE SIENDO ESA VIGA (v56).
            # En la lista de lote aparece «VG01», pero al pasar por muros y
            # columnas se parte en `VG01_1`, `VG01_2`, `VG01_3`… Comparando
            # el nombre exacto solo se marcaba el tramo que casualmente se
            # llamara igual, y los demás seguían sin peralte: Willy escribía
            # 0.50, ORA decía «aplicado a 6 vigas» y luego el paso avisaba de
            # 20 vigas sin peralte y no levantaba ninguna.
            _base = _nom.split("_")[0] if "_" in _nom else _nom
            if _nom in marcadas or _base in marcadas:
                vg["peralte"] = round(val, 4)
                vg["peralte_asumido"] = False
                vg["fuente_peralte"] = "escrito por ti (en lote)"
                n += 1
        # SE GUARDA, no solo se escribe en memoria volátil (v57). Al cambiar
        # de paso o de piso ORA vuelve a analizar el plano y reconstruye
        # `resumen` desde el DXF: sin esto, el peralte se borraba y el paso de
        # Vigas no levantaba ni una.
        try:
            from memoria_elementos import guardar_peraltes
            guardar_peraltes(_firma_actual(), _piso_actual(),
                             {nom: val for nom in marcadas})
        except Exception:
            pass
        log(f"Peralte {val:.2f} m aplicado a {n} viga(s). Queda guardado.", "ok")
        _pintar_lista_vigas()
        refrescar_fases()
        # ---- v83 · Y AHORA SE VUELVE A LEVANTAR, QUE ES DONDE WILLY MIRA --
        # Willy: «yo puse 0.50 y mira, en la selección múltiple aparece 0.30,
        # no modificó lo que puse». Tenía razón, y el dato no se perdía: se
        # escribía SOLO en `resumen["vigas"]` (la lista de aquí al lado, que
        # por eso sí decía 0.50). La TABLA de elementos no lee de ahí — lee
        # las vigas que ya están levantadas, y esas seguían con el peralte
        # viejo porque nadie las volvió a generar.
        #
        # En la azotea sí funcionó, y no es casualidad: ahí escribió el
        # peralte ANTES de levantar la viga, así que al levantarla ya cogió
        # el 0.50.
        #
        # No se copia el cálculo del peralte a un segundo sitio —eso es lo
        # que provoca justo este tipo de líos—: se vuelve a mandar el paso,
        # que es el mismo camino de siempre. `generar_vigas` recalcula el
        # recorte contra muros y losa con la medida nueva, y al terminar la
        # tabla se repuebla sola. Si estás en la previa salen enteras; si ya
        # las recortaste, se recortan otra vez. Igual que si lo pulsaras tú.
        if n:
            try:
                paso_actual["enviado"] = False
                enviar_paso_actual()
            except Exception as e:
                log(f"El peralte quedó guardado, pero no pude volver a "
                    f"levantar las vigas solo ({e}). Pulsa el paso otra vez.",
                    "warn")

    def _pasos_del_nivel():
        """Qué pasos tiene sentido enseñar en la planta activa.

        Willy, sobre su sótano de cisterna: «obviamente va a tener sus propios
        pasos, nada más esa parte de sótano, con solo los elementos que
        aparezcan». Su DXF de cisterna trae exactamente dos capas —muro y
        piso—, así que preguntarle por vanos, vigas o escalera es hacerle
        perder el tiempo con pasos vacíos.
        """
        cl = str((edificio.get("deteccion") or {}).get("clase_activa") or "")
        if not cl:
            for n in ((edificio.get("deteccion") or {}).get("niveles") or []):
                if n.get("nivel") == nivel_activo.get("piso"):
                    cl = str(n.get("clase") or "")
                    break
        if cl in ("sotano", "semisotano"):
            return {"muros_pisos"}
        return None      # None = todos

    def _fase_disponible():
        """Fases que aplican a ESTE plano.

        El asistente era estático: siempre los 5 pasos, aunque el plano no
        trajera nada de esa categoría. Con un DXF de escalera sola había que
        confirmar cuatro pantallas vacías antes de llegar a lo único que había.
        Ahora se salta lo que está en cero — salvo que el usuario lo fuerce
        (ver `fases_forzadas`), porque un cero también puede ser un fallo de
        detección y no una ausencia real.
        """
        if not motor.resumen:
            return [(c, e) for c, e in FASES]
        _solo = _pasos_del_nivel()
        if _solo:
            return [(c, e) for c, e in FASES if c in _solo]
        inv = _inventario()
        fases = []
        for clave, etiqueta in FASES:
            # EDIFICIO: el techo de un nivel es el piso del que está encima,
            # así que la mayoría de plantas NO tienen paso de Techo. Solo lo
            # tienen las que traen alguna losa sin nivel encima: la azotea, y
            # los voladizos del piso 1 (los tres de la cochera). Se salta el
            # paso en vez de enseñar una pantalla vacía.
            if (clave == "techo" and nivel_activo.get("modo") == "edificio"
                    and not nivel_activo.get("paso_techo")
                    and clave not in fases_forzadas):
                continue
            if inv.get(clave, 0) > 0 or clave in fases_forzadas:
                fases.append((clave, etiqueta))
        # Si no quedara ninguna (plano vacío o todo sin reconocer), se muestran
        # todas: mejor una pantalla de más que dejar al usuario sin salida.
        return fases or [(c, e) for c, e in FASES]

    def _fases_ocultas():
        """Pasos que se saltaron por estar en cero, para poder forzarlos."""
        if not motor.resumen:
            return []
        inv = _inventario()
        return [(c, e, inv.get(c, 0)) for c, e in FASES
                if inv.get(c, 0) == 0 and c not in fases_forzadas]

    def forzar_fase(clave):
        """Mostrar un paso aunque ORA no haya detectado nada de esa categoría."""
        fases_forzadas.add(clave)
        log(f"Se mostrará el paso «{dict(FASES).get(clave, clave)}» aunque no se "
            "detectó nada. Si el plano SÍ lo trae, revisa el nombre de la capa.",
            "warn")
        refrescar_fases()

    # Lo que el usuario escribe A MANO, por planta. La medida del corte es
    # por planta; lo escrito a mano también tiene que serlo.
    _altura_mano = {}

    def _clave_planta():
        return (int(nivel_activo.get("piso") or 0)
                if nivel_activo.get("modo") == "edificio" else 0)

    def _recordar_altura_mano(*_a):
        _k = _clave_planta()
        _altura_mano.setdefault(_k, {})
        for _c, _v in (("altura_muro", var_altura), ("espesor_losa", var_losa)):
            _t = (_v.get() or "").strip()
            if _t:
                _altura_mano[_k][_c] = _t

    def _aplicar_sugerencias_corte(resumen):
        """Rellena la altura de muro y el espesor de losa con lo que dice el
        plano, no con un valor de fábrica (v61).

        Solo escribe en un campo que esté VACÍO: si el usuario ya puso una
        medida a mano, esa manda. Y siempre dice de dónde salió el número.
        """
        sug = (resumen or {}).get("sugerencias_corte") or {}
        if not sug:
            return
        if nivel_activo.get("modo") == "edificio":
            # En multipisos las casillas no existen: nada que rellenar.
            return
        for clave, var, etiqueta in (("altura_muro", var_altura,
                                      "Altura de muros"),
                                     ("espesor_losa", var_losa,
                                      "Espesor de losa")):
            dato = sug.get(clave)
            if not dato:
                continue
            # UNA ALTURA POR PLANTA (v66)
            #
            # Willy: «me sale 1.55 en el piso 1». Cierto: la casilla es una
            # sola para todo el edificio y solo se escribía si estaba VACÍA.
            # Se analizaba la cisterna, entraba su 1.55, y todas las plantas
            # siguientes heredaban el valor del sótano.
            #
            # Ahora la casilla MUESTRA la de la planta que estás mirando. Solo
            # se respeta lo que escribiste TÚ para ESTA planta.
            _mio = (_altura_mano.get(_clave_planta()) or {}).get(clave)
            if _mio:
                var.set(_mio)
                log(f"📐 {etiqueta}: {_mio} m — lo que escribiste para esta "
                    f"planta.", "ok")
                continue
            var.set(f"{dato['valor']:.2f}")
            log(f"📐 {etiqueta}: {dato['valor']:.2f} m — leído del corte "
                f"(aparece {dato['veces']} veces). Cámbialo si no es.", "ok")

    def refrescar_fases():
        """Dibuja el paso ACTUAL del asistente. Uno a la vez: así no te saltas
        ninguno ni te confunde una pantalla llena de opciones."""
        fases = _fase_disponible()
        rapido = bool(var_rapido.get())
        hay_plano = bool(motor.resumen)
        # El cartel del nivel se repinta SIEMPRE, pase lo que pase después:
        # en cualquier paso, en cualquier rama, tiene que decir dónde estás.
        try:
            _pintar_nivel_grande()
        except Exception:
            pass

        if rapido:
            lbl_progreso.configure(text="Modo rápido")
            lbl_paso.configure(text="Todo de una vez")
            lbl_ayuda.configure(text="Se genera el modelo completo sin revisar por "
                                     "partes. Úsalo solo si ya conoces el plano.")
            fr_esc_paso.pack_forget()
            fr_confirmar.pack_forget()
            fr_avisos.pack_forget()
            fr_previa.pack_forget()
            btn_enviar_paso.configure(
                text="🏗️  GENERAR TODO", state=("normal" if hay_plano else "disabled"),
                command=lambda: aplicar_en_vivo())
            btn_atras.configure(state="disabled")
            return

        i = min(paso_actual["i"], len(fases))
        if not fases:
            lbl_progreso.configure(text="")
            lbl_paso.configure(text="Analiza un plano para empezar")
            lbl_ayuda.configure(text="")
            btn_enviar_paso.configure(text="—", state="disabled")
            fr_confirmar.pack_forget()
            fr_esc_paso.pack_forget()
            return

        if i >= len(fases):        # terminó el asistente
            lbl_progreso.configure(text=_rotulo_progreso(len(fases), len(fases)))
            lbl_paso.configure(text="✅ Modelo completo")
            hechas = sum(1 for c, _ in fases if estado_fases.get(c))
            lbl_ayuda.configure(text=f"{hechas} de {len(fases)} pasos confirmados. "
                                     "Ya puedes seguir ajustando a mano en SketchUp: "
                                     "ORA sigue escuchando y aprende al guardar.")
            fr_esc_paso.pack_forget()
            fr_confirmar.pack_forget()
            # LA CADENA POR PISOS. Terminados los 6 pasos de una planta, en
            # un edificio queda la siguiente. Antes ponía «Modelo completo» y
            # ahí moría: Willy terminaba el piso 1 y no tenía por dónde
            # seguir, ni un mensaje que se lo dijera.
            _sig = _siguiente_nivel()
            if _sig:
                lbl_paso.configure(text=f"✅ Piso {nivel_activo.get('piso')} "
                                        "terminado")
                lbl_ayuda.configure(
                    text=f"Los {len(fases)} pasos de este piso están "
                         f"confirmados. Sigue el {_sig['etiqueta']}.")
                btn_enviar_paso.configure(
                    text=f"▶  Pasar al {_sig['etiqueta']}", state="normal",
                    command=lambda n=_sig["nivel"]: (
                        paso_actual.update(i=0, enviado=False),
                        _aplicar_nivel(n, analizar=True,
                                       cabecera=f"── {_sig['etiqueta']} ──")))
            else:
                btn_enviar_paso.configure(text="↺ Empezar de nuevo", state="normal",
                                          command=lambda: (paso_actual.update(i=0, enviado=False),
                                                           refrescar_fases()))
            btn_atras.configure(state="normal")
            return

        clave, etiqueta = fases[i]
        lbl_progreso.configure(text=_rotulo_progreso(i + 1, len(fases)))
        lbl_paso.configure(text=etiqueta)
        lbl_ayuda.configure(text=AYUDA_FASE.get(clave, ""))
        btn_atras.configure(state=("normal" if i > 0 else "disabled"))

        # PASOS SALTADOS: se listan con su botón para forzarlos. Un cero puede
        # ser una ausencia real (un plano de escalera sola no trae muros) o un
        # fallo de detección (capa con nombre fuera del catálogo). Ocultarlo sin
        # avisar escondería el error junto con el paso.
        for _w in fr_saltados.winfo_children():
            _w.destroy()
        _ocultas = _fases_ocultas()
        if _ocultas:
            tk.Label(fr_saltados, font=("Segoe UI", 8, "bold"), justify="left",
                     text=f"⏭ {len(_ocultas)} paso(s) saltado(s): el plano no "
                          "trae nada de eso.").pack(anchor="w")
            tk.Label(fr_saltados, font=("Segoe UI", 7), justify="left",
                     wraplength=260,
                     text="Si crees que sí los trae, la capa puede tener un "
                          "nombre que ORA no reconoce. Muéstralo y revisa."
                     ).pack(anchor="w")
            for _c, _e, _n in _ocultas:
                tk.Button(fr_saltados, text=f"Mostrar «{_e}» igual ({_n})",
                          font=("Segoe UI", 7), cursor="hand2",
                          command=lambda k=_c: forzar_fase(k)
                          ).pack(anchor="w", pady=1)
            fr_saltados.pack(fill="x", pady=(4, 0))
        else:
            fr_saltados.pack_forget()

        # El paso de escalera muestra su propia pregunta (la contrahuella)
        if clave == "escalera":
            # DE DÓNDE ARRANCA: se muestra SIEMPRE, antes de generar nada.
            # Si ORA lo leyó del plano, lo dice y de qué ambiente. Si no pudo,
            # lo dice también y pide el dato. Nunca se decide en silencio ni
            # queda escondido en un aviso al final.
            _r = motor.resumen or {}
            _escs = (_r.get("escaleras")
                     or ([_r["escalera"]] if _r.get("escalera") else []))
            _arr = (_escs[0].get("arranque") or {}) if _escs else {}
            _npt_plano = _arr.get("npt")
            if _arr.get("sin_cruce") or _npt_plano is None:
                lbl_esc_origen.configure(
                    text="⚠️ No se pudo leer de qué NPT arranca: ningún "
                         "extremo de la escalera cae en un ambiente rotulado "
                         "del plano. Escríbelo abajo antes de generar.",
                    fg="#b00020")
            else:
                _amb = _arr.get("ambiente")
                lbl_esc_origen.configure(
                    text=(f"Arranca en NPT {float(_npt_plano):+.3f} m"
                          + (f" — leído del ambiente {_amb} del plano."
                             if _amb else " — leído del plano.")
                          + " Cámbialo abajo solo si está mal."),
                    fg="#1F3C51")
            fr_esc_contexto.grid(row=2, column=0, columnspan=2,
                                 sticky="we", pady=(2, 0))
            # ORA la PROPONE sola, con la altura ya confirmada en los pasos
            # anteriores. Si el usuario la cambia a mano, se respeta: solo se
            # recalcula mientras siga en el valor de fábrica o vacía.
            try:
                _ch_txt = str(var_contrahuella.get()).strip()
                if _ch_txt in ("", "0", "0.15", "0,15"):
                    _calcular_contrahuella(silencioso=True)
            except Exception:
                pass
        if clave == "escalera":
            esc = (motor.resumen or {}).get("escalera") or {}
            n = esc.get("pasos", 0)
            arr = esc.get("arranque") or {}
            if esc.get("real"):
                txt = (f"Encontré {n} peldaños dibujados en el plano. Se usan tal "
                       "cual: solo dime la contrahuella.")
                if arr.get("motivo"):
                    txt += "\n" + arr["motivo"]
            else:
                txt = ("El plano no trae los peldaños dibujados: se generan por "
                       "cálculo con los datos del panel de escalera.")
            lbl_esc_info.configure(text=txt)
            if not arr.get("invertir_aplicado"):
                var_invertir.set(bool(arr.get("invertir", False)))
                arr["invertir_aplicado"] = True
            fr_esc_paso.pack(fill="x", pady=(0, 6), before=btn_enviar_paso)
        else:
            fr_esc_paso.pack_forget()

        _pintar_avisos(clave)

        # PASO DE VANOS EN DOS TIEMPOS: primero la previa, después el corte.
        en_previa = (clave == "vanos" and previa_vanos["mostrada"]
                     and not previa_vanos["aprobada"])
        en_previa_vg = (clave == "vigas" and previa_vigas["mostrada"]
                        and not previa_vigas["aprobada"])
        if en_previa:
            fr_previa.pack(fill="x", pady=(0, 6), before=btn_enviar_paso)
        else:
            fr_previa.pack_forget()
        if en_previa_vg:
            fr_previa_vg.pack(fill="x", pady=(0, 6), before=btn_enviar_paso)
        else:
            fr_previa_vg.pack_forget()
        # La lista de peralte en lote sale en el paso de Vigas, con o sin
        # previa: es donde Willy trabaja, no en la ventana de evidencia.
        if clave == "vigas":
            _pintar_lista_vigas()
            fr_lote_vg.pack(fill="x", pady=(0, 2), before=btn_enviar_paso)
            fr_aplicar_vg.pack(fill="x", pady=(0, 6), before=btn_enviar_paso)
        else:
            fr_lote_vg.pack_forget()
            fr_aplicar_vg.pack_forget()
        en_previa = en_previa or en_previa_vg

        if paso_actual["enviado"] and not en_previa:
            # Ya se mandó a SketchUp: ahora el usuario decide, no se marca solo.
            fr_confirmar.pack(fill="x", pady=(2, 4), before=fr_atras)
            btn_enviar_paso.configure(text="Enviado — revisa en SketchUp",
                                      state="disabled")
        elif en_previa:
            fr_confirmar.pack_forget()
            btn_enviar_paso.configure(text="Previa enviada — revísala en SketchUp",
                                      state="disabled")
        else:
            fr_confirmar.pack_forget()
            if clave == "vanos" and not previa_vanos["aprobada"]:
                txt = "👁️  Ver PREVIA de vanos (sin cortar)"
            elif clave == "vigas" and not previa_vigas["aprobada"]:
                txt = "👁️  Ver PREVIA de vigas (sin recortar)"
            else:
                txt = f"▶  Enviar {etiqueta.split(' ', 1)[-1]} a SketchUp"
            btn_enviar_paso.configure(
                text=txt, state=("normal" if hay_plano else "disabled"),
                command=enviar_paso_actual)

    def _avisar_cambios_en_confirmado():
        """Antes de enviar una fase nueva, revisa si algo YA CONFIRMADO cambió.

        Solo avisa. Nunca lo corrige ni lo pisa: lo que el usuario confirmó
        manda por encima de lo que diga el DXF.
        """
        firma = _firma_actual()
        if not firma or not estado_vivo:
            return
        try:
            from memoria_elementos import diferencias_con_congelado
            avisos = diferencias_con_congelado(firma, 0, estado_vivo)
        except Exception:
            return
        for a in avisos[:6]:
            log("⚠️ " + a, "warn")
        if len(avisos) > 6:
            log(f"⚠️ ...y {len(avisos) - 6} diferencia(s) más sobre lo confirmado.",
                "warn")
        if avisos:
            log("Lo confirmado se respeta tal como está: ORA no lo va a pisar.", "ok")

    # ------------------------------------------------------------------
    # AVISOS ACCIONABLES: cada duda aparece en SU paso, con cómo resolverla.
    # ------------------------------------------------------------------
    resoluciones = {}   # id_aviso -> valor elegido por el usuario

    # Palabras que delatan a qué paso pertenece una duda suelta del análisis.
    # Hasta la v34 solo Vanos y Vigas generaban avisos; en Muros, Pisos,
    # Columnas, Techo y Escalera la ventana no salía nunca aunque el análisis
    # SÍ hubiera detectado dudas — se quedaban enterradas en el informe.
    PISTAS_DE_FASE = {
        "muros_pisos": ("muro", "piso", "ambiente", "npt", "sardinel",
                        "parapeto", "línea doble", "lineas dobles"),
        "vanos": ("vano", "puerta", "ventana", "mampara", "portón", "porton",
                  "alféizar", "alfeizar", "cuadro de vanos"),
        "columnas": ("columna", "placa"),
        "techo": ("techo", "losa", "azotea", "patio", "vacío", "vacio"),
        "vigas": ("viga", "peralte"),
        "escalera": ("escalera", "peldaño", "peldano", "contrahuella",
                     "descanso"),
    }

    def _dudas_sueltas_de(clave, ya_puestos):
        """Dudas del análisis que caen en este paso y nadie estaba mostrando.

        Son las del informe (`resumen["dudas"]`): texto, sin botones. Se
        muestran igual — una duda que no ves no la resuelves. Las que ya
        tienen su aviso propio con botones no se repiten.
        """
        r = motor.resumen or {}
        pistas = PISTAS_DE_FASE.get(clave, ())
        if not pistas:
            return []
        def _puntua(pistas_de):
            """(cuántas pistas coinciden, qué tan pronto aparece la primera).

            Con solo contar coincidencias, «Vano P-1: no hay ningún muro
            debajo» empataba a 1 entre Vanos y Muros y salía en los dos.
            Desempata la palabra que aparece ANTES: en castellano el sujeto va
            primero, así que esa frase es del paso de Vanos, no del de Muros.
            """
            pos = [t.index(p) for p in pistas_de if p in t]
            return (len(pos), -min(pos)) if pos else (0, 0)

        salida = []
        for i, d in enumerate(r.get("dudas") or []):
            t = str(d).lower()
            mia = _puntua(pistas)
            if not mia[0]:
                continue
            # UNA DUDA, UN SOLO PASO. Se puntúa contra todos y solo la muestra
            # el que gana; si nadie gana, la muestra el primero del orden fijo.
            gana = clave
            mejor = mia
            for c2, p2 in PISTAS_DE_FASE.items():
                if c2 == clave:
                    continue
                p = _puntua(p2)
                if p > mejor:
                    gana, mejor = c2, p
                elif p == mejor and list(PISTAS_DE_FASE).index(c2) < \
                        list(PISTAS_DE_FASE).index(gana):
                    gana = c2
            if gana != clave:
                continue
            if any(str(d)[:40] in str(a.get("texto", "")) for a in ya_puestos):
                continue
            salida.append({"id": f"duda::{clave}::{i}", "grave": False,
                           "texto": str(d), "editable": False,
                           "opciones": [("Entendido, seguir", "visto")]})
        return salida

    def _avisos_del_paso(clave):
        """Lista de avisos que pertenecen a este paso, ya resolubles."""
        r = motor.resumen or {}
        av = []
        if clave == "muros_pisos":
            av.extend(r.get("avisos_edificio") or [])
            # SUBTIPOS DE MURO: cada capa que no es el muro estándar del nivel
            # se pregunta aquí, con botones que APLICAN de verdad. Sin esto
            # todos subían a la altura genérica, incluidos los de cisterna.
            for _sub, _nombres in sorted((r.get("subtipos_muro") or {}).items()):
                _ya = (subtipos_declarados or {}).get(_sub)
                if _ya:
                    continue
                # Si el plano de cisterna venía adjunto a esta planta, la
                # altura y la cota YA se leyeron: se ofrecen resueltas, con su
                # evidencia, en vez de pedirlas en blanco.
                _b = bajo_nivel.get(
                    os.path.basename(getattr(motor, "archivo", "") or ""))
                _es_cist = any(k in _sub.upper()
                               for k in ("CISTERNA", "SOTANO", "SÓTANO"))
                _ops = [("Llega al techo, como el resto", "nivel"),
                        ("Escribir su altura", "escribir")]
                # YA CONTESTADO -> NO SE PREGUNTA (v66)
                if _sub in subtipos_declarados:
                    continue
                _extra = ""
                if _b and _es_cist:
                    _ops.insert(0, (f"Usar lo leído: {_b['alto']:.2f} m "
                                    f"desde {_b['fondo']:+.2f}",
                                    f"leido::{_b['alto']}::{_b['fondo']}"))
                    _extra = f"\n   Del plano adjunto: {_b['evidencia']}"
                av.append({
                    "id": f"subtipo::{_sub}",
                    "grave": True,
                    "texto": f"Capa «{_sub}»: {len(_nombres)} muro(s) "
                             f"({', '.join(str(n) for n in _nombres[:6])}"
                             f"{'…' if len(_nombres) > 6 else ''}). No es el "
                             "muro estándar del nivel. ¿Qué hace?" + _extra,
                    "editable": True,
                    "placeholder": "altura en m (y cota de arranque si va "
                                   "bajo el nivel: 1.80 / -1.80)",
                    "opciones": _ops,
                })
            if not getattr(motor, "archivo_specs", None):
                av.append({"id": "sin_info", "grave": True,
                           "texto": "No cargaste el plano de INFORMACIÓN. Los "
                                    "NPT se están adivinando por el material y "
                                    "las alturas de vano son valores típicos, no "
                                    "los de tu cuadro.",
                           "opciones": []})
            # SOLO LOS QUE DE VERDAD NO TRAEN RÓTULO (v58). Antes entraba
            # aquí cualquier paño con NPT 0.00, incluidos los rotulados
            # ±0.00: a Willy le salía «Piso_P0_12 no tiene rótulo de NPT
            # dentro» con el N.P.T +0.15 escrito al lado en la evidencia.
            sin_npt = [p for p in (r.get("pisos") or [])
                       if not p.get("npt_declarado")
                       and not p.get("npt_resuelto")]
            # UNO POR UNO, CON SU SITIO Y SU ORIGEN (v56).
            #
            # Antes era un solo aviso de bulto —«3 pisos sin NPT declarado»—
            # sin decir cuáles ni dónde, y sin nada que pulsar. Willy tiene
            # dos clósets en el piso 1 y tres en la típica que van 10 cm por
            # encima del piso, y ese dato no está en la planta: está en el
            # CORTE. Así que el aviso tiene que: enseñar dónde cae el paño,
            # dejar escribir la altura, decir DESDE DÓNDE se mide, y poder
            # mandarle el corte a la IA para que lo busque.
            _npt_niv = float((nivel_activo.get("npt") or 0.0)
                             if nivel_activo.get("modo") == "edificio" else 0.0)
            for n, p in enumerate(sin_npt[:12]):
                _poly = p.get("poly") or []
                _cx = sum(q[0] for q in _poly) / len(_poly) if _poly else None
                _cy = sum(q[1] for q in _poly) / len(_poly) if _poly else None
                _nom = p.get("nombre") or f"paño {n + 1}"
                _desde = (f"el piso terminado de esta planta (NPT "
                          f"{_npt_niv:+.2f})" if abs(_npt_niv) > 0.001
                          else "la cota 0.00 del proyecto")
                av.append({
                    "id": f"pisonpt::{_nom}", "grave": False,
                    "x": _cx, "y": _cy, "poly": _poly, "codigo": _nom,
                    "texto": (f"{_nom} no tiene rótulo de NPT dentro, así que "
                              "queda al ras y NO se levanta. Si va elevado, "
                              "escribe cuánto sube — se mide desde "
                              f"{_desde}. El dato suele estar acotado en el "
                              "CORTE de esa zona, no en la planta."),
                    "editable": True,
                    "placeholder": ("cuánto sube o baja en m "
                                    "(p. ej. 0.10 · -0.15)"),
                    # Willy: «indicando de dónde empieza su altura». Se dice
                    # y además se ofrece la otra referencia, para que no haya
                    # que sumar de cabeza los 0.15 + 0.10.
                    "origen_npt": round(_npt_niv, 3),
                    "opciones": ([("👁 Ver dónde está", ("mirar", p)),
                                  (f"Subir 0.10 sobre el piso "
                                   f"({_npt_niv + 0.10:+.2f} total)", 0.10)]
                                 # EL CASO DE LA COCHERA Y LA TERRAZA (v58).
                                 # Van a la cota 0.00 del proyecto, o sea
                                 # POR DEBAJO del piso terminado de su
                                 # planta. Antes no había forma de decirlo:
                                 # el campo solo aceptaba «cuánto sube».
                                 + ([(f"Va a la cota 0.00 del proyecto "
                                      f"(baja {-_npt_niv:.2f})",
                                      round(-_npt_niv, 3))]
                                    if abs(_npt_niv) > 0.001 else [])
                                 + [("Al ras de esta planta (mismo nivel)", 0.0),
                                    ("Dejarlo como cara (no se levanta)",
                                     "solo_cara")])})
        elif clave == "vanos":
            for n, c in enumerate((r.get("conflictos_vano") or [])):
                cod = c.get("codigo") or "?"
                if c.get("tipo") == "ancho_no_coincide":
                    av.append({
                        "id": f"ancho::{cod}::{n}", "grave": True,
                        # Willy: «no me especifica si es el ancho, el alto o
                        # el alféizar. Debe decírmelo».
                        "texto": (f"{cod} · ANCHO: el dibujo mide "
                                  f"{c['dibujo']} m y tu cuadro dice "
                                  f"{c['cuadro']} m. ¿Cuál vale?"),
                        # "Ver dónde está" en TODOS los avisos con código, no
                        # solo en algunos: leer "PS-1 mide 3.25 y el cuadro
                        # dice 3.0" sin saber cuál es PS-1 no sirve de nada.
                        "x": (c or {}).get("x"), "y": (c or {}).get("y"),
                        # El contorno viene del DXF, no de lo modelado: PS-1
                        # no tiene muro debajo y no se levanta, pero dibujado
                        # está y hay que poder verlo.
                        "poly": (c or {}).get("poly"),
                        "codigo": (c or {}).get("codigo"),
                        "opciones": [("👁 Ver dónde está", ("mirar", c)),
                                     (f"Usar {c['dibujo']} (dibujo)", c["dibujo"]),
                                     (f"Usar {c['cuadro']} (cuadro)", c["cuadro"])]})
                elif c.get("tipo") == "alta_con_alfeizar_bajo":
                    av.append({
                        "id": f"alta::{cod}::{n}", "grave": False,
                        "texto": f"{cod} está en la capa «{c.get('capa')}» "
                                 f"(ventana alta) pero su alféizar es "
                                 f"{c.get('alfeizar')} m.",
                        "x": (c or {}).get("x"), "y": (c or {}).get("y"),
                        "poly": (c or {}).get("poly"),
                        "codigo": (c or {}).get("codigo"),
                        "opciones": [("👁 Ver dónde está", ("mirar", c)),
                                     ("Dejar como el cuadro", "cuadro"),
                                     ("Subir a 1.90 (alta)", 1.90)]})
                elif c.get("tipo") == "codigo_ambiguo":
                    # AMBIGÜEDAD DE TEXTO (v60). Willy: «si la distancia entre
                    # un texto y varios elementos de vano es menor a un valor
                    # definido, el proceso de asignación debe pausarse». Este
                    # vano quedó con el código más cercano por defecto — el
                    # aviso deja elegir el otro, o preguntarle a la IA.
                    _otro = c.get("otro_codigo")
                    av.append({
                        "id": f"codvano::{cod}::{c.get('otro_codigo')}::{n}",
                        "grave": False,
                        "texto": (f"El código «{cod}» está casi a la misma "
                                  f"distancia de dos vanos: este "
                                  f"({c.get('distancia')} m) y otro con "
                                  f"«{_otro}» cerca ({c.get('otra_distancia')} "
                                  "m). ¿Cuál es el correcto para este vano?"),
                        "x": (c or {}).get("x"), "y": (c or {}).get("y"),
                        "poly": (c or {}).get("poly"),
                        "codigo": cod,
                        "ia_consulta": "codigo_ambiguo", "ia_datos": c,
                        "opciones": [("👁 Ver dónde está", ("mirar", c)),
                                     ("🤖 Preguntarle a la IA",
                                      ("ia_codigo", c)),
                                     (f"Es «{cod}»", cod),
                                     (f"Es «{_otro}»", _otro)]})
                elif c.get("tipo") == "sin_muro":
                    # Antes esto solo salía como línea en el informe y Willy se
                    # enteraba cuando ya estaba modelando. Ahora es un aviso
                    # del paso, con acciones: verlo en SketchUp para moverlo
                    # encima del muro, o dejarlo así si va entre columnas.
                    _pct = c.get("pct")
                    _det = (f"apenas toca el muro más cercano "
                            f"({int(_pct * 100)}% de solape)" if _pct is not None
                            else "no tiene ningún muro debajo")
                    av.append({
                        "id": f"sinmuro::{cod}::{n}", "grave": True,
                        "x": (c or {}).get("x"), "y": (c or {}).get("y"),
                        "poly": (c or {}).get("poly"),
                        "codigo": (c or {}).get("codigo"),
                        # Willy: «deja un lenguaje más entendible al usuario y
                        # directo». Nada de «exento»: se dice qué pasa y qué
                        # hacer, con las palabras de la obra.
                        "texto": f"{cod}: {_det}, así que ORA no le va a "
                                 "abrir el hueco. Si el vano va en un espacio "
                                 "abierto o entre columnas, está bien. Si "
                                 "tenía que perforar un muro, muévelo encima "
                                 "del muro en la previa y vuelve a cortar.",
                        "opciones": [("👁 Ver dónde está", ("mirar", c)),
                                     ("Está bien, va sin muro", "dejar")]})
                elif c.get("tipo") == "superpuesto":
                    av.append({
                        "id": f"superp::{cod}::{n}", "grave": True,
                        "x": (c or {}).get("x"), "y": (c or {}).get("y"),
                        "codigo": (c or {}).get("codigo"),
                        "texto": f"{cod} está dibujado ENCIMA de "
                                 f"{c.get('otro')}, en la misma coordenada del "
                                 "plano. Uno de los dos sobra: si se cortan los "
                                 "dos, el hueco sale doble y parece que uno "
                                 "desapareció.",
                        "opciones": [("Ver dónde está", ("mirar", c)),
                                     ("No modelar el repetido", "quitar_dup"),
                                     ("Modelar los dos igual", "dejar")]})
            sin_alto = [a for a in (r.get("catalogo_vanos") or [])
                        if a.get("alto_asumido")]
            for v in sin_alto[:4]:
                cod = v.get("codigo") or "?"
                av.append({
                    "id": f"alto::{cod}::sinalto", "grave": True,
                    "x": v.get("x"), "y": v.get("y"), "poly": v.get("poly"),
                    "codigo": v.get("codigo"),
                    "texto": f"{cod} no tiene altura en ningún plano: se "
                             f"asumió {v.get('alto')} m.",
                    "editable": True,
                    "placeholder": "altura real en m (p. ej. 2.10)",
                    "opciones": [("👁 Ver dónde está", ("mirar", v)),
                                 ("Dejar el asumido",
                                  float(v.get("alto") or 0))]})
        elif clave == "vigas":
            # CONTRADICCIÓN entre planos: se muestra con las dos cifras y con
            # la opción de pedirle una segunda opinión a la IA. La IA no
            # decide: aporta un argumento y el usuario elige.
            for vg in (r.get("vigas") or []):
                if not vg.get("en_conflicto"):
                    continue
                _pc = vg.get("peralte_corte")
                av.append({
                    "id": f"conflicto::{vg.get('nombre')}", "grave": True,
                    "texto": (f"{vg.get('nombre')}: el corte dice "
                              f"{float(_pc):.2f} m de peralte y la capa "
                              f"«{vg.get('capa')}» dice "
                              f"{float(vg.get('peralte')):.2f} m. Uno de los "
                              "dos planos está desactualizado."),
                    "opciones": [
                        ("👁 Ver dónde está",
                         ("mirar", {"codigo": vg.get("nombre")})),
                        (f"Usar {float(_pc):.2f} (corte)", float(_pc)),
                        (f"Usar {float(vg.get('peralte')):.2f} (capa)",
                         float(vg.get("peralte"))),
                        ("🤖 Segunda opinión", ("ia", vg))]})
            # Sin peralte no se levanta la viga: se pide aquí. ORA no lo
            # inventa, porque una viga inventada miente en el metrado y en la
            # altura libre que revisa el municipio.
            for vg in (r.get("vigas") or []):
                if vg.get("pendiente") or not vg.get("peralte"):
                    av.append({
                        "id": f"peralte::{vg.get('nombre')}", "grave": True,
                        "texto": (f"{vg.get('nombre')} ({vg.get('capa')}) no "
                                  "trae peralte: no está en el nombre de la "
                                  "capa, ni en la planta, ni en el corte. "
                                  "Escríbelo y se levanta."),
                        # «Escribir el peralte» no abría ningún campo: Willy
                        # pulsaba, no pasaba nada, y sus 20 vigas se quedaban
                        # sin levantar. Faltaba declararlo editable.
                        "editable": True,
                        "placeholder": ("PERALTE en m — el alto de la viga "
                                        "(0.40) o ancho×alto (0.30x0.40)"),
                        "opciones": [("👁 Ver dónde está",
                                      ("mirar", {"codigo": vg.get("nombre")}))]})
            # VIGAS: vano que no pasa por debajo, y altura libre para el RNE.
            for c in (r.get("conflictos_viga") or [])[:4]:
                if c.get("tipo") == "vano_no_pasa_bajo_viga":
                    av.append({
                        "id": f"viga::{c.get('vano')}::{c.get('viga')}",
                        "grave": True, "editable": False,
                        "texto": (f"{c.get('vano')} mide {c.get('alto_vano')} m "
                                  f"pero bajo la viga {c.get('viga')} solo hay "
                                  f"{c.get('libre_bajo_viga')} m: faltan "
                                  f"{c.get('falta')} m."),
                        "opciones": [("👁 Ver la viga",
                                      ("mirar", {"codigo": c.get("viga")})),
                                     ("Bajar el vano a lo que entra",
                                      c.get("libre_bajo_viga"))]})
        elif clave == "techo":
            # HUECO DE ESCALERA propuesto cuando el DXF no lo trae.
            pr = r.get("hueco_escalera_propuesto")
            if pr and pr.get("necesario"):
                av.append({
                    "id": "hueco_escalera", "grave": True, "editable": False,
                    "texto": ("El plano no trae el hueco de la escalera en la "
                              f"losa. Propongo uno de {pr.get('area')} m² con "
                              f"{pr.get('holgura')} m de holgura. Revísalo en "
                              "la previa antes de abrirlo."),
                    "opciones": [("Usar el propuesto", "aplicar"),
                                 ("No abrir hueco", "omitir")]})
            for c in (r.get("avisos_rne") or [])[:3]:
                av.append({
                    "id": f"rne::{c.get('ambiente')}::{c.get('viga')}",
                    "grave": True, "editable": False,
                    "texto": (f"{c.get('ambiente')}: bajo la viga "
                              f"{c.get('viga')} quedan {c.get('libre')} m "
                              f"libres, menos que los {c.get('minima')} m que "
                              "suele exigir el RNE."),
                    "opciones": [("Entendido", "visto")]})
        # PLANTAS TÍPICAS: se propone, no se asume (regla de Willy).
        for pr in (r.get("propuestas_planta_tipica") or []):
            av.append({"id": f"tipica::{'-'.join(map(str, pr['niveles']))}",
                       "grave": False, "editable": False,
                       "texto": pr["texto"],
                       "opciones": [("Sí, son la misma", "tipica"),
                                    ("Por separado", "separado")]})
        av += _dudas_sueltas_de(clave, av)
        return [a for a in av if a["id"] not in resoluciones]

    def _resolver_aviso(aviso, valor):
        """Guarda la decisión Y vuelve a calcular con ella.

        Antes esto solo sacaba el aviso de la lista: la decisión no llegaba
        nunca al modelo. Ahora se guarda en la memoria del plano (manda sobre
        lo que digan los planos, porque es un dato tuyo) y se re-aplica al
        catálogo en el acto.
        """
        resoluciones[aviso["id"]] = valor
        firma = _firma_actual()
        piso = _piso_actual()

        # --- VER DÓNDE ESTÁ: lleva la cámara de SketchUp al vano en cuestión
        # y lo deja seleccionado, para poder moverlo ahí mismo. Un aviso que
        # no puedes resolver donde lo lees no sirve de nada.
        if isinstance(valor, tuple) and valor and valor[0] == "ia_codigo":
            c = valor[1] if len(valor) > 1 else {}
            log("🤖 Consultando a la IA sobre el código ambiguo…", "warn")

            def _pedir_cod():
                try:
                    from ia_asistente import opinar_sobre_codigo_ambiguo
                    _cod = aviso.get("codigo")
                    _otro = c.get("otro_codigo")
                    txt, quien = opinar_sobre_codigo_ambiguo({
                        "texto": _cod,
                        "candidatos": [
                            {"nombre": _cod, "muro": "?",
                             "distancia": c.get("distancia") or 0,
                             "ancho": c.get("ancho")},
                            {"nombre": _otro, "muro": "?",
                             "distancia": c.get("otra_distancia") or 0}],
                        "contexto": "Proyecto de vivienda en Perú. El texto "
                                    "está casi a la misma distancia de dos "
                                    "vanos dibujados."})
                except Exception as ex:
                    txt, quien = None, str(ex)
                def _fin():
                    if txt:
                        log(f"🤖 ({quien}) {txt}", "ok")
                        log("La IA solo opina: decides tú con los botones.",
                            "warn")
                    else:
                        log(f"No se pudo consultar a la IA: {quien}. "
                            "Revisa la clave en Configuración.", "warn")
                root.after(0, _fin)
            threading.Thread(target=_pedir_cod, daemon=True).start()
            resoluciones.pop(aviso["id"], None)     # sigue sin decidirse
            _pintar_avisos(_fase_disponible()[paso_actual["i"]][0]
                           if _fase_disponible() else "")
            return
        if isinstance(valor, tuple) and valor and valor[0] == "ia":
            vg = valor[1] if len(valor) > 1 else {}
            log("🤖 Consultando a la IA sobre la contradicción…", "warn")

            def _pedir():
                try:
                    from ia_asistente import opinar_sobre_contradiccion
                    txt, quien = opinar_sobre_contradiccion({
                        "elemento": f"Viga {vg.get('nombre')}",
                        "dato": "peralte",
                        "fuentes": {
                            "corte/elevaciones":
                                f"{vg.get('peralte_corte')} m",
                            f"nombre de capa «{vg.get('capa')}»":
                                f"{vg.get('peralte')} m"},
                        "contexto": ("Proyecto de vivienda en Perú. El corte "
                                     "rotula la especificación general; el "
                                     "nombre de capa identifica cada viga por "
                                     "separado.")})
                except Exception as ex:
                    txt, quien = None, str(ex)
                def _fin():
                    if txt:
                        log(f"🤖 ({quien}) {txt}", "ok")
                        log("La IA solo opina: decides tú con los botones.",
                            "warn")
                    else:
                        log(f"No se pudo consultar a la IA: {quien}. "
                            "Revisa la clave en Configuración.", "warn")
                root.after(0, _fin)
            threading.Thread(target=_pedir, daemon=True).start()
            resoluciones.pop(aviso["id"], None)     # sigue sin decidirse
            _pintar_avisos(_fase_disponible()[paso_actual["i"]][0]
                           if _fase_disponible() else "")
            return
        if isinstance(valor, tuple) and valor and valor[0] == "mirar":
            c = valor[1] if len(valor) > 1 else {}
            cod = c.get("codigo", "")
            try:
                # Se busca la fila del vano para saber su nombre de grupo real
                # (durante la previa es 'ORA_PREVIA_<nombre>').
                objetivo = None
                for f in fila_elementos:
                    if cod and cod in str(f.get("nombre") or ""):
                        objetivo = f["nombre"]
                        break
                if objetivo:
                    enviar_edicion(objetivo, "mirar", 0)
                    log(f"👁 {cod} seleccionado y enfocado en SketchUp. Si hay "
                        "que moverlo, hazlo ahí y pulsa «Aprender posiciones "
                        "que moví».", "ok")
                elif not paso_actual.get("enviado"):
                    log(f"Todavía no has generado este paso: {cod} aún no "
                        "existe en SketchUp. Pulsa el botón del paso y vuelve "
                        "a darle a «Ver dónde está».", "warn")
                else:
                    log(f"{cod} no está en SketchUp (no se modeló). Está en el "
                        f"plano cerca de X={c.get('x', 0):.2f}, "
                        f"Y={c.get('y', 0):.2f}.", "warn")
            except Exception as ex:
                log(f"No se pudo enfocar: {ex}", "warn")
            resoluciones.pop(aviso["id"], None)   # sigue pendiente de decidir
            refrescar_fases()
            return

        # --- NO MODELAR EL REPETIDO: el plano trae dos vanos en la misma
        # coordenada. Se marca el segundo para que no se corte, sin tocar el DXF.
        if valor == "quitar_dup":
            cod = aviso["id"].split("::")[1]
            n_out = 0
            for ent in list((motor.kernel.project.entities or {}).values()):
                if ent.type not in ("door", "window"):
                    continue
                if (ent.properties or {}).get("codigo") != cod:
                    continue
                n_out += 1
                if n_out > 1:            # el primero se queda, los demás no
                    ent.properties["no_modelar"] = True
            log(f"✂️ {cod}: se modelará una sola vez ({n_out - 1} repetida(s) "
                "descartada(s)). El DXF no se toca.", "ok")
            refrescar_fases()
            return

        if aviso["id"].startswith("semisotano::") and isinstance(valor, (int, float)):
            # Este aviso no es de vano: es un dato del EDIFICIO (cuánto se
            # hunde el semisótano). Se corrige el pisos_config y se vuelve a
            # apilar en el acto — nunca se queda como "informado y ya".
            idx = aviso.get("nivel")
            if idx is not None and getattr(motor, "pisos_config", None):
                try:
                    motor.pisos_config[idx]["enterrado"] = float(valor)
                    analizar_edificio_ahora()
                    log(f"🔄 Recalculado con {valor} m de hundimiento.", "ok")
                except Exception as ex:
                    log(f"No se pudo recalcular: {ex}", "warn")
            refrescar_fases()
            return
        if aviso["id"].startswith("pisonpt::"):
            # ESTE BOTÓN NO HACÍA NADA (v58). No existía ni una línea que
            # atendiera `pisonpt::`: el valor caía en la rama genérica del
            # final, que busca un VANO con ese nombre, no lo encuentra, y se
            # va. La decisión se guardaba en la memoria y el modelo salía
            # idéntico. Por eso a Willy «Dejarlo al ras» no le hacía nada,
            # «Subir 0.10» tampoco, y escribir 0.00 tampoco: los tres botones
            # hacían exactamente lo mismo, que era nada.
            _nom = aviso["id"].split("::", 1)[1]
            _pano = next((p for p in ((motor.resumen or {}).get("pisos") or [])
                          if str(p.get("nombre") or "") == _nom), None)
            if _pano is None:
                log(f"No encuentro el paño «{_nom}» en este plano. Vuelve a "
                    "analizar la planta.", "warn")
                return
            _niv = float(aviso.get("origen_npt") or 0.0)
            if valor == "solo_cara":
                _pano["npt_declarado"] = False
                _pano["npt_resuelto"] = True
                _guardado = None
                log(f"«{_nom}»: queda como cara al ras de esta planta, sin "
                    "volumen. No vuelvo a preguntar.", "ok")
            else:
                try:
                    _sube = float(valor)
                except (TypeError, ValueError):
                    log("Escribe cuánto sube o baja en metros "
                        "(por ejemplo 0.10, o -0.15 si va por debajo).",
                        "warn")
                    return
                _guardado = round(_niv + _sube, 3)
                _pano["npt"] = _guardado
                _pano["npt_declarado"] = True
                _pano["npt_resuelto"] = True
                _pano["npt_fuente"] = "escrito por ti"
                # El grosor lo recalcula el generador según la planta; aquí
                # solo se deja de dar por bueno el 0.05 de respaldo.
                _pano.pop("grosor", None)
                _donde = ("sube" if _sube > 0.0005 else
                          "baja" if _sube < -0.0005 else "queda al ras")
                log(f"«{_nom}»: {_donde} {abs(_sube):.2f} m sobre el piso de "
                    f"esta planta → cota {_guardado:+.2f}.", "ok")
            if firma:
                try:
                    from memoria_elementos import guardar_npt_piso
                    guardar_npt_piso(firma, piso, _nom, _guardado)
                except Exception as ex:
                    log(f"No se pudo recordar ese NPT: {ex}", "warn")
            refrescar_fases()
            _reenviar_tras_resolver()
            return
        if aviso["id"].startswith("subtipo::"):
            # «Llega al techo» o una altura escrita. Se guarda por subtipo y
            # se aplica a TODOS los muros de esa capa al regenerar.
            sub = aviso["id"].split("::", 1)[1]
            if valor == "nivel":
                subtipos_declarados[sub] = {"modo": "nivel"}
                log(f"«{sub}»: llega al techo, como el muro del nivel.", "ok")
            elif str(valor).startswith("leido::"):
                # El botón «Usar lo leído»: alto y cota vienen del plano
                # adjunto de la cisterna, no de una fórmula ni de un supuesto.
                _p = str(valor).split("::")
                subtipos_declarados[sub] = {"modo": "cota",
                                            "alto": float(_p[1]),
                                            "z": float(_p[2])}
                log(f"«{sub}»: {float(_p[1]):.2f} m arrancando en "
                    f"{float(_p[2]):+.2f}, leído de su plano.", "ok")
            else:
                txt = str(valor).replace(",", ".").strip()
                nums = re.findall(r"-?\d+(?:\.\d+)?", txt)
                if not nums:
                    log(f"No entendí «{valor}». Escribe la altura en metros, "
                        "y la cota de arranque si va bajo el nivel "
                        "(ejemplo: 1.80 / -1.80).", "warn")
                    return
                alto = abs(float(nums[0]))
                if len(nums) > 1:
                    subtipos_declarados[sub] = {"modo": "cota", "alto": alto,
                                                "z": float(nums[1])}
                    log(f"«{sub}»: {alto:.2f} m arrancando en "
                        f"{float(nums[1]):+.2f}.", "ok")
                else:
                    subtipos_declarados[sub] = {"modo": "propia", "alto": alto}
                    log(f"«{sub}»: altura propia de {alto:.2f} m.", "ok")
            if firma:
                try:
                    from memoria_elementos import guardar_decision
                    guardar_decision(firma, piso, aviso["id"],
                                     subtipos_declarados[sub])
                except Exception:
                    pass
            refrescar_fases()
            _reenviar_tras_resolver()
            return
        if aviso["id"].startswith("codvano::") and isinstance(valor, str):
            # Willy elige entre los dos candidatos («Es «P-1»» / «Es «P-2»»).
            # El valor es el CÓDIGO elegido; la posición para encontrar el
            # vano exacto viene del propio aviso, no de un código que
            # justamente estaba en duda.
            _dic = {"x": float(aviso.get("x")) if aviso.get("x") is not None
                    else None,
                    "y": float(aviso.get("y")) if aviso.get("y") is not None
                    else None, "codigo": valor}
            try:
                from memoria_elementos import (guardar_decision,
                                               aplicar_decisiones_a_vanos)
                if firma:
                    guardar_decision(firma, piso, aviso["id"], _dic)
                n = aplicar_decisiones_a_vanos(
                    (motor.resumen or {}).get("catalogo_vanos") or [],
                    {aviso["id"]: _dic})
                log(f"«{valor}» confirmado para este vano." if n
                    else "No encontré el vano en el catálogo para "
                         "renombrarlo.", "ok" if n else "warn")
            except Exception as ex:
                log(f"No se pudo aplicar: {ex}", "warn")
            refrescar_fases()
            _reenviar_tras_resolver()
            return
        if aviso["id"].startswith("conflicto::") and isinstance(valor, (int, float)):
            # «Usar 0.40 (corte)» / «Usar 0.45 (capa)». Hasta la v35 este id
            # caía en la rama genérica, que llama a aplicar_decisiones_a_vanos:
            # buscaba un VANO llamado VG01 y no existía. El botón sacaba el
            # aviso de la lista y la viga se quedaba exactamente igual.
            nombre_vg = aviso["id"].split("::", 1)[1]
            _hecho = False
            for vg in (motor.resumen or {}).get("vigas") or []:
                if vg.get("nombre") != nombre_vg:
                    continue
                from vigas import clasificar
                vg["peralte"] = round(float(valor), 4)
                vg["peralte_asumido"] = False
                vg["pendiente"] = False
                vg["en_conflicto"] = False        # ya lo decidiste tú
                vg["fuente_peralte"] = "elegido por el usuario"
                cl = clasificar(valor, vg.get("espesor_losa", 0.20))
                vg["tipo"], vg["cuelgue"] = cl["tipo"], cl["cuelgue"]
                _hecho = True
            if firma:
                try:
                    from memoria_elementos import guardar_decision
                    guardar_decision(firma, piso, aviso["id"],
                                     round(float(valor), 4))
                except Exception:
                    pass
            log(f"🔄 {nombre_vg}: peralte fijado en {float(valor):.2f} m "
                "(tu decisión manda sobre los dos planos)." if _hecho
                else f"No encontré la viga {nombre_vg} para aplicarle el "
                     "peralte.", "ok" if _hecho else "warn")
            refrescar_fases()
            _reenviar_tras_resolver()
            return
        if aviso["id"].startswith("viga::") and isinstance(valor, (int, float)):
            # «Bajar el vano a lo que entra». El id es viga::<vano>::<viga>;
            # la rutina genérica lo partía como clase="viga", código="<vano>",
            # y como no hay rama para "viga" devolvía 0: no bajaba nada.
            _p = aviso["id"].split("::")
            cod = _p[1] if len(_p) > 1 else ""
            nuevo = round(float(valor), 4)
            try:
                from memoria_elementos import (guardar_decision,
                                               aplicar_decisiones_a_vanos)
                if firma:
                    guardar_decision(firma, piso, f"alto::{cod}", nuevo)
                n = aplicar_decisiones_a_vanos(
                    (motor.resumen or {}).get("catalogo_vanos") or [],
                    {f"alto::{cod}": nuevo})
                if n:
                    log(f"🔽 {cod}: alto bajado a {nuevo:.2f} m para que pase "
                        "bajo la viga. Se vuelve a cortar el vano.", "ok")
                    # El vano es de un paso ANTERIOR: hay que regenerarlo
                    # aparte, si no el cambio se guarda y no se ve.
                    root.after(150, lambda: aplicar_en_vivo(
                        categorias=["muros", "vanos"]))
                else:
                    log(f"No encontré el vano {cod} en el cuadro para bajarlo.",
                        "warn")
            except Exception as ex:
                log(f"No se pudo bajar el vano: {ex}", "warn")
            refrescar_fases()
            return
        if aviso["id"].startswith("peralte::"):
            # El campo manda TEXTO: «0.40» o «0.30x0.40». Antes solo se
            # aceptaba un número y lo escrito se perdía sin decir nada.
            if not isinstance(valor, (int, float)):
                _txt = str(valor or "").strip().replace(",", ".")
                try:
                    from vigas import peralte_de_texto
                    valor = peralte_de_texto(_txt)
                except Exception:
                    valor = None
                if valor is None:
                    # `peralte_de_texto` solo entiende «0.30x0.40». Willy
                    # escribe muchas veces el peralte a secas: «0.40».
                    try:
                        _v = float(_txt)
                        valor = _v if 0.05 <= _v <= 3.0 else None
                    except (TypeError, ValueError):
                        valor = None
                if valor is None:
                    log("No entendí ese peralte. Escríbelo como 0.40 o "
                        "0.30x0.40.", "warn")
                    return
            nombre_vg = aviso["id"].split("::", 1)[1]
            for vg in (motor.resumen or {}).get("vigas") or []:
                if vg.get("nombre") == nombre_vg:
                    from vigas import clasificar
                    vg["peralte"] = round(float(valor), 4)
                    vg["peralte_asumido"] = False
                    vg["pendiente"] = False
                    vg["fuente_peralte"] = "escrito"
                    cl = clasificar(valor, vg.get("espesor_losa", 0.20))
                    vg["tipo"], vg["cuelgue"] = cl["tipo"], cl["cuelgue"]
                    log(f"🔄 {nombre_vg}: peralte actualizado a {valor} m.", "ok")
            refrescar_fases()
            _reenviar_tras_resolver()
            return
        if firma and isinstance(valor, (int, float)):
            try:
                from memoria_elementos import (guardar_decision, decisiones_de,
                                               aplicar_decisiones_a_vanos)
                guardar_decision(firma, piso, aviso["id"], valor)
                n = aplicar_decisiones_a_vanos(
                    (motor.resumen or {}).get("catalogo_vanos") or [],
                    decisiones_de(firma, piso))
                if n:
                    log(f"🔄 Recalculado con tu decisión ({n} vano(s) "
                        "actualizados).", "ok")
            except Exception as ex:
                log(f"No se pudo aplicar la decisión: {ex}", "warn")
        log(f"✔ Resuelto: {aviso['texto'][:60]}… → {valor}", "ok")
        refrescar_fases()
        _reenviar_tras_resolver()

    def _reenviar_tras_resolver():
        """La decisión se aplica en SketchUp en el acto.

        Antes se guardaba y se recalculaba por dentro, pero el modelo seguía
        con lo viejo hasta que el usuario reenviaba el paso a mano. Un aviso
        que resuelves y no cambia nada en pantalla no parece resuelto.
        """
        try:
            if paso_actual.get("enviado"):
                root.after(120, enviar_paso_actual)
        except Exception:
            pass

    def _resolver_con_valor_escrito(aviso, var):
        """El usuario escribió un valor propio en vez de elegir una opción."""
        txt = str(var.get()).replace(",", ".").strip()
        try:
            valor = float(txt)
        except ValueError:
            log("Escribe un número válido.", "warn")
            return
        _resolver_aviso(aviso, round(valor, 4))

    # ---- VENTANA FLOTANTE DE AVISOS -----------------------------------
    # Los avisos vivían solo en la columna de ORA, apretados entre todo lo
    # demás: se leían como jerga y pasaban desapercibidos ("5 cosas por
    # revisar" y a otra cosa). Ahora salen en una ventana propia, al lado de
    # ORA (nunca en el centro, que tapa el modelo), con el botón para verlos
    # en SketchUp y los de resolver a mano.
    win_avisos = {"top": None, "cuerpo": None, "cerrada_por_ti": False}
    # v36: los avisos SÍ salen al entrar al paso. Antes se diferían hasta la
    # previa con el argumento de que "Ver dónde está" no tendría qué enfocar —
    # pero la mayoría de avisos (una medida que falta, dos planos que se
    # contradicen) se resuelven ANTES de generar nada, y esperar solo servía
    # para que el usuario no los viera. Si todavía no hay geometría, el botón
    # de mirar lo dice en cristiano en vez de fallar.
    avisos_diferidos = {"pendiente": True}
    # Para no repetir el mismo anuncio en cada repintado de la columna.
    avisos_anunciados = {"ultimo": None}

    def _cerrar_avisos():
        t = win_avisos.get("top")
        if t is not None:
            try:
                t.destroy()
            except Exception:
                pass
        win_avisos["top"] = None
        win_avisos["cuerpo"] = None
        # Si la cerraste tú, se queda cerrada hasta que haya algo NUEVO que
        # revisar. Antes volvía a salirte sola en el siguiente refresco.
        win_avisos["cerrada_por_ti"] = True

    def _ventana_recorte(aviso):
        """Muestra la zona del plano donde está la duda, como en AutoCAD.

        Sale del plano de INFORMACIÓN (textos, códigos de vano, NPT, tramas);
        el limpio queda como segunda opción porque son solo líneas. Se
        renderiza al abrir, no al analizar: media lámina de 3 MB tarda unos
        segundos y no tiene sentido pagar eso por 31 dudas de golpe.
        """
        try:
            from recorte_plano import recorte_de_duda, disponible, RADIO_DEFECTO
        except Exception as ex:
            messagebox.showinfo("ORA", f"No puedo dibujar el plano: {ex}")
            return
        ok, motivo = disponible()
        if not ok:
            messagebox.showinfo(
                "ORA", "Para ver la duda en el plano falta una librería de "
                       f"dibujo.\n\n{motivo}")
            return
        t = tk.Toplevel(root)
        t.title(f"ORA — {aviso.get('codigo') or 'la duda'} en el plano")
        t.transient(root)
        t.geometry("1000x800")
        tk.Label(t, text=aviso.get("texto", ""), wraplength=960,
                 justify="left", font=("Segoe UI", 9)).pack(anchor="w",
                                                            padx=10, pady=8)
        lbl = tk.Label(t, text="Dibujando la zona del plano…",
                       font=("Segoe UI", 10))
        lbl.pack(expand=True)
        barra = tk.Frame(t)
        barra.pack(fill="x", padx=10, pady=(0, 10))
        estado = {"radio": RADIO_DEFECTO, "fuente": "info", "img": None}

        def _pintar():
            info = getattr(motor, "archivo_specs", None)
            limpio = getattr(motor, "archivo", None)
            if estado["fuente"] == "limpio":
                info, limpio = None, limpio
            png, de_donde = recorte_de_duda(aviso, info, limpio,
                                            estado["radio"])
            def _fin():
                if not png:
                    lbl.configure(text=f"No pude dibujarlo: {de_donde}")
                    return
                try:
                    img = tk.PhotoImage(file=png)
                except Exception as ex:
                    lbl.configure(text=f"No pude mostrar la imagen: {ex}")
                    return
                estado["img"] = img          # sin esto tk la descarta
                lbl.configure(image=img, text="")
                t.title(f"ORA — {aviso.get('codigo') or 'la duda'} · "
                        f"{de_donde}")
            root.after(0, _fin)

        def _relanzar():
            lbl.configure(image="", text="Dibujando la zona del plano…")
            threading.Thread(target=_pintar, daemon=True).start()

        def _zoom(f):
            estado["radio"] = max(1.0, min(30.0, estado["radio"] * f))
            _relanzar()

        tk.Button(barra, text="➕ Acercar", font=("Segoe UI", 9),
                  command=lambda: _zoom(0.6)).pack(side="left")
        tk.Button(barra, text="➖ Alejar", font=("Segoe UI", 9),
                  command=lambda: _zoom(1.7)).pack(side="left", padx=4)

        def _cambiar_fuente():
            estado["fuente"] = ("limpio" if estado["fuente"] == "info"
                                else "info")
            btn_f.configure(text=("📐 Ver el de información"
                                  if estado["fuente"] == "limpio"
                                  else "📂 Ver el plano limpio"))
            _relanzar()

        btn_f = tk.Button(barra, text="📂 Ver el plano limpio",
                          font=("Segoe UI", 9), command=_cambiar_fuente)
        btn_f.pack(side="left", padx=4)
        tk.Button(barra, text="Cerrar", command=t.destroy).pack(side="right")
        _relanzar()
        t.lift()

    # ------------------------------------------------------------------
    # EVIDENCIA VISUAL (v46)
    # ------------------------------------------------------------------
    # Regla de Willy, después de que el «SARDINEL H: 0.20 cm.» estuviera
    # escrito en su plano y ORA lo ignorara durante versiones: **todo elemento
    # y toda duda vienen con la imagen de dónde salieron, en los dos planos**.
    # Sin eso, «asumí 1.10 m» es una afirmación que nadie puede comprobar.
    def _planos_del_paso():
        """Los DXF de la planta que se está mirando ahora mismo."""
        limpio = getattr(motor, "archivo", None)
        info = getattr(motor, "archivo_specs", None)
        extras = []
        cortes = getattr(motor, "archivo_cortes", None)
        if cortes:
            extras.append({"titulo": "Corte / elevación", "ruta": cortes})
        # Los adjuntos de ESTA planta (cisterna, techos, lo que se colgara).
        _nom = os.path.basename(limpio or "")
        for p_cfg in (estado.get("edificio") or []):
            if os.path.basename(p_cfg.get("dxf") or "") != _nom:
                continue
            for adj in (p_cfg.get("adjuntos") or []):
                if adj.get("ruta") and os.path.exists(adj["ruta"]):
                    extras.append({"titulo": _etiq_adj(adj.get("que", "otro")),
                                   "ruta": adj["ruta"]})
        extras += evidencia_extra.get(_nom, [])
        return limpio, info, extras

    def _contorno_de(nombre):
        """El contorno en planta de un elemento, buscado por su nombre.

        Es lo que permite que CUALQUIER elemento tenga evidencia sin que haya
        que llevarle las coordenadas a mano por cada aviso.
        """
        if not nombre:
            return None
        try:
            ents = (motor.modelo or {}).get("entities") or {}
        except Exception:
            return None
        nom = str(nombre).strip().upper()
        for e in ents.values():
            pr = e.get("properties") or {}
            if str(pr.get("nombre") or "").strip().upper() != nom:
                continue
            v = _contorno_crudo(e)
            if v:
                return v
        return None

    def _contorno_crudo(e):
        """El contorno en planta de una entidad del kernel.

        Vive en `entity["geometry"]["outer"]`. Se buscan también las otras
        formas por si alguna categoría lo guarda distinto: la evidencia tiene
        que salir para TODOS los elementos, sin excepción, y un elemento sin
        imagen es un elemento del que Willy no puede comprobar nada.
        """
        g = e.get("geometry")
        candidatos = []
        if isinstance(g, dict):
            candidatos += [g.get("outer"), g.get("poly"), g.get("contorno"),
                           g.get("points")]
        elif isinstance(g, (list, tuple)):
            candidatos.append(g)
        pr = e.get("properties") or {}
        candidatos += [e.get("footprint"), e.get("outer"), pr.get("outer"),
                       pr.get("contorno")]
        for v in candidatos:
            if v and isinstance(v, (list, tuple)) and len(v) >= 3:
                try:
                    return [(float(q[0]), float(q[1])) for q in v]
                except (TypeError, ValueError, IndexError):
                    continue
        return None

    def _contorno_parcial(trozo):
        """Busca un elemento cuyo nombre CONTENGA el código.

        Los vanos se llaman «M02-P2»: el aviso habla de «P2» y el nombre
        exacto no existe. Se prefiere el más corto, que es el más específico.
        """
        if not trozo:
            return None
        try:
            ents = (motor.modelo or {}).get("entities") or {}
        except Exception:
            return None
        t = str(trozo).strip().upper()
        candidatos = []
        for e in ents.values():
            nom = str((e.get("properties") or {}).get("nombre") or "").upper()
            if nom and (t == nom or nom.endswith("-" + t) or t in nom):
                v = _contorno_crudo(e)
                if v:
                    candidatos.append((len(nom), v))
        return min(candidatos)[1] if candidatos else None

    def _contorno_de_viga(codigo):
        """El contorno de una viga. Viajan fuera del kernel, en el resumen."""
        if not codigo:
            return None
        cod = str(codigo).strip().upper()
        for vg in ((getattr(motor, "resumen", None) or {}).get("vigas") or []):
            if str(vg.get("nombre") or "").strip().upper() != cod:
                continue
            for clave in ("contorno", "outer", "poly", "footprint", "puntos"):
                v = vg.get(clave)
                if v and isinstance(v, (list, tuple)) and len(v) >= 3:
                    try:
                        return [(float(p[0]), float(p[1])) for p in v]
                    except (TypeError, ValueError, IndexError):
                        continue
        return None

    def _zona_de(aviso):
        """De dónde recortar: contorno del elemento, o el punto del aviso."""
        poly = aviso.get("poly")
        if not poly:
            poly = _contorno_de(aviso.get("elemento") or aviso.get("codigo"))
        if not poly:
            # El código del aviso, buscado como TROZO del nombre. Los vanos se
            # llaman «M02-PS-1»: pedir el nombre exacto «PS-1» no encontraba
            # nada y el aviso se quedaba sin imagen.
            poly = _contorno_parcial(aviso.get("elemento")
                                     or aviso.get("codigo"))
        if not poly:
            # Muchos ids llevan el nombre dentro: «conflicto::VG01»,
            # «ancho::P-1::2».
            for trozo in str(aviso.get("id") or "").split("::")[1:]:
                poly = _contorno_de(trozo)
                if poly:
                    break
        if not poly:
            # Y cuando el id es un nombre de CAPA («subtipo::MURO CISTERNA»),
            # el elemento va nombrado dentro del texto: «1 muro(s) (M22)».
            # Sin esto, justo los avisos más importantes se quedaban sin
            # imagen, que es lo único que permite comprobarlos.
            for cod in re.findall(r"\b((?:MB|MV|VG|M|C|P|V)-?\d{1,3})\b",
                                  str(aviso.get("texto") or "")):
                poly = _contorno_de(cod)
                if poly:
                    break
        if not poly:
            # Los VANOS no se llaman «P2» sino «M02-P2»: el muro que perforan
            # va delante. Buscar el nombre exacto no encontraba ninguno y el
            # paso de Vanos entero se quedaba sin una sola imagen.
            # Los códigos de Willy no son solo P/V/M: hay PS-1 (portón
            # seccional), VA-1 (ventana alta), MB (muro bajo)… Con el patrón
            # antiguo, «PS-1» no casaba con nada y justo esos avisos salían
            # sin una sola imagen.
            for cod in re.findall(r"\b([A-Z]{1,3}-?\d{1,3}|vano_polilinea\S*)\b",
                                  str(aviso.get("texto") or "")
                                  + " " + str(aviso.get("id") or "")):
                poly = _contorno_parcial(cod)
                if poly:
                    break
        if not poly:
            # Las VIGAS no son entidades del kernel: viajan aparte, en el
            # resumen. Sin esto, los 21 avisos de vigas salían sin imagen.
            for cod in re.findall(r"\bVG-?\d{1,3}\b",
                                  str(aviso.get("texto") or "")
                                  + " " + str(aviso.get("id") or "")):
                poly = _contorno_de_viga(cod)
                if poly:
                    break
        punto = None
        if aviso.get("x") is not None and aviso.get("y") is not None:
            punto = (float(aviso["x"]), float(aviso["y"]))
        return poly, punto

    def _mostrar_observaciones_menores():
        """Las «N observaciones menores» dejan de esconderse en un txt.

        SketchUp avisaba «hay 12 observaciones menores: detalle en la Consola
        Ruby y en salidas/analisis.txt». Willy no las veía nunca. Ahora se
        vuelcan al registro de ORA, que es donde mira.
        """
        try:
            ruta = os.path.join(BASE, "salidas", "analisis.txt")
            if not os.path.exists(ruta):
                return 0
            with open(ruta, encoding="utf-8", errors="ignore") as f:
                lineas = [l.strip() for l in f if l.strip()]
        except Exception:
            return 0
        if not lineas:
            return 0
        log(f"— {len(lineas)} observación(es) de SketchUp —", "warn")
        for l in lineas[:20]:
            log("   · " + l[:160], "warn")
        if len(lineas) > 20:
            log(f"   … y {len(lineas) - 20} más en salidas/analisis.txt", "warn")
        return len(lineas)

    def _pintar_escena(padre, esc, estado_v, cb_zoom):
        """Pinta la escena en un `tk.Canvas`. SIN matplotlib.

        Esto es lo que arregla el fallo de la v46: allí se generaba un PNG con
        matplotlib, que en la máquina de Willy no está instalado. Todas las
        imágenes salían como «no se pudo leer esta zona» y el motivo real se
        escribía en una consola que él no ve. Tkinter viene con Python: aquí
        no hay nada que instalar y no hay nada que pueda fallar en silencio.
        """
        marco = tk.Frame(padre, bd=1, relief="solid", bg="white")
        marco.pack(fill="both", expand=True)
        if esc.get("imagen"):
            try:
                img = tk.PhotoImage(file=esc["imagen"])
                estado_v["imgs"].append(img)      # que no lo barra el GC
                tk.Label(marco, image=img, bg="white").pack(fill="both",
                                                            expand=True)
                return
            except Exception as ex:
                esc["error"] = f"no pude mostrar la imagen: {ex}"
        cv = tk.Canvas(marco, bg="white", highlightthickness=0, height=420)
        cv.pack(fill="both", expand=True)
        if esc.get("error"):
            cv.create_text(10, 14, anchor="nw", fill="#b45309", width=480,
                           font=("Segoe UI", 10),
                           text="⚠ " + esc["error"])
            return

        cx, cy, r = esc["vista"]

        def dibujar(_e=None):
            cv.delete("all")
            an = max(cv.winfo_width(), 60)
            al = max(cv.winfo_height(), 60)
            k = min(an, al) / (2.0 * r)          # metros -> píxeles
            ox, oy = an / 2.0, al / 2.0

            def P(x, y):
                # Y se invierte: en el plano crece hacia arriba, en el lienzo
                # hacia abajo.
                return (ox + (x - cx) * k, oy - (y - cy) * k)

            for pts in esc["lineas"]:
                pl = []
                for x, y in pts:
                    pl.extend(P(x, y))
                if len(pl) >= 4:
                    cv.create_line(*pl, fill="#98a2ae", width=1)
            for x, y, txt in esc["textos"]:
                px, py = P(x, y)
                cv.create_text(px, py, text=txt, anchor="w", fill="#0f766e",
                               font=("Segoe UI", 8))
            m = esc.get("marca")
            if m and m["tipo"] == "poly":
                pl = []
                for x, y in m["puntos"]:
                    pl.extend(P(x, y))
                pl.extend(P(*m["puntos"][0]))
                if len(pl) >= 4:
                    cv.create_polygon(*pl, fill="#fde2e7", outline="")
                    cv.create_line(*pl, fill="#e11d48", width=3)
            elif m:
                px, py = P(*m["centro"])
                rr = m["radio"] * k
                cv.create_oval(px - rr, py - rr, px + rr, py + rr,
                               outline="#e11d48", width=3)

        cv.bind("<Configure>", dibujar)
        # Rueda para acercar: recorta de nuevo el DXF, así el detalle es real
        # y no un PNG estirado.
        cv.bind("<MouseWheel>",
                lambda e: cb_zoom(1.25 if e.delta > 0 else 0.8))
        cv.bind("<Button-4>", lambda e: cb_zoom(1.25))
        cv.bind("<Button-5>", lambda e: cb_zoom(0.8))
        cv.after(30, dibujar)

    def _ventana_evidencia(titulo, poly=None, punto=None, nombre=""):
        """Las dos imágenes de un elemento suelto, desde la tabla."""
        _abrir_visor([{"id": "elemento", "texto": titulo, "poly": poly,
                       "x": (punto or (None, None))[0],
                       "y": (punto or (None, None))[1],
                       "nombre_el": nombre, "opciones": []}], 0,
                     cabecera=titulo)

    def _abrir_visor(avisos, indice=0, cabecera=""):
        """LA VENTANA. Un aviso a la vez, con sus imágenes y su edición.

        Antes salía una lista interminable de tarjetas y había que creerse cada
        una. Ahora se ve de uno en uno: el texto, las dos imágenes grandes con
        zoom, el campo para corregir y los botones. Confirmas y pasa al
        siguiente.
        """
        t = win_avisos.get("top")
        if t is not None and t.winfo_exists():
            t.destroy()
        t = tk.Toplevel(root)
        t.title("ORA — revisar con la evidencia delante")
        t.geometry("1180x820")
        t.minsize(900, 620)
        t.protocol("WM_DELETE_WINDOW", _cerrar_avisos)
        win_avisos["top"] = t
        tema = TEMAS[estado["tema"]]
        t.configure(bg=tema["bg"])

        estado_v = {"i": max(0, min(indice, len(avisos) - 1)), "zoom": 1.0,
                    "imgs": []}

        cab = tk.Frame(t, bg=tema["bg"])
        cab.pack(fill="x", padx=14, pady=(12, 4))
        lbl_paso = tk.Label(cab, text="", font=("Segoe UI", 9, "bold"),
                            bg=tema["bg"], fg="#1e6fd9", anchor="w")
        lbl_paso.pack(anchor="w")
        lbl_txt = tk.Label(cab, text="", font=("Segoe UI", 11), bg=tema["bg"],
                           fg=tema["texto"], anchor="w", justify="left",
                           wraplength=1120)
        lbl_txt.pack(anchor="w", pady=(4, 0))

        fr_img = tk.Frame(t, bg=tema["bg"])
        fr_img.pack(fill="both", expand=True, padx=14, pady=8)

        fr_ed = tk.Frame(t, bg=tema["bg"])
        fr_ed.pack(fill="x", padx=14)

        fr_nav = tk.Frame(t, bg=tema["bg"])
        fr_nav.pack(fill="x", padx=14, pady=(6, 12))

        def _pintar():
            for w in fr_img.winfo_children():
                w.destroy()
            for w in fr_ed.winfo_children():
                w.destroy()
            for w in fr_nav.winfo_children():
                w.destroy()
            estado_v["imgs"] = []
            if not avisos:
                tk.Label(fr_img, text="No queda nada por revisar en este paso.",
                         bg=tema["bg"], fg=tema["texto"],
                         font=("Segoe UI", 11)).pack(pady=40)
                tk.Button(fr_nav, text="Cerrar", command=_cerrar_avisos,
                          padx=16, pady=6).pack(side="right")
                return
            a = avisos[estado_v["i"]]
            _piso = (f"Piso {nivel_activo['piso']} · "
                     if nivel_activo.get("modo") == "edificio" else "")
            lbl_paso.configure(
                text=f"{_piso}{cabecera or paso_actual['clave']} — "
                     f"aviso {estado_v['i'] + 1} de {len(avisos)}"
                     + (f"   ·   zoom {estado_v['zoom']:.1f}×"
                        if estado_v["zoom"] != 1.0 else ""))
            # QUIÉN LO DIJO. Willy: «indícame cuál ha detectado la IA con
            # una etiqueta y qué es lo que ha detectado ORA». Sin esto no hay
            # forma de saber si la IA sirve o solo estorba.
            _et = a.get("etiqueta") or ("🤖 IA" if a.get("origen") == "ia"
                                        else "🔍 ORA · leído del plano")
            lbl_paso.configure(text=lbl_paso.cget("text") + f"   ·   {_et}")
            lbl_txt.configure(text=("⚠  " if a.get("grave") else "")
                              + str(a.get("texto") or ""),
                              fg=("#7c3c05" if a.get("origen") == "ia"
                                  else tema["texto"]))

            # ---- las imágenes ----
            # NO SE BLOQUEA LA VENTANA (v54). Recortar los dos planos cuesta
            # 1.7 s la primera vez, y se hacía aquí mismo, en el hilo de la
            # interfaz: por eso salía «ORA Modeler (No responde)» en cada
            # clic de Siguiente y en cada zoom. Ahora se pinta el texto ya, y
            # las imágenes entran cuando están.
            poly, punto = _zona_de(a)
            limpio, info, extras = _planos_del_paso()
            if not (poly or punto):
                tk.Label(fr_img, bg=tema["bg"], fg="#b45309",
                         font=("Segoe UI", 10), justify="left",
                         text="Este aviso no señala un sitio del plano, así "
                              "que no hay zona que recortar.").pack(anchor="w",
                                                                    pady=6)
            else:
                _cargando = tk.Label(
                    fr_img, bg=tema["bg"], fg="#64748b", font=("Segoe UI", 10),
                    text="Recortando la zona de los planos…")
                _cargando.pack(anchor="w", pady=6)
                _sello = (estado_v["i"], estado_v["zoom"])

                def _traer():
                    try:
                        import evidencia
                        _r = evidencia.para_elemento(
                            limpio, info, poly=poly, punto=punto,
                            nombre=(a.get("nombre_el") or ""), extras=extras,
                            zoom=estado_v["zoom"])
                        _e = None
                    except Exception as ex:
                        _r, _e = [], str(ex)
                    root.after(0, lambda: _poner(_r, _e))

                def _poner(imgs, err):
                    # Si ya cambió de aviso o de zoom, esto llegó tarde.
                    if (estado_v["i"], estado_v["zoom"]) != _sello:
                        return
                    if not _cargando.winfo_exists():
                        return
                    _cargando.destroy()
                    if err:
                        tk.Label(fr_img, bg=tema["bg"], fg="#b45309",
                                 text=f"No pude generar la evidencia: {err}"
                                 ).pack(anchor="w")
                        return
                    if not imgs:
                        tk.Label(fr_img, bg=tema["bg"], fg="#b45309",
                                 font=("Segoe UI", 10), justify="left",
                                 text="No conseguí recortar esa zona de los "
                                      "planos.").pack(anchor="w", pady=6)
                        return
                    _pintar_columnas(imgs)

                threading.Thread(target=_traer, daemon=True).start()

            # ---- corregir aquí mismo ----
            if a.get("editable") or a.get("opciones"):
                tk.Label(fr_ed, text="Corrige aquí mismo:", bg=tema["bg"],
                         fg=tema["texto"], font=("Segoe UI", 9, "bold")
                         ).pack(anchor="w")
            fila = tk.Frame(fr_ed, bg=tema["bg"])
            fila.pack(fill="x", pady=(2, 6))
            var = tk.StringVar()
            if a.get("editable"):
                tk.Entry(fila, textvariable=var, width=34,
                         font=("Segoe UI", 10)).pack(side="left", padx=(0, 4))
                tk.Label(fila, text=a.get("placeholder", ""),
                         font=("Segoe UI", 8), bg=tema["bg"], fg="#64748b"
                         ).pack(side="left", padx=(0, 8))
                tk.Button(fila, text="✔ Aplicar", cursor="hand2",
                          bg="#1e6fd9", fg="white", relief="flat", padx=12,
                          command=lambda: _resolver_y_seguir(a, var.get())
                          ).pack(side="left", padx=2)
            for etq, val in (a.get("opciones") or []):
                tk.Button(fila, text=etq, font=("Segoe UI", 9), cursor="hand2",
                          command=lambda _a=a, _v=val: _resolver_y_seguir(_a, _v)
                          ).pack(side="left", padx=2)

            # ---- navegación ----
            tk.Button(fr_nav, text="◀ Anterior", cursor="hand2",
                      state=("normal" if estado_v["i"] > 0 else "disabled"),
                      command=lambda: _ir(-1)).pack(side="left")
            tk.Button(fr_nav, text="Siguiente ▶", cursor="hand2",
                      state=("normal" if estado_v["i"] < len(avisos) - 1
                             else "disabled"),
                      command=lambda: _ir(1)).pack(side="left", padx=6)
            tk.Button(fr_nav, text="➖", command=lambda: _zoom(0.8),
                      width=3).pack(side="left", padx=(18, 2))
            tk.Button(fr_nav, text="🔍 100%",
                      command=lambda: _zoom(None)).pack(side="left", padx=2)
            tk.Button(fr_nav, text="➕", command=lambda: _zoom(1.25),
                      width=3).pack(side="left", padx=2)
            tk.Button(fr_nav, text="🖼 Agregar imagen", cursor="hand2",
                      command=_agregar_imagen).pack(side="left", padx=16)
            tk.Button(fr_nav, text="🤖 Que lo mire la IA", cursor="hand2",
                      command=lambda _a=a: _pedir_ia(_a)).pack(side="left")
            tk.Button(fr_nav, text="Cerrar", command=_cerrar_avisos,
                      padx=14).pack(side="right")

        def _pintar_columnas(imgs):
            tema = TEMAS[estado["tema"]]
            for d in imgs:
                col = tk.Frame(fr_img, bg=tema["bg"])
                # La vista de ubicación va estrecha: sirve para situarse de un
                # vistazo, no para leerla. Las dos grandes son las que se
                # miran de verdad.
                if d.get("mini"):
                    col.pack(side="left", fill="y", padx=6)
                    col.configure(width=250)
                    col.pack_propagate(False)
                else:
                    col.pack(side="left", fill="both", expand=True, padx=6)
                tk.Label(col, text=d["titulo"], font=("Segoe UI", 9, "bold"),
                         bg=tema["bg"], fg=tema["texto"]).pack(anchor="w")
                _pintar_escena(col, d, estado_v, _zoom)
                pie = (d.get("error") or d.get("fuente") or "")
                tk.Label(col, text=pie, font=("Segoe UI", 8), bg=tema["bg"],
                         fg=("#b45309" if d.get("error") else "#64748b"),
                         wraplength=520, justify="left").pack(anchor="w")

        def _ir(d):
            estado_v["i"] = max(0, min(estado_v["i"] + d, len(avisos) - 1))
            _pintar()

        def _zoom(f):
            estado_v["zoom"] = 1.0 if f is None else max(
                0.25, min(estado_v["zoom"] * f, 12.0))
            _pintar()

        def _agregar_imagen():
            ruta = filedialog.askopenfilename(
                title="Plano o imagen para adjuntar a esta evidencia",
                parent=t,
                filetypes=[("Planos e imágenes", "*.dxf *.png *.jpg *.jpeg"),
                           ("Todos", "*.*")])
            if not ruta:
                return
            _nom = os.path.basename(getattr(motor, "archivo", "") or "")
            evidencia_extra.setdefault(_nom, []).append(
                {"titulo": os.path.basename(ruta), "ruta": ruta})
            _pintar()

        def _pedir_ia(a):
            """Le enseña a la IA las dos imágenes de esta zona.

            Lo que devuelva entra como duda etiquetada, con sus botones. La IA
            señala; el código sigue siendo el único que reconstruye.
            """
            poly, punto = _zona_de(a)
            if not (poly or punto):
                messagebox.showinfo(
                    "ORA", "Este aviso no señala un sitio del plano, así que "
                           "no hay recorte que enseñarle a la IA.\n\n"
                           "Si sabes dónde está, usa «🖼 Agregar imagen» para "
                           "colgarle el corte o la foto de esa zona y vuelve "
                           "a pulsar.", parent=t)
                return
            limpio, info, extras = _planos_del_paso()
            log("Preguntando a la IA…", "info")

            def trabajo():
                try:
                    import evidencia
                    import segunda_opinion as so
                    escs = evidencia.para_elemento(limpio, info, poly=poly,
                                                   punto=punto, extras=extras)
                    h, quien, err = so.revisar_zona(
                        escs[1:], [str(a.get("texto") or "")])
                except Exception as ex:
                    h, quien, err = [], None, str(ex)
                root.after(0, lambda: aplicar(h, quien, err))

            def aplicar(h, quien, err):
                if err:
                    log(f"La IA no pudo responder: {err}", "warn")
                    messagebox.showwarning(
                        "ORA", f"La IA no respondió:\n\n{err}",
                        parent=t if t.winfo_exists() else root)
                    return
                if not h:
                    log(f"La IA ({quien}) no vio nada que ORA no tuviera ya.",
                        "ok")
                    return
                import segunda_opinion as so
                nuevos = so.a_avisos(h, quien, a.get("id", "zona"), poly, punto)
                for k, nv in enumerate(nuevos):
                    avisos.insert(estado_v["i"] + 1 + k, nv)
                log(f"La IA ({quien}) encontró {len(nuevos)} cosa(s) que ORA "
                    "no estaba usando.", "ok")
                if t.winfo_exists():
                    _pintar()

            threading.Thread(target=trabajo, daemon=True).start()

        def _resolver_y_seguir(a, valor):
            def _hacer():
                _resolver_aviso(a, valor)
                if a in avisos:
                    avisos.remove(a)
                estado_v["i"] = min(estado_v["i"], max(0, len(avisos) - 1))
                if t.winfo_exists():
                    _pintar()
            root.after(0, _hacer)

        _pintar()
        try:
            t.attributes("-topmost", True)
            t.lift()
            t.after(700, lambda: t.winfo_exists()
                    and t.attributes("-topmost", False))
        except Exception:
            pass
        return t

    def _ventana_avisos(clave, avisos):
        win_avisos["cerrada_por_ti"] = False
        return _abrir_visor(list(avisos), 0, cabecera=_ETIQ_PASO.get(clave, clave))


    def _avisos_automaticos():
        """¿La ventana de avisos sale sola? (v59)

        Encendido por defecto: mientras el sistema se estabiliza, ver cada
        hallazgo con su evidencia delante es justo lo que prueba que ORA está
        leyendo bien el plano. Se apaga desde Configuración cuando ya sobra.
        """
        try:
            from ia_asistente import cargar_config
            return bool(cargar_config().get("avisos_automaticos", True))
        except Exception:
            return True

    def _marcar_avisos_pendientes():
        avisos_diferidos["pendiente"] = True
        _cerrar_avisos()

    def _pintar_avisos(clave):
        for w in fr_avisos_lista.winfo_children():
            w.destroy()
        avisos = _avisos_del_paso(clave)
        if not avisos:
            fr_avisos.pack_forget()
            _cerrar_avisos()
            return
        # NO se repite el detalle aquí: eso es lo que salía dos veces, en la
        # ventana flotante y en la columna. Aquí queda solo el resumen y el
        # botón para reabrir la ventana si se cerró.
        graves = sum(1 for a in avisos if a.get("grave"))
        lbl_avisos_tit.configure(
            text=f"⚠ {len(avisos)} cosa(s) por revisar en este paso"
                 + (f" · {graves} importante(s)" if graves else ""))
        tk.Label(fr_avisos_lista, wraplength=258, justify="left",
                 font=("Segoe UI", 8),
                 text="Están en la ventana de al lado, con el botón para "
                      "ver cada uno en SketchUp."
                 ).pack(anchor="w")
        tk.Button(fr_avisos_lista, text="🔎 Abrir la ventana de avisos",
                  font=("Segoe UI", 8), cursor="hand2",
                  command=lambda c=clave: _ventana_avisos(
                      c, _avisos_del_paso(c))
                  ).pack(anchor="w", pady=(2, 0))
        fr_avisos.pack(fill="x", pady=(0, 6), before=btn_enviar_paso)
        # ANUNCIO + VENTANA SOLA. Hasta la v35 la ventana solo se abría si el
        # usuario pulsaba el botón de arriba: los avisos existían y no los veía
        # nadie. Willy lo pidió tres veces. Ahora, en CUALQUIERA de los pasos,
        # en cuanto hay algo que revisar se avisa en el registro y la ventana
        # sale sola. El botón queda solo por si la cerraste.
        # LA VENTANA SE ABRE UNA VEZ, NO EN CADA REFRESCO (v54).
        #
        # Willy: «cada vez que avanzo y cada paso me vuelve a salir los avisos
        # con las imágenes, y ahí es donde se produce la parte lenta».
        # Tenía razón. `refrescar_fases()` se llama desde 22 sitios y esta
        # línea DESTRUÍA y volvía a construir la ventana entera cada vez, con
        # sus tres recortes de DXF por delante (1.7 s medidos con sus planos)
        # y saltando encima de lo que estuviera haciendo.
        #
        # Ahora solo se abre si no está abierta, o si lo que hay que revisar
        # cambió de verdad. Si ya la tiene delante con los mismos avisos, no
        # se toca.
        _firma_av = (clave, tuple(sorted(a["id"] for a in avisos)))
        _abierta = win_avisos.get("top")
        _viva = bool(_abierta is not None and _abierta.winfo_exists())
        # INTERRUPTOR DE NOTIFICACIONES (v59). Willy: «ahora las observaciones
        # salen como una especie de notificación… cuando ya se estabilice no
        # va a necesitar todo esto, ahorraría tiempo».
        #
        # Apagado, la ventana deja de salir sola para los avisos LEVES: el
        # resumen y el botón «Abrir la ventana de avisos» siguen ahí, así que
        # nada se pierde, solo deja de interrumpir.
        #
        # LOS GRAVES NO SE PUEDEN SILENCIAR, y es a propósito: un paño sin
        # NPT, una viga sin peralte o un vano sin muro son cosas que ORA NO
        # inventa. Si se pudieran callar, ORA acabaría dando por bueno en
        # silencio justo lo que el proyecto entero se niega a suponer.
        if not _avisos_automaticos() and not graves:
            return
        if avisos_anunciados.get("ultimo") != _firma_av:
            avisos_anunciados["ultimo"] = _firma_av
            log(f"⚠ Encontré {len(avisos)} cosa(s) por revisar en «{clave}»"
                + (f" ({graves} importante(s))" if graves else "")
                + ". Te abro la ventana con cada una.", "warn")
            win_avisos["cerrada_por_ti"] = False
            root.after(0, lambda c=clave: _ventana_avisos(c, _avisos_del_paso(c)))
        elif not _viva and not win_avisos.get("cerrada_por_ti"):
            root.after(0, lambda c=clave: _ventana_avisos(c, _avisos_del_paso(c)))

    def aprender_posiciones_previa():
        """El usuario movió cajas de previa en SketchUp: ORA guarda ese
        corrimiento para que el corte real salga en ese sitio."""
        firma = _firma_actual()
        if not firma or not estado_vivo:
            log("No estoy recibiendo medidas de SketchUp: no puedo leer dónde "
                "moviste las cajas.", "warn")
            return
        from memoria_elementos import guardar_ajuste_vano
        n = 0
        piso = _piso_actual()
        for nombre, m in estado_vivo.items():
            if not nombre.startswith("ORA_PREVIA_"):
                continue
            base = previa_base.get(nombre)
            if not base:
                continue
            dx = round(float(m.get("x", 0)) - base.get("x", 0), 4)
            dy = round(float(m.get("y", 0)) - base.get("y", 0), 4)
            dz = round(float(m.get("z", 0)) - base.get("z", 0), 4)
            # GIRO: si moviste una mampara y además la giraste para ponerla en
            # su sitio, ese giro también se aprende. Antes se perdía y al
            # cortar el vano volvía a salir torcido.
            rot = round(float(m.get("ang", 0)) - float(base.get("ang", 0)), 3)
            if (abs(dx) < 0.002 and abs(dy) < 0.002 and abs(dz) < 0.002
                    and abs(rot) < 0.2):
                continue
            guardar_ajuste_vano(firma, piso, nombre[len("ORA_PREVIA_"):],
                                dx, dy, dz, rot)
            n += 1
        if n:
            log(f"📌 {n} vano(s) reubicados: el corte va a salir donde los "
                "dejaste, con el giro que les diste.", "ok")
            enviar_paso_actual()      # redibuja la previa ya corregida
        else:
            log("No moviste ninguna caja (o el movimiento fue mínimo).", "warn")

    def cortar_vanos_ahora():
        previa_vanos["aprobada"] = True
        paso_actual["enviado"] = False
        log("✂️ Cortando los vanos sobre los muros confirmados…", "ok")
        enviar_paso_actual()

    btn_aprender_previa.configure(command=aprender_posiciones_previa)
    btn_cortar_vanos.configure(command=cortar_vanos_ahora)

    def recortar_vigas_ahora():
        previa_vigas["aprobada"] = True
        previa_vigas["mostrada"] = False
        paso_actual["enviado"] = False
        log("✂️ Recortando las vigas con los muros y la losa como molde. "
            "Ni el muro ni la losa se tocan: solo la viga pierde lo que no "
            "se ve.", "ok")
        enviar_paso_actual()

    def aprender_previa_vigas():
        aprender_posiciones_previa()

    btn_peralte_lote.configure(command=_aplicar_peralte_lote)
    btn_marcar_todas.configure(
        command=lambda: ([v.set(True) for v in marcas_vigas.values()]))
    btn_recortar_vigas.configure(command=recortar_vigas_ahora)
    btn_aprender_previa_vg.configure(command=aprender_previa_vigas)

    def enviar_paso_actual():
        """Manda a SketchUp SOLO lo del paso en curso."""
        fases = _fase_disponible()
        i = paso_actual["i"]
        if not motor.resumen or i >= len(fases):
            return
        clave, _etq = fases[i]
        cats = CATEGORIAS_DE_FASE.get(clave, [clave])
        # VANOS EN DOS TIEMPOS: primero la previa (no perfora), después el corte.
        if clave == "vanos" and not previa_vanos["aprobada"]:
            cats = ["vanos_previa"]
        # VIGAS EN DOS TIEMPOS: primero enteras para revisarlas, después
        # recortadas contra muros y losa.
        motor.vigas_sin_recortar = (clave == "vigas"
                                    and not previa_vigas["aprobada"])
        _avisar_cambios_en_confirmado()

        def al_terminar():
            if clave == "vanos" and not previa_vanos["aprobada"]:
                previa_vanos["mostrada"] = True
                # Foto de dónde quedó cada caja al generarse: contra esto se
                # mide después cuánto la movió el usuario.
                def _foto_previa(intentos=12):
                    hallados = {n: dict(m) for n, m in (estado_vivo or {}).items()
                                if n.startswith("ORA_PREVIA_")}
                    if hallados:
                        previa_base.clear()
                        previa_base.update(hallados)
                    elif intentos > 0:
                        root.after(500, lambda: _foto_previa(intentos - 1))
                root.after(800, _foto_previa)
                log("👁️ Previa de vanos en SketchUp (cajas naranjas). Revisa "
                    "dónde cae cada hueco. Si alguno no está en su sitio, "
                    "muévelo ahí mismo y pulsa «Aprender posiciones». Cuando "
                    "estén todos bien, pulsa «Cortar vanos».", "warn")
            # Ya hay geometría en SketchUp: ahora sí tiene sentido mostrar
            # los avisos con su botón de "Ver dónde está".
            avisos_diferidos["pendiente"] = False
            root.after(400, lambda c=clave: _pintar_avisos(c))
            if clave == "vigas" and not previa_vigas["aprobada"]:
                previa_vigas["mostrada"] = True
                log("👁️ Vigas ENTERAS en SketchUp, sin recortar. Revisa el "
                    "peralte y la posición de cada una. Cuando estén bien, "
                    "pulsa «Recortar vigas» y se quedan solo con la parte "
                    "que se ve.", "warn")
            paso_actual["enviado"] = True
            # La lista de elementos aparece sola: es donde revisas y corriges
            # las medidas de lo que acabas de enviar (antes había que buscarla
            # en un "modo edición" aparte y por eso no se veía).
            if not modo_split["activo"]:
                alternar_modo_split()
            else:
                poblar_lista_elementos()
            refrescar_fases()
        aplicar_en_vivo(categorias=cats, al_terminar=al_terminar)

    def _categoria_de_grupo(nombre):
        """A qué fase pertenece un grupo de SketchUp, por su nombre."""
        n = nombre[4:] if nombre.startswith("ORA_") else nombre
        if n.startswith("Piso_"):
            return "pisos"
        if n.startswith("Techo") or n.startswith("Losa"):
            return "techo"
        if n.startswith("Peldano") or n.startswith("Escalera"):
            return "escalera"
        if re.match(r"^(P\d+-)?C\d+$", n) or n.startswith("Columna"):
            return "columnas"
        # VG01, VG11_2, E1_Viga… Sin esto la viga caía en "muros" y el paso de
        # Vigas no congelaba NADA: lo que el usuario corregía se perdía en la
        # siguiente generación, y "lo confirmado manda" no llegaba a aplicarse
        # nunca aunque el código para usarlo ya estuviera puesto.
        if re.match(r"^(P\d+-)?VG\d", n) or n.startswith("Viga"):
            return "vigas"
        # Panel de carpintería de un vano: se llama con el muro que lo aloja
        # más su código (M01-P-1, M06-V-3#2). El muro pelado es solo 'M01'.
        # Antes ambos caían en la misma bolsa y el paso de Vanos terminaba
        # congelando también los muros.
        if re.search(r"-(P|V|M|PS|VA)-?\d", n):
            return "vanos"
        return "muros"

    def _firma_actual():
        """La etiqueta con la que se archiva lo que confirmas.

        EN EDIFICIO, UNA SOLA PARA TODO (v57). Antes era la firma del plano
        cargado en ese instante, y ahí estaba el fallo más caro de todos:
        SketchUp va apuntando lo que mueves en una cola, y esa cola se vacía
        en la SIGUIENTE generación, sea del nivel que sea. Willy empezó por
        la cisterna, así que sus correcciones de los pisos 1, 2 y 3 quedaron
        archivadas bajo la firma de la cisterna:

            e88b7031be6b996e::piso1   medidas=73     <- eran del PISO 1
            e88b7031be6b996e::piso2   posiciones=44  <- eran de la TÍPICA
            7ff7deb273c24e0c::piso1   congelados=54  <- esta sí, la del piso 1

        Al regenerar el piso 1, ORA leía en `7ff7...::piso1` y encontraba
        CERO posiciones. Las 44 buenas estaban en el otro cajón. Por eso
        «me movió todo» al cortar vanos y al poner columnas.

        Con una etiqueta única por edificio no hay dos cajones posibles: lo
        que separa los niveles es el número de piso, que ya viene del propio
        plugin (`P2::ORA_M01`). Un plano suelto conserva su firma por plano,
        que ahí sí es lo correcto.
        """
        if nivel_activo.get("modo") == "edificio":
            _f = _firma_del_edificio()
            if _f:
                return _f
        return ((motor.resumen or {}).get("clasificacion_capas") or {}).get("firma")

    def _firma_del_edificio():
        """Etiqueta estable del edificio: los planos limpios que lo componen.

        No depende de qué planta esté cargada ni del orden en que se carguen.
        """
        rutas = sorted(os.path.basename(p.get("dxf") or "").lower()
                       for p in (estado.get("edificio") or [])
                       if p.get("dxf"))
        if not rutas:
            return None
        import hashlib
        return "ED" + hashlib.sha1("|".join(rutas).encode("utf-8")).hexdigest()[:14]

    def _piso_actual():
        """Índice del piso que está seleccionado ahora mismo.

        BUG (FASE 0.1): confirmar_paso() congelaba SIEMPRE en el piso 0, sin
        mirar en qué nivel estabas parado. En un edificio, lo que corregías en
        el piso 2 se guardaba en la misma bolsa que el piso 1 y se pisaban
        entre sí. Con planta típica repetida era peor todavía: los pisos 3, 4
        y 5 comparten los mismos nombres de muro (M01, M02...), así que las
        correcciones de los tres caían encima de las mismas claves.
        """
        # EL BUG QUE HACÍA PERDER TODO LO CONFIRMADO (v48).
        #
        # Había DOS numeraciones de piso peleándose:
        #   · El plugin manda «P1::ORA_M01» -> piso 1, 1-based.
        #   · Esta función devolvía el índice del desplegable -> 0, 0-based.
        #
        # Resultado: las medidas y posiciones que llegaban de SketchUp se
        # guardaban en «firma::piso1», y los congelados y las decisiones en
        # «firma::piso0». Se escribía en una bolsa y se leía de la otra. Por
        # eso los avisos ya resueltos volvían a salir, la cisterna perdía su
        # 1.95 desde -1.80 y los vanos que Willy había colocado se movían al
        # cortar. En un piso no se notaba porque las dos daban 0.
        #
        # Ahora manda el NIVEL REAL, el mismo que usa el plugin. Y de paso
        # los dos carriles quedan separados solos, que es como Willy los
        # quiere: un plano suelto vive en «piso0» y no se cruza jamás con el
        # «piso1» de un edificio.
        if nivel_activo.get("modo") == "edificio":
            return int(nivel_activo.get("piso") or 0)
        try:
            m = motor.kernel.to_dict() if getattr(motor, "kernel", None) else None
            if not m:
                return 0
            niveles = sorted(m["levels"].items(), key=lambda kv: kv[1]["elevation"])
            nombres = [f"Piso {i+1}" for i in range(len(niveles))] or ["Piso 1"]
            sel = var_piso_sel.get()
            return nombres.index(sel) if sel in nombres else 0
        except Exception:
            return 0

    def _z_base_del_piso(idx):
        """Cota que hay que restarle a lo que reporta SketchUp al congelar.

        AHORA ES SIEMPRE CERO, Y ESTÁ BIEN QUE LO SEA (v58).

        El plugin mide cada grupo DENTRO de su contenedor `ORA_PISO_n`, así
        que lo que llega ya es local a la planta; y desde la v58 la planta se
        genera en 0.00 local. No hay nada que restar: hacerlo era restar dos
        veces.

        Y había una mina: `idx` es el NIVEL del edificio, que puede ser -1
        (cisterna). `niveles[-1]` en Python no es «el nivel -1», es el ÚLTIMO
        de la lista — a la cisterna se le restaba la cota de otra planta al
        congelar. Se conserva la función porque la llaman dos sitios.
        """
        return 0.0

    def confirmar_paso():
        """El usuario dice que ese paso quedó bien.

        Aquí está lo importante: se CONGELA lo que hay en SketchUp en este
        momento como la verdad definitiva de esos elementos. De ahí en
        adelante ORA los reconstruye con ESAS medidas — antes, al pasar a la
        fase siguiente, los muros ya corregidos volvían al estado del DXF.
        """
        fases = _fase_disponible()
        i = paso_actual["i"]
        if i >= len(fases):
            return
        clave, etiqueta = fases[i]

        firma = _firma_actual()
        if not estado_vivo:
            if not messagebox.askyesno(
                    "ORA — sin contacto con SketchUp",
                    "No estoy recibiendo medidas de SketchUp, así que no puedo "
                    "congelar lo que hiciste allá.\n\n"
                    "Revisa que el plugin esté instalado y SketchUp abierto.\n\n"
                    "¿Marcar el paso igual, sin congelar?"):
                return
            propios = {}
        else:
            mapa = {"muros_pisos": ("muros", "pisos"),
                    # Vanos SOLO congela los vanos. El muro ya quedó definitivo
                    # en el paso anterior y no se vuelve a tocar.
                    "vanos": ("vanos",),
                    "columnas": ("columnas",), "techo": ("techo",),
                    "escalera": ("escalera",)}
            quiere = mapa.get(clave, (clave,))
            propios = {n: m for n, m in estado_vivo.items()
                       if _categoria_de_grupo(n) in quiere}

        if not messagebox.askyesno(
                "ORA — confirmar paso",
                f"¿Confirmas «{etiqueta}»?\n\n"
                f"Se congelan {len(propios)} elemento(s) tal como están AHORA en "
                "SketchUp. ORA ya no los va a rehacer: en los pasos siguientes "
                "los respeta como definitivos.\n\n"
                "Si algo no calza, usa Reintentar en vez de confirmar."):
            return

        if firma and propios:
            try:
                from memoria_elementos import congelar
                piso = _piso_actual()
                # ---- TRACE: identidad de este paso de confirmación ----
                trace_forense.fijar_contexto(
                    firma=firma, piso_visual=piso, piso_logico=piso,
                    motor_piso_activo=getattr(motor, "piso_activo", None),
                    nivel_activo_piso=nivel_activo.get("piso"),
                    modo=nivel_activo.get("modo"))
                # FASE 0.2: SketchUp reporta la Z ABSOLUTA del modelo completo
                # (ya incluye la altura acumulada de los pisos de abajo). El
                # motor, al reconstruir, le vuelve a sumar la cota del nivel:
                # si guardáramos la absoluta, en cualquier piso que no fuera el
                # primero la altura se duplicaría. Se guarda relativa a su
                # propio nivel.
                zb = _z_base_del_piso(piso)
                if zb:
                    propios = {n: dict(m, z=round(float(m.get("z", 0)) - zb, 4))
                               for n, m in propios.items()}
                # ---- TRACE: CONFIRMACIÓN, elemento por elemento -------
                # Esta es la clave literal de guardado que pedía el
                # encargo: firma + piso + elemento + campo. Se marca
                # es_confirmacion=True porque esto es una acción explícita
                # de Willy en SketchUp — cualquier escritura posterior bajo
                # esta misma clave con un valor distinto queda marcada como
                # inconsistencia automáticamente (Z_CAMBIA_DESPUES_DE_
                # CONFIRMACION), venga de generar_vigas(), de Ruby o de
                # donde sea.
                for _nombre_el, _medidas in propios.items():
                    for _campo, _valor in (_medidas or {}).items():
                        trace_forense.escritura(
                            archivo="memoria_elementos.json",
                            funcion="confirmar_paso", firma=firma, piso=piso,
                            elemento=_nombre_el, campo=_campo, valor=_valor,
                            es_confirmacion=True, fase=clave)
                n = congelar(firma, piso, propios, fase=clave)
                log(f"🔒 {n} elemento(s) congelados en el piso {piso + 1}: "
                    "ORA ya no los rehace.", "ok")
            except Exception as ex:
                trace_forense.excepcion(
                    ex, funcion="confirmar_paso",
                    motor_piso_activo=getattr(motor, "piso_activo", None),
                    nivel_activo_piso=nivel_activo.get("piso"), firma=firma)
                log(f"No se pudieron congelar: {ex}", "warn")

        estado_fases[clave] = True
        paso_actual["i"] = i + 1
        paso_actual["enviado"] = False
        _marcar_avisos_pendientes()
        previa_vanos.update(mostrada=False, aprobada=False)
        log(f"✅ Paso confirmado: {etiqueta}", "ok")
        refrescar_fases()
        poblar_lista_elementos()      # la tabla ya solo muestra el paso nuevo

    def reintentar_paso():
        """Volver a mandar el paso tras ajustar algo en ORA."""
        paso_actual["enviado"] = False
        refrescar_fases()
        log("Ajusta lo que necesites y vuelve a enviar el paso.", "warn")

    def descartar_paso():
        """El usuario ya lo corrigió a mano en SketchUp: ORA respeta su versión."""
        fases = _fase_disponible()
        i = paso_actual["i"]
        if i >= len(fases):
            return
        clave, etiqueta = fases[i]
        if not messagebox.askyesno(
                "ORA — usar tu versión",
                f"¿Te quedas con tu versión de «{etiqueta}» hecha en SketchUp?\n\n"
                "ORA no volverá a regenerar esa parte. Guarda en SketchUp "
                "(Ctrl+S) para que ORA aprenda definitivamente lo que dejaste."):
            return
        estado_fases[clave] = True
        paso_actual["i"] = i + 1
        paso_actual["enviado"] = False
        _marcar_avisos_pendientes()
        log(f"Tu versión de «{etiqueta}» se respeta. Guarda en SketchUp para "
            "que ORA la aprenda.", "warn")
        refrescar_fases()

    def paso_anterior():
        if paso_actual["i"] > 0:
            paso_actual["i"] -= 1
            paso_actual["enviado"] = False
            previa_vanos.update(mostrada=False, aprobada=False)
            refrescar_fases()
            poblar_lista_elementos()

    def aplicar_en_vivo(categorias=None, al_terminar=None):
        """Regenera el modelo y emite un pulso: si SketchUp tiene la
        Sincronización EN VIVO activada, se actualiza solo, sin reabrir.
        `categorias`: None = todo; ['muros'] = solo esa parte (flujo por fases)."""
        # Sin plano analizado NO hay kernel: `motor.generar()` haría
        # `self.kernel.to_dict()` sobre None y reventaba con
        # "'NoneType' object has no attribute 'to_dict'", que no le dice nada
        # a nadie. Se avisa en cristiano y no se intenta.
        if getattr(motor, "kernel", None) is None or not motor.resumen:
            messagebox.showinfo(
                "ORA",
                "Todavía no hay ningún plano analizado.\n\n"
                "Elige tu DXF limpio en «1 · Plano» y pulsa ANALIZAR PLANO. "
                "Después ya puedes aplicar en vivo.")
            return
        from sincronizacion_vivo import chequear_plugin
        ok_plugin, msg_plugin = chequear_plugin()
        if ok_plugin is False:
            log(f"⚠️ {msg_plugin}", "warn")
            if not messagebox.askyesno("ORA", msg_plugin + "\n\n¿Continuar de todos modos?"):
                return
        elif ok_plugin is None:
            log(f"ℹ️ {msg_plugin}", "warn")
        cuadro = leer_cuadro_manual()
        if cuadro and cuadro["por_bloque"]:
            try:
                # Re-analizar SIN pasarle el plano de información lo perdía:
                # `Motor.analizar` pone `archivo_specs = None`. A partir de ahí
                # los NPT quedaban al ras, los textos 'H:' desaparecían y salía
                # «No cargaste el plano de INFORMACIÓN» aunque sí estuviera
                # cargado. Se conserva lo que ya tenía el motor.
                motor.analizar(motor.archivo, motor.unidad, cuadro,
                               archivo_specs=getattr(motor, "archivo_specs", None),
                               archivo_cortes=getattr(motor, "archivo_cortes", None))
            except Exception as ex:
                messagebox.showerror("ORA", f"Error re-analizando:\n{ex}")
                return
        try:
            dec = _construir_decisiones()
        except ValueError:
            messagebox.showwarning("ORA", "Revisa los números (altura, losa, escalera).")
            return
        btn_vivo.configure(state="disabled")
        log("Aplicando en vivo...", "warn")

        def trabajo():
            try:
                total = motor.generar(dec, categorias=categorias, preguntar=False)
                from sincronizacion_vivo import emitir_pulso
                ruta_rb = os.path.abspath(os.path.join(BASE, "salidas", "modelo.rb"))
                n = emitir_pulso(ruta_rb)
                aprendido = getattr(motor, "mensajes_aprendizaje", [])
                def fin():
                    que = ", ".join(categorias) if categorias else "todo"
                    log(f"🔴 En vivo #{n}: {total} elemento(s) enviados a SketchUp ({que}).", "ok")
                    # CERO ELEMENTOS = ORA SE PLANTA (v55).
                    #
                    # Willy mandó el sótano y no apareció NADA en SketchUp. Lo
                    # que ORA hizo fue crear el grupo `ORA_PISO_-1` vacío y
                    # callarse: «Modelo ORA generado: 0 elementos». Él tuvo
                    # que venir a preguntar qué había pasado.
                    #
                    # Un nivel que no produce ni una pieza casi siempre es una
                    # capa mal nombrada o geometría que se descartó por una
                    # duda. Se dice ahí mismo, en grande, con las dudas de ese
                    # plano delante.
                    if not total:
                        _quien = ""
                        if nivel_activo.get("modo") == "edificio":
                            _quien = (f" del nivel {nivel_activo.get('piso')}"
                                      if nivel_activo.get("piso") is not None
                                      else "")
                        _dudas = [d for d in ((motor.resumen or {}).get("dudas") or [])][:4]
                        log(f"⛔ Este paso{_quien} no generó NI UN elemento. "
                            "En SketchUp no va a aparecer nada.", "warn")
                        for d in _dudas:
                            log("   · " + str(d)[:180], "warn")
                        messagebox.showwarning(
                            "ORA — este paso no generó nada",
                            f"El paso «{que}»{_quien} no produjo ningún "
                            "elemento, así que en SketchUp no vas a ver nada.\n\n"
                            + ("Lo que ORA descartó de este plano:\n\n· "
                               + "\n\n· ".join(str(d)[:220] for d in _dudas)
                               if _dudas else
                               "El plano no trae geometría de esa categoría, o "
                               "sus capas tienen un nombre que ORA no "
                               "reconoce.")
                            + "\n\nRevísalo antes de seguir: si sigues "
                              "avanzando, este nivel se queda vacío.")
                    for aviso in (getattr(motor, "avisos_escalera", None) or []):
                        log("🪜 " + aviso, "warn")
                    for aviso in (getattr(motor, "avisos_vigas", None) or []):
                        log("🏗️ " + aviso, "warn")
                    # Lo que SketchUp no pudo dibujar: antes quedaba como un
                    # hueco mudo en el modelo.
                    for aviso in (getattr(motor, "avisos_dibujo", None) or []):
                        log("❌ No se pudo dibujar — " + aviso, "warn")
                    for m in aprendido:
                        log(f"🧠 {m}", "ok")
                    if modo_split["activo"]:
                        poblar_lista_elementos()
                    btn_vivo.configure(state="normal")
                    if al_terminar:
                        al_terminar()
                root.after(0, fin)
            except Exception as ex:
                root.after(0, lambda _m=str(ex): (
                    messagebox.showerror("ORA", f"Error al aplicar en vivo:\n{_m}"),
                    btn_vivo.configure(state="normal")))
        threading.Thread(target=trabajo, daemon=True).start()

    def generar():
        if getattr(motor, "kernel", None) is None or not motor.resumen:
            messagebox.showinfo(
                "ORA",
                "Todavía no hay ningún plano analizado.\n\n"
                "Elige tu DXF limpio en «1 · Plano» y pulsa ANALIZAR PLANO.")
            return
        cuadro = leer_cuadro_manual()
        if cuadro and cuadro["por_bloque"]:
            log("Aplicando tu cuadro de vanos...", "warn")
            try:
                # Re-analizar SIN pasarle el plano de información lo perdía:
                # `Motor.analizar` pone `archivo_specs = None`. A partir de ahí
                # los NPT quedaban al ras, los textos 'H:' desaparecían y salía
                # «No cargaste el plano de INFORMACIÓN» aunque sí estuviera
                # cargado. Se conserva lo que ya tenía el motor.
                motor.analizar(motor.archivo, motor.unidad, cuadro,
                               archivo_specs=getattr(motor, "archivo_specs", None),
                               archivo_cortes=getattr(motor, "archivo_cortes", None))
            except Exception as ex:
                messagebox.showerror("ORA", f"Error re-analizando:\n{ex}")
                return
        try:
            dec = _construir_decisiones()
        except ValueError:
            messagebox.showwarning("ORA", "Revisa los números (altura, losa, escalera).")
            return
        btn_generar.configure(state="disabled")
        log("Generando el modelo 3D...", "warn")

        def trabajo():
            try:
                total = motor.generar(dec)
                ok, msg = motor.abrir_sketchup()

                def fin():
                    log(f"✅ Modelo generado ({total} elementos). "
                        + ("SketchUp abierto." if ok else "Abre SketchUp tú."), "ok")
                    messagebox.showinfo("ORA Modeler",
                                        f"Modelo generado: {total} elementos.\n\n{msg}")
                    btn_generar.configure(state="normal")
                root.after(0, fin)
            except Exception as ex:
                root.after(0, lambda _m=str(ex): (
                    messagebox.showerror("ORA", f"Error al generar:\n{_m}"),
                    btn_generar.configure(state="normal"),
                    log("Error en la generación.", "warn")))
        threading.Thread(target=trabajo, daemon=True).start()

    # ---------- aplicar tema ----------
    def aplicar_tema():
        t = T()
        root.configure(bg=t["bg"])
        cab.configure(bg=t["bg"])
        cuerpo.configure(bg=t["bg"])
        izq_cont.configure(bg=t["bg"])
        izq_canvas.configure(bg=t["bg"])
        izq.configure(bg=t["bg"])
        der.configure(bg=t["bg"])
        p3.configure(bg=t["bg"])
        lbl_logo.configure(bg=t["bg"], image=cargar_logo() or "")
        lbl_der.configure(bg=t["bg"], fg=t["texto"])
        btn_config.configure(bg=t["bg"], fg=t["texto"], activebackground=t["bg"])
        btn_ayuda.configure(bg=t["bg"], fg=t["texto"], activebackground=t["bg"])
        btn_biblioteca.configure(bg=t["bg"], fg=t["texto"], activebackground=t["bg"])
        btn_tema.configure(bg=t["bg"], fg=t["texto"],
                           activebackground=t["bg"],
                           text=("☀️  Tema claro" if estado["tema"] == "oscuro"
                                 else "🌙  Tema oscuro"))
        for lf in (p1, p2, p_esc, p_cv, p_fases, p_sel):
            lf.configure(bg=t["panel"], fg=t["texto"],
                         highlightbackground=t["borde"])
            for w in lf.winfo_children():
                cls = w.winfo_class()
                if cls in ("Label", "Checkbutton"):
                    w.configure(bg=t["panel"], fg=t["texto"],
                                activebackground=t["panel"])
                    if cls == "Checkbutton":
                        w.configure(selectcolor=t["panel"])
                elif cls == "Entry":
                    w.configure(bg=t["consola_bg"], fg=t["texto"],
                                insertbackground=t["texto"], relief="solid", bd=1)
                elif cls == "Button":
                    w.configure(bg=t["panel"], fg=t["texto"],
                                activebackground=t["borde"])
        for b in (btn_analizar, btn_generar):
            b.configure(bg=t["acento"], fg=t["acento_txt"],
                        activebackground=t["acento"],
                        activeforeground=t["acento_txt"],
                        disabledforeground="#9aa4b1", relief="flat")
        btn_buscar.configure(bg=t["panel"], fg=t["texto"], relief="solid", bd=1)
        btn_specs.configure(bg=t["panel"], fg=t["texto"], relief="solid", bd=1)
        txt.configure(bg=t["consola_bg"], fg=t["consola_fg"],
                      highlightbackground=t["borde"])
        barra.configure(bg=t["panel"], fg=t["texto"],
                        highlightbackground=t["borde"])

    def alternar_tema():
        estado["tema"] = "oscuro" if estado["tema"] == "claro" else "claro"
        aplicar_tema()

    # ---------------- FASE E, punto 12: tutorial del estándar ----------------
    TUTORIAL = [
        ("1. Capas con prefijo ORA_",
         "ORA_MURO, ORA_MURO_BAJO, ORA_PUERTA, ORA_VENTANA, ORA_COLUMNA,\n"
         "ORA_PISO_CERAMICO, ORA_TECHO, ORA_ESCALERA... Si necesitas una que no\n"
         "existe, créala igual con ORA_ — ORA te pregunta qué es la primera vez\n"
         "y lo recuerda para tus próximos planos."),
        ("2. Muros: polilínea CERRADA",
         "Nunca líneas dobles sueltas. El muro va CORRIDO de columna a columna,\n"
         "sin partirlo en pedazos."),
        ("3. Vanos: polilínea cerrada ENCIMA del muro",
         "Sin bloques dinámicos (ensucian el modelo). El rectángulo del vano se\n"
         "superpone al muro que perfora; su lado largo es el ANCHO real. Escribe\n"
         "su código al lado (P-1, V-2) y pon alto/alféizar en el cuadro de vanos."),
        ("4. Alturas especiales, con un texto cerca",
         "Muro bajo, parapeto o baranda: escribe H:1.10 junto al elemento.\n"
         "Sin ese texto, ORA pregunta — nunca lo asume."),
        ("5. Techos y patios",
         "Dibuja el hueco real del patio como hueco en la polilínea del techo.\n"
         "No lo rellenes 'para que se vea completo'."),
        ("6. Un DXF por piso + su DXF de datos",
         "Cada piso o sótano con su propio par: plano limpio + plano de datos de\n"
         "ESE piso (cuadro de vanos, NPT, ambientes). El corte/elevación es un\n"
         "archivo aparte del edificio completo."),
        ("7. Cortes: convención de letra",
         "La línea de corte en la planta con la letra A en cada extremo, y el\n"
         "dibujo rotulado 'CORTE A - A'' con su altura acotada (H: 2.85).\n"
         "ORA empareja por la letra y usa esa altura real."),
        ("8. Origen y unidades",
         "Todas las plantas con el mismo origen (0,0) del terreno y escala 1:1.\n"
         "Así las columnas y la escalera calzan solas al apilar los pisos.\n"
         "Entrega en ZIP, nunca RAR."),
    ]

    def mostrar_tutorial(forzado=False):
        from ia_asistente import cargar_config, guardar_config
        cfg = cargar_config()
        if not forzado and cfg.get("tutorial_visto"):
            return
        t = T()
        win = tk.Toplevel(root)
        win.title("¿Cómo preparo mi plano? — ORA Modeler")
        win.geometry("640x560")
        win.configure(bg=t["bg"])
        win.transient(root)
        tk.Label(win, text="Cómo preparar tu plano para ORA",
                 bg=t["bg"], fg=t["acento"], font=("Segoe UI", 13, "bold")
                 ).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(win, text="30 segundos de lectura. El estándar es la vía rápida, "
                           "no un muro:\nlo que no lo cumpla, ORA lo pregunta — "
                           "nunca lo asume en silencio.",
                 bg=t["bg"], fg=t["texto"], font=("Segoe UI", 9), justify="left"
                 ).pack(anchor="w", padx=16, pady=(0, 8))
        cuerpo_t = tk.Text(win, wrap="word", font=("Segoe UI", 9), bd=1,
                           relief="solid", padx=10, pady=8,
                           bg=t["consola_bg"], fg=t["consola_fg"])
        cuerpo_t.pack(fill="both", expand=True, padx=16)
        for titulo, texto in TUTORIAL:
            cuerpo_t.insert("end", titulo + "\n", "t")
            cuerpo_t.insert("end", texto + "\n\n")
        cuerpo_t.tag_configure("t", font=("Segoe UI", 10, "bold"))
        cuerpo_t.configure(state="disabled")

        pie = tk.Frame(win, bg=t["bg"])
        pie.pack(fill="x", padx=16, pady=12)
        v_no = tk.BooleanVar(value=bool(cfg.get("tutorial_visto")))
        tk.Checkbutton(pie, text="No volver a mostrar al abrir", variable=v_no,
                       bg=t["bg"], fg=t["texto"], activebackground=t["bg"],
                       selectcolor=t["panel"], font=("Segoe UI", 9)).pack(side="left")

        def abrir_documento():
            ruta = os.path.join(BASE, "ESTANDAR_DE_ENTREGA_ORA.md")
            if os.path.exists(ruta):
                try:
                    if sys.platform == "win32":
                        os.startfile(ruta)
                    else:
                        subprocess.Popen(["xdg-open", ruta])
                except Exception:
                    messagebox.showinfo("ORA", f"El documento está en:\n{ruta}",
                                        parent=win)
            else:
                messagebox.showinfo("ORA", "No encontré ESTANDAR_DE_ENTREGA_ORA.md "
                                           "en la carpeta del programa.", parent=win)
        tk.Button(pie, text="Ver el documento completo",
                  command=abrir_documento).pack(side="right", padx=8)

        def cerrar():
            cfg2 = cargar_config()
            cfg2["tutorial_visto"] = bool(v_no.get())
            guardar_config(cfg2)
            win.destroy()
        tk.Button(pie, text="Entendido", command=cerrar, bg=t["acento"],
                  fg=t["acento_txt"], relief="flat", padx=18, pady=6,
                  font=("Segoe UI", 10, "bold")).pack(side="right")
        win.protocol("WM_DELETE_WINDOW", cerrar)

    def abrir_biblioteca():
        """Biblioteca 3D — Apartado A.

        Administra `biblioteca/fichas.json`: las fichas de VANOS (puertas,
        ventanas, mamparas, portones) con sus medidas reales, y el mapeo
        de MOBILIARIO (bloque del DXF -> archivo .skp).

        Importante para lo que viene después (Apartado B — Insertar
        Mobiliario): hoy la inserción de un vano en SketchUp busca un
        archivo con el MISMO NOMBRE que el código del plano (si el vano
        se llama "P-7" en el DXF, busca "P-7.skp"). Las fichas que se
        cargan aquí NO cambian eso todavía — son la base de datos con
        medidas reales que el Apartado B va a usar para SUGERIR una
        ficha por medida (ancho/alto/alféizar), aunque su código no
        tenga nada que ver con el del plano. Por eso el código de cada
        ficha es libre: no hace falta que calce con ningún vano real.
        """
        import biblioteca_datos as bd
        t = T()
        win = tk.Toplevel(root)
        win.title("Biblioteca 3D — ORA Modeler")
        win.geometry("880x600")
        win.configure(bg=t["bg"])
        win.transient(root)

        tk.Label(win, text="Biblioteca 3D", bg=t["bg"], fg=t["acento"],
                 font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=16,
                                                      pady=(14, 2))
        tk.Label(win, text="Puertas, ventanas, mamparas, portones y mobiliario "
                           "con su .skp. Independiente de cualquier proyecto: "
                           "llénala cuando quieras, no depende de tener un "
                           "plano cargado.",
                 bg=t["bg"], fg=t["texto"], font=("Segoe UI", 9), justify="left"
                 ).pack(anchor="w", padx=16, pady=(0, 8))

        pestanas = tk.Frame(win, bg=t["bg"])
        pestanas.pack(fill="x", padx=16)
        cont = tk.Frame(win, bg=t["bg"])
        cont.pack(fill="both", expand=True, padx=16, pady=(8, 0))

        seccion = {"activa": "vanos"}

        def _boton_pestana(txt, clave):
            activo = seccion["activa"] == clave
            return tk.Button(
                pestanas, text=txt, relief=("solid" if activo else "flat"),
                bd=1, cursor="hand2", font=("Segoe UI", 9, "bold" if activo else "normal"),
                bg=(t["panel"] if activo else t["bg"]), fg=t["texto"],
                command=lambda: _cambiar(clave))

        def _cambiar(clave):
            seccion["activa"] = clave
            _refrescar_pestanas()
            _refrescar_tabla()

        def _refrescar_pestanas():
            for w in pestanas.winfo_children():
                w.destroy()
            _boton_pestana("🚪 Vanos (puertas / ventanas / mamparas / portones)",
                           "vanos").pack(side="left", padx=(0, 4))
            _boton_pestana("🛋️ Mobiliario", "mobiliario").pack(side="left")

        # ---------------- tabla (mismo patrón que la tabla de elementos:
        # Canvas + Scrollbar + Frame interior con filas en grid) ----------
        def _tabla_vacia():
            for w in cont.winfo_children():
                w.destroy()

        def _refrescar_tabla():
            _tabla_vacia()
            if seccion["activa"] == "vanos":
                _pintar_vanos()
            else:
                _pintar_mobiliario()

        def _armar_scroll():
            fr = tk.Frame(cont, bg=t["bg"])
            fr.pack(fill="both", expand=True)
            canvas = tk.Canvas(fr, bg=t["bg"], highlightthickness=0)
            scroll = ttk.Scrollbar(fr, orient="vertical", command=canvas.yview)
            tabla = tk.Frame(canvas, bg=t["bg"])
            tabla.bind("<Configure>",
                      lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
            canvas.create_window((0, 0), window=tabla, anchor="nw")
            canvas.configure(yscrollcommand=scroll.set)
            canvas.pack(side="left", fill="both", expand=True)
            scroll.pack(side="right", fill="y")

            def _rueda(event):
                delta = -1 if (getattr(event, "num", 0) == 5 or event.delta < 0) else 1
                canvas.yview_scroll(-delta, "units")
                return "break"
            for w in (canvas, tabla):
                w.bind("<MouseWheel>", _rueda)
                w.bind("<Button-4>", _rueda)
                w.bind("<Button-5>", _rueda)
            return tabla

        def _pintar_vanos():
            barra = tk.Frame(cont, bg=t["bg"]); barra.pack(fill="x", pady=(0, 6))
            tk.Button(barra, text="➕ Agregar vano", cursor="hand2",
                      command=lambda: _dialogo_vano()).pack(side="left")
            tabla = _armar_scroll()
            cab_f = tk.Frame(tabla, bg=t["bg"]); cab_f.pack(fill="x")
            for c, (txt, w) in enumerate((("Código", 16), ("Tipo", 9),
                                          ("Ancho", 6), ("Alto", 6),
                                          ("Alféizar", 8), ("Material", 16),
                                          (".skp", 5), ("", 6), ("", 6))):
                tk.Label(cab_f, text=txt, font=("Segoe UI", 8, "bold"), width=w,
                        anchor="w", bg=t["bg"], fg=t["texto"]).grid(
                    row=0, column=c, padx=3, pady=2)
            filas = bd.listar_vanos()
            if not filas:
                tk.Label(tabla, text="Sin fichas de vanos todavía. Agrega la primera "
                                     "con el botón de arriba.",
                        bg=t["bg"], fg=t["texto"], font=("Segoe UI", 9)
                        ).pack(anchor="w", pady=10)
            for fila_datos in filas:
                fr = tk.Frame(tabla, bg=t["bg"]); fr.pack(fill="x")
                vals = (fila_datos["codigo"], fila_datos.get("tipo", ""),
                        f'{fila_datos.get("ancho", 0):.2f}',
                        f'{fila_datos.get("alto", 0):.2f}',
                        f'{fila_datos.get("alfeizar", 0):.2f}',
                        fila_datos.get("material", ""),
                        "✅" if fila_datos["tiene_skp"] else "❌")
                anchos = (16, 9, 6, 6, 8, 16, 5)
                for c, (v, w) in enumerate(zip(vals, anchos)):
                    tk.Label(fr, text=v, width=w, anchor="w", bg=t["bg"],
                            fg=t["texto"], font=("Segoe UI", 8)).grid(
                        row=0, column=c, padx=3, pady=1)
                cod = fila_datos["codigo"]
                tk.Button(fr, text="Editar", font=("Segoe UI", 7),
                         command=lambda c=cod: _dialogo_vano(c)).grid(
                    row=0, column=7, padx=2)
                tk.Button(fr, text="Borrar", font=("Segoe UI", 7),
                         command=lambda c=cod: _borrar_vano(c)).grid(
                    row=0, column=8, padx=2)

        def _borrar_vano(codigo):
            if messagebox.askyesno("Borrar ficha",
                                   f"¿Borrar la ficha «{codigo}» de la biblioteca?\n"
                                   "(El archivo .skp NO se borra del disco, "
                                   "solo se deja de usar.)", parent=win):
                bd.borrar_vano(codigo)
                _refrescar_tabla()

        def _pintar_mobiliario():
            barra = tk.Frame(cont, bg=t["bg"]); barra.pack(fill="x", pady=(0, 6))
            tk.Button(barra, text="➕ Agregar mobiliario", cursor="hand2",
                      command=lambda: _dialogo_mueble()).pack(side="left")
            tk.Label(barra, text="  El «Bloque DXF» es el nombre del bloque tal "
                                 "como aparece en tu plano (INODORO, CAMA...).",
                    bg=t["bg"], fg=t["texto"], font=("Segoe UI", 8)
                    ).pack(side="left", padx=8)
            tabla = _armar_scroll()
            cab_f = tk.Frame(tabla, bg=t["bg"]); cab_f.pack(fill="x")
            for c, (txt, w) in enumerate((("Bloque DXF", 20), ("Archivo .skp", 24),
                                          (".skp", 5), ("", 6), ("", 6))):
                tk.Label(cab_f, text=txt, font=("Segoe UI", 8, "bold"), width=w,
                        anchor="w", bg=t["bg"], fg=t["texto"]).grid(
                    row=0, column=c, padx=3, pady=2)
            filas = bd.listar_mobiliario()
            if not filas:
                tk.Label(tabla, text="Sin mobiliario mapeado todavía.",
                        bg=t["bg"], fg=t["texto"], font=("Segoe UI", 9)
                        ).pack(anchor="w", pady=10)
            for fila_datos in filas:
                fr = tk.Frame(tabla, bg=t["bg"]); fr.pack(fill="x")
                vals = (fila_datos["nombre"], fila_datos["archivo"],
                        "✅" if fila_datos["tiene_skp"] else "❌")
                anchos = (20, 24, 5)
                for c, (v, w) in enumerate(zip(vals, anchos)):
                    tk.Label(fr, text=v, width=w, anchor="w", bg=t["bg"],
                            fg=t["texto"], font=("Segoe UI", 8)).grid(
                        row=0, column=c, padx=3, pady=1)
                nom = fila_datos["nombre"]
                tk.Button(fr, text="Editar", font=("Segoe UI", 7),
                         command=lambda n=nom: _dialogo_mueble(n)).grid(
                    row=0, column=3, padx=2)
                tk.Button(fr, text="Borrar", font=("Segoe UI", 7),
                         command=lambda n=nom: _borrar_mueble(n)).grid(
                    row=0, column=4, padx=2)

        def _borrar_mueble(nombre):
            if messagebox.askyesno("Borrar mapeo",
                                   f"¿Borrar el mapeo de «{nombre}»?", parent=win):
                bd.borrar_mueble(nombre)
                _refrescar_tabla()

        # ---------------- diálogo Agregar/Editar VANO ----------------
        def _dialogo_vano(codigo_existente=None):
            editando = codigo_existente is not None
            ficha = {}
            if editando:
                ficha = next((f for f in bd.listar_vanos()
                             if f["codigo"] == codigo_existente), {})
            d = tk.Toplevel(win)
            d.title("Editar vano" if editando else "Agregar vano")
            d.configure(bg=t["bg"])
            d.transient(win)
            d.grab_set()

            def campo(r, etiqueta, valor="", ancho=30):
                tk.Label(d, text=etiqueta, bg=t["bg"], fg=t["texto"],
                        font=("Segoe UI", 9)).grid(row=r, column=0, sticky="w",
                                                   padx=12, pady=4)
                v = tk.StringVar(value=str(valor))
                tk.Entry(d, textvariable=v, width=ancho).grid(
                    row=r, column=1, sticky="we", padx=12, columnspan=2)
                return v

            v_cod = campo(0, "Código (libre — no depende del plano)",
                         codigo_existente or "")
            if editando:
                # El código es la clave: para "renombrar" se borra y se
                # agrega de nuevo, así nunca queda una ficha a medias.
                d.nametowidget(d.grid_slaves(row=0, column=1)[0]).configure(
                    state="disabled")

            tk.Label(d, text="Tipo", bg=t["bg"], fg=t["texto"],
                    font=("Segoe UI", 9)).grid(row=1, column=0, sticky="w",
                                               padx=12, pady=4)
            v_tipo = tk.StringVar(value=ficha.get("tipo", "puerta"))
            ttk.Combobox(d, textvariable=v_tipo, values=bd.TIPOS_VANO,
                        state="readonly", width=14).grid(row=1, column=1,
                                                         sticky="w", padx=12)

            v_ancho = campo(2, "Ancho (m)", ficha.get("ancho", ""), 10)
            v_alto = campo(3, "Alto (m)", ficha.get("alto", ""), 10)
            v_alfeizar = campo(4, "Alféizar (m) — 0 si es puerta",
                              ficha.get("alfeizar", 0.0), 10)
            v_material = campo(5, "Material", ficha.get("material", ""))
            v_archivo = campo(6, "Archivo .skp", ficha.get("archivo", ""))

            def _buscar_skp():
                ruta = filedialog.askopenfilename(
                    title="Elige el archivo .skp", parent=d,
                    filetypes=[("SketchUp", "*.skp")])
                if not ruta:
                    return
                nombre_sugerido = (v_cod.get().strip() or "pieza")
                try:
                    final = bd.importar_skp(ruta, nombre_sugerido)
                    v_archivo.set(final)
                    messagebox.showinfo(
                        "ORA", f"Copiado a biblioteca/{final}", parent=d)
                except Exception as ex:
                    messagebox.showerror("ORA", str(ex), parent=d)
            tk.Button(d, text="Buscar .skp...", command=_buscar_skp).grid(
                row=6, column=3, padx=8)

            msg = tk.Label(d, text="", bg=t["bg"], fg=t["warn"],
                          font=("Segoe UI", 8), wraplength=380, justify="left")
            msg.grid(row=7, column=0, columnspan=4, sticky="w", padx=12)

            def _guardar():
                try:
                    ancho = float(v_ancho.get().replace(",", "."))
                    alto = float(v_alto.get().replace(",", "."))
                    alfeizar = float((v_alfeizar.get() or "0").replace(",", "."))
                except ValueError:
                    msg.configure(text="Ancho, alto y alféizar deben ser números "
                                       "(ej. 0.90).")
                    return
                try:
                    if editando:
                        bd.editar_vano(codigo_existente, tipo=v_tipo.get(),
                                       ancho=ancho, alto=alto, alfeizar=alfeizar,
                                       material=v_material.get(),
                                       archivo=v_archivo.get())
                    else:
                        bd.agregar_vano(v_cod.get(), v_tipo.get(), ancho, alto,
                                        alfeizar, v_material.get(), v_archivo.get())
                except ValueError as ex:
                    msg.configure(text=str(ex))
                    return
                d.destroy()
                _refrescar_tabla()

            pie = tk.Frame(d, bg=t["bg"]); pie.grid(row=8, column=0, columnspan=4,
                                                     sticky="we", padx=12, pady=12)
            tk.Button(pie, text="Guardar", command=_guardar, bg=t["acento"],
                     fg=t["acento_txt"], relief="flat", padx=16, pady=4,
                     font=("Segoe UI", 9, "bold")).pack(side="right")
            tk.Button(pie, text="Cancelar", command=d.destroy).pack(
                side="right", padx=8)
            d.lift()

        # ---------------- diálogo Agregar/Editar MOBILIARIO ----------------
        def _dialogo_mueble(nombre_existente=None):
            editando = nombre_existente is not None
            actual = next((f for f in bd.listar_mobiliario()
                          if f["nombre"] == nombre_existente), {})
            d = tk.Toplevel(win)
            d.title("Editar mobiliario" if editando else "Agregar mobiliario")
            d.configure(bg=t["bg"])
            d.transient(win)
            d.grab_set()

            tk.Label(d, text="Bloque DXF (nombre exacto del bloque en tu plano)",
                    bg=t["bg"], fg=t["texto"], font=("Segoe UI", 9)).grid(
                row=0, column=0, sticky="w", padx=12, pady=4)
            v_nom = tk.StringVar(value=nombre_existente or "")
            e_nom = tk.Entry(d, textvariable=v_nom, width=26)
            e_nom.grid(row=0, column=1, sticky="we", padx=12, columnspan=2)
            if editando:
                e_nom.configure(state="disabled")

            tk.Label(d, text="Archivo .skp", bg=t["bg"], fg=t["texto"],
                    font=("Segoe UI", 9)).grid(row=1, column=0, sticky="w",
                                               padx=12, pady=4)
            v_arch = tk.StringVar(value=actual.get("archivo", ""))
            tk.Entry(d, textvariable=v_arch, width=26).grid(
                row=1, column=1, sticky="we", padx=12, columnspan=2)

            def _buscar_skp():
                ruta = filedialog.askopenfilename(
                    title="Elige el archivo .skp", parent=d,
                    filetypes=[("SketchUp", "*.skp")])
                if not ruta:
                    return
                nombre_sugerido = (v_nom.get().strip().lower() or "mueble")
                try:
                    final = bd.importar_skp(ruta, nombre_sugerido)
                    v_arch.set(final)
                except Exception as ex:
                    messagebox.showerror("ORA", str(ex), parent=d)
            tk.Button(d, text="Buscar .skp...", command=_buscar_skp).grid(
                row=1, column=3, padx=8)

            msg = tk.Label(d, text="", bg=t["bg"], fg=t["warn"],
                          font=("Segoe UI", 8))
            msg.grid(row=2, column=0, columnspan=4, sticky="w", padx=12)

            def _guardar():
                try:
                    if editando:
                        bd.editar_mueble(nombre_existente, v_arch.get())
                    else:
                        bd.agregar_mueble(v_nom.get(), v_arch.get())
                except ValueError as ex:
                    msg.configure(text=str(ex))
                    return
                d.destroy()
                _refrescar_tabla()

            pie = tk.Frame(d, bg=t["bg"]); pie.grid(row=3, column=0, columnspan=4,
                                                     sticky="we", padx=12, pady=12)
            tk.Button(pie, text="Guardar", command=_guardar, bg=t["acento"],
                     fg=t["acento_txt"], relief="flat", padx=16, pady=4,
                     font=("Segoe UI", 9, "bold")).pack(side="right")
            tk.Button(pie, text="Cancelar", command=d.destroy).pack(
                side="right", padx=8)
            d.lift()

        tk.Button(win, text="Cerrar", command=win.destroy).pack(
            anchor="e", padx=16, pady=12)

        _refrescar_pestanas()
        _refrescar_tabla()
        win.lift()

    def abrir_configuracion():
        from ia_asistente import cargar_config, guardar_config
        cfg = cargar_config()
        t = T()
        win = tk.Toplevel(root)
        win.title("Configuración — ORA Modeler")
        win.geometry("620x900")
        win.configure(bg=t["bg"])
        win.transient(root)

        def fila(fila_n, etiqueta, valor, ancho=44, secreto=False):
            tk.Label(win, text=etiqueta, bg=t["bg"], fg=t["texto"],
                     font=("Segoe UI", 9)).grid(row=fila_n, column=0,
                                                sticky="w", padx=12, pady=4)
            v = tk.StringVar(value=valor)
            e = tk.Entry(win, textvariable=v, width=ancho,
                         show=("•" if secreto else ""))
            e.grid(row=fila_n, column=1, sticky="we", padx=12)
            return v

        tk.Label(win, text="SketchUp", bg=t["bg"], fg=t["acento"],
                 font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w",
                                                     padx=12, pady=(12, 0))
        v_su = fila(1, "Ruta de SketchUp.exe", cfg.get("sketchup_exe", ""))

        def buscar_su():
            r = filedialog.askopenfilename(title="Ubica SketchUp.exe",
                                           filetypes=[("SketchUp", "SketchUp.exe"),
                                                      ("Ejecutables", "*.exe")])
            if r:
                v_su.set(r)
        tk.Button(win, text="Buscar...", command=buscar_su).grid(row=1, column=2, padx=6)

        tk.Label(win, text="Inteligencia artificial (opcional)", bg=t["bg"],
                 fg=t["acento"], font=("Segoe UI", 10, "bold")).grid(
            row=2, column=0, columnspan=2, sticky="w", padx=12, pady=(14, 0))
        tk.Label(win, text="Se usa para sugerir el cuadro de vanos cuando el plano\n"
                 "trae bloques sin medidas. Si un proveedor agota su cuota,\n"
                 "ORA cambia solo al otro.", bg=t["bg"], fg=t["texto"],
                 font=("Segoe UI", 8), justify="left").grid(
            row=3, column=0, columnspan=2, sticky="w", padx=12)

        tk.Label(win, text="Proveedor preferido", bg=t["bg"], fg=t["texto"],
                 font=("Segoe UI", 9)).grid(row=4, column=0, sticky="w", padx=12)
        v_prov = tk.StringVar(value=cfg.get("ia_proveedor", "gemini"))
        ttk.Combobox(win, textvariable=v_prov, values=["gemini", "nvidia"],
                     state="readonly", width=12).grid(row=4, column=1,
                                                      sticky="w", padx=12)
        v_gem = fila(5, "API key de Gemini", cfg.get("gemini_api_key", ""), secreto=True)
        v_nvi = fila(6, "API key de NVIDIA (nvapi-...)", cfg.get("nvidia_api_key", ""), secreto=True)
        tk.Label(win, text="La key de NVIDIA es gratis en build.nvidia.com\n"
                 "(Developer Program: créditos de inferencia sin tarjeta).",
                 bg=t["bg"], fg=t["texto"], font=("Segoe UI", 8),
                 justify="left").grid(row=7, column=0, columnspan=2,
                                      sticky="w", padx=12)

        # ---------------- PROBAR LA IA ----------------
        # Willy: «hay modelos que tú piensas que están funcionando pero ya no
        # están funcionando». Tenía razón: `gemini-2.0-flash` llevaba meses
        # retirado y ORA lo llamaba en silencio. Este botón recorre la
        # cascada entera y enseña cuál responde y cuál está caído.
        def probar_ia():
            v_ia.configure(text="Probando la cascada de modelos…",
                           fg=t["texto"])
            win.update()

            def trabajo():
                try:
                    import ia_asistente as _ia
                    r = _ia.probar_modelos({
                        "gemini_api_key": v_gem.get().strip(),
                        "nvidia_api_key": v_nvi.get().strip(),
                        "ia_proveedor": v_prov.get()})
                except Exception as ex:
                    r = [{"proveedor": "—", "modelo": "—", "ok": False,
                          "detalle": str(ex)[:90], "ms": 0}]
                root.after(0, lambda: pintar(r))

            def pintar(r):
                vivos = [x for x in r if x["ok"]]
                L = []
                for x in r:
                    L.append(("  ✅ " if x["ok"] else "  ❌ ")
                             + f"{x['modelo']}"
                             + (f"  ({x['ms']} ms)" if x["ok"]
                                else f"  — {x['detalle']}"))
                cab = (f"{len(vivos)} de {len(r)} modelo(s) responden. "
                       f"ORA usará «{vivos[0]['modelo']}»."
                       if vivos else
                       "Ningún modelo respondió. ORA trabaja solo con lo que "
                       "lee del plano.")
                v_ia.configure(text=cab + "\n" + "\n".join(L),
                               fg=("#0f7b3f" if vivos else "#b45309"))
            threading.Thread(target=trabajo, daemon=True).start()

        tk.Button(win, text="🤖 Probar la IA (mira qué modelos responden)",
                  command=probar_ia, cursor="hand2").grid(
                      row=8, column=0, columnspan=2, sticky="w", padx=12,
                      pady=(6, 2))
        v_ia = tk.Label(win, text="", bg=t["bg"], fg=t["texto"],
                        font=("Consolas", 8), justify="left", anchor="w")
        v_ia.grid(row=9, column=0, columnspan=2, sticky="w", padx=12)

        # ---------------- MEMORIA DE APRENDIZAJE ----------------
        from memoria_elementos import (resumen_memoria, limpiar_plano, limpiar_todo,
                                       exportar_diagnostico, ARCHIVO as ARCHIVO_MEM)
        firma_cfg = ((motor.resumen or {}).get("clasificacion_capas") or {}).get("firma")
        res_mem = resumen_memoria()
        marco_mem = tk.LabelFrame(win, text="  Memoria de aprendizaje  ",
                                  bg=t["bg"], fg=t["texto"],
                                  font=("Segoe UI", 9, "bold"), padx=10, pady=8)
        marco_mem.grid(row=8, column=0, columnspan=3, sticky="we", padx=12, pady=(10, 0))
        lbl_mem = tk.Label(
            marco_mem, bg=t["bg"], fg=t["texto"], justify="left",
            font=("Segoe UI", 8),
            text=(f"{res_mem['planos']} plano(s) con memoria · "
                  f"{res_mem['congelados']} congelado(s) · "
                  f"{res_mem['excluidos']} excluido(s) · "
                  f"{res_mem['medidas']} medida(s)\n"
                  f"Archivo: {ARCHIVO_MEM}"))
        lbl_mem.pack(anchor="w")

        def _refrescar_mem():
            r2 = resumen_memoria()
            lbl_mem.configure(
                text=(f"{r2['planos']} plano(s) con memoria · "
                      f"{r2['congelados']} congelado(s) · "
                      f"{r2['excluidos']} excluido(s) · "
                      f"{r2['medidas']} medida(s)\n"
                      f"Archivo: {ARCHIVO_MEM}"))

        def olvidar_plano():
            if not firma_cfg:
                messagebox.showinfo("ORA", "Analiza un plano primero para saber "
                                           "cuál olvidar.", parent=win)
                return
            if not messagebox.askyesno(
                    "ORA", "¿Olvidar TODO lo aprendido de este plano?\n\n"
                           "Se borran los elementos congelados, los excluidos y las "
                           "medidas aprendidas SOLO de este plano. Los demás "
                           "proyectos no se tocan.\n\nNo se puede deshacer.",
                    parent=win):
                return
            n = limpiar_plano(firma_cfg)
            _refrescar_mem()
            log(f"🧹 Memoria de este plano borrada ({n} registro(s)).", "ok")

        def olvidar_todo():
            if not messagebox.askyesno(
                    "ORA", "¿Olvidar lo aprendido de TODOS los planos?\n\n"
                           "Esto borra la memoria completa de ORA, de todos tus "
                           "proyectos.\n\nNo se puede deshacer.", parent=win):
                return
            try:
                _firma_para_trace = _firma_actual()
            except Exception:
                _firma_para_trace = None
            trace_forense.evento(
                "proyecto:olvidar_todo", funcion="olvidar_todo",
                firma=_firma_para_trace)
            n = _olvidar_todo_de_verdad(limpiar_todo)
            _refrescar_mem()
            log(f"🧹 Memoria completa borrada ({n} registro(s)).", "ok")

        def exportar_diag():
            destino = filedialog.asksaveasfilename(
                title="Guardar diagnóstico", parent=win, defaultextension=".json",
                initialfile="ora_diagnostico.json",
                filetypes=[("Diagnóstico ORA", "*.json")])
            if not destino:
                return
            extra = {"plano": motor.archivo, "unidad": motor.unidad,
                     "dudas": (motor.resumen or {}).get("dudas", []),
                     "muros": (motor.resumen or {}).get("muros"),
                     "escalera": bool((motor.resumen or {}).get("escalera"))}
            exportar_diagnostico(destino, firma_cfg, extra)
            log(f"📤 Diagnóstico guardado: {destino}", "ok")
            messagebox.showinfo(
                "ORA", "Diagnóstico guardado.\n\nEste archivo NO se envía solo a "
                       "ningún lado: queda en tu PC y tú decides si lo compartes.",
                parent=win)

        fr_mem = tk.Frame(marco_mem, bg=t["bg"])
        fr_mem.pack(fill="x", pady=(6, 0))
        tk.Button(fr_mem, text="🧹 Olvidar este plano", command=olvidar_plano,
                  font=("Segoe UI", 8)).pack(side="left")
        tk.Button(fr_mem, text="Olvidar todo", command=olvidar_todo,
                  font=("Segoe UI", 8)).pack(side="left", padx=6)
        tk.Button(fr_mem, text="📤 Exportar diagnóstico", command=exportar_diag,
                  font=("Segoe UI", 8)).pack(side="right")

        # ---------------- AVISOS ----------------
        v_avisos = tk.BooleanVar(
            value=bool(cfg.get("avisos_automaticos", True)))
        marco_av = tk.Frame(win, bg=t["bg"])
        marco_av.grid(row=10, column=0, columnspan=3, sticky="we",
                      padx=12, pady=(10, 0))
        tk.Label(marco_av, text="Avisos", bg=t["bg"], fg=t["acento"],
                 font=("Segoe UI", 10, "bold")).pack(anchor="w")
        tk.Checkbutton(
            marco_av, variable=v_avisos, bg=t["bg"], fg=t["texto"],
            selectcolor=t["bg"], activebackground=t["bg"],
            font=("Segoe UI", 9),
            text="Abrir sola la ventana de avisos al llegar a cada paso"
        ).pack(anchor="w")
        tk.Label(marco_av, justify="left", bg=t["bg"], fg=t["texto"],
                 font=("Segoe UI", 8),
                 text="Apagado, los avisos leves siguen contándose en la "
                      "columna con su botón\npara abrirlos — solo dejan de "
                      "interrumpirte. Los importantes (un paño sin\nNPT, una "
                      "viga sin peralte, un vano sin muro) salen SIEMPRE: son "
                      "cosas que\nORA no inventa, y callarlas sería darlas "
                      "por buenas en silencio."
                 ).pack(anchor="w")

        def guardar():
            cfg.update({"sketchup_exe": v_su.get().strip(),
                        "ia_proveedor": v_prov.get(),
                        "gemini_api_key": v_gem.get().strip(),
                        "nvidia_api_key": v_nvi.get().strip(),
                        "avisos_automaticos": bool(v_avisos.get())})
            guardar_config(cfg)
            win.destroy()
            log("Configuración guardada.", "ok")
        tk.Button(win, text="Guardar", command=guardar, bg=t["acento"],
                  fg=t["acento_txt"], relief="flat", padx=18, pady=6,
                  font=("Segoe UI", 10, "bold")).grid(row=11, column=1,
                                                      sticky="e", padx=12, pady=16)
        win.columnconfigure(1, weight=1)

    def sugerir_con_ia():
        if not filas_cv:
            return
        log("Consultando a la IA (Gemini/NVIDIA)...", "warn")

        def trabajo():
            try:
                from ia_asistente import sugerir_cuadro_vanos
                bloques = []
                r = motor.resumen or {}
                # descripción simple: nombre + cuántas veces aparece
                for nb, *_ in filas_cv:
                    bloques.append({"nombre": nb})
                sugerido, proveedor = sugerir_cuadro_vanos(bloques)

                def aplicar():
                    for nb, vt, vc, va, vh, vf in filas_cv:
                        s = sugerido.get(nb)
                        if not s:
                            continue
                        vt.set("P" if s.get("tipo") == "door" else "V")
                        vc.set(s.get("codigo") or "")
                        va.set(str(s.get("ancho", "")))
                        vh.set(str(s.get("alto", "")))
                        vf.set(str(s.get("alfeizar", 0.0)))
                    log(f"Sugerencias aplicadas ({proveedor}). Revísalas antes de generar.", "ok")
                root.after(0, aplicar)
            except Exception as ex:
                root.after(0, lambda _m=str(ex): log(f"IA no disponible: {_m}", "warn"))
        threading.Thread(target=trabajo, daemon=True).start()

    def elegir_cortes():
        ruta = filedialog.askopenfilename(
            title="③ DXF DE CORTES/elevaciones (opcional)",
            filetypes=[("Planos DXF", "*.dxf"), ("Todos", "*.*")],
            initialdir=os.path.join(BASE, "ejemplos"))
        if ruta:
            var_cortes.set(ruta)

    btn_aplicar_edit.configure(command=aplicar_edicion_ficha)
    btn_confirmar.configure(command=confirmar_paso)
    btn_reintentar.configure(command=reintentar_paso)
    btn_descartar.configure(command=descartar_paso)
    btn_atras.configure(command=paso_anterior)
    btn_buscar.configure(command=elegir_archivo)

    def _elegir_carril(cual, avisar=True):
        """Fija el carril y enseña SOLO lo suyo.

        Un piso y multipisos dejan de compartir pantalla. El de un piso queda
        igual que siempre — es el que está probado y funcionando —, y el de
        varios pisos abre su tabla de plantas.
        """
        modo_app["cual"] = cual
        t = TEMAS[estado["tema"]]
        for b, c in ((btn_un_piso, "un_piso"), (btn_edificio, "multipisos")):
            b.configure(bg=(t["acento"] if cual == c else t.get("bg_boton",
                                                                "#f0f0f0")),
                        fg=(t["acento_txt"] if cual == c else t["texto"]),
                        relief=("flat" if cual == c else "raised"))
        # Willy: «cuando presionas un piso, RECIÉN aparezca para poder subir
        # un DXF limpio». Antes los tres campos estaban a la vista desde el
        # arranque aunque no hubieras elegido nada, y convivían con la tabla
        # de plantas: la mezcla que él pedía cortar.
        for w in campos_un_piso:
            w.grid_remove()
        if cual == "un_piso":
            for w in campos_un_piso:
                w.grid()
            p2_lectura.pack_forget()
            p2.pack(fill="x", pady=(0, 8), before=p3)
            _volver_a_un_piso()
            estado["edificio"] = []
            _guardar_edificio_en_disco([])
            refrescar_etiqueta_edificio()
            lbl_carril.configure(
                text="Un plano suelto. Elige el DXF limpio arriba y pulsa "
                     "ANALIZAR PLANO.")
            if avisar:
                log("Modo UN PISO. Un plano suelto, como siempre.", "ok")
        else:
            lbl_carril.configure(
                text="Varias plantas. Cárgalas en la tabla; los campos de "
                     "arriba se rellenan solos con la planta que estés "
                     "mirando.")
            # multipisos: fuera el panel editable, entra el de solo lectura
            p2.pack_forget()
            p2_lectura.pack(fill="x", pady=(0, 8), before=p3)
            _pintar_medido()
            if avisar:
                log("Modo VARIOS PISOS. Carga una planta por fila. La altura "
                    "y la losa salen del corte: aquí ya no se escriben.", "ok")
                abrir_edificio()
        refrescar_fases()

    btn_un_piso.configure(command=lambda: _elegir_carril("un_piso"))
    btn_edificio.configure(command=lambda: _elegir_carril("multipisos"))
    # Al abrir: si quedaron plantas guardadas, se retoma el carril de
    # multipisos; si no, un piso.
    _elegir_carril("multipisos" if estado.get("edificio") else "un_piso",
                   avisar=False)
    btn_cortes.configure(command=elegir_cortes)
    btn_specs.configure(command=elegir_specs)
    btn_analizar.configure(command=analizar)
    btn_generar.configure(command=generar)
    btn_tema.configure(command=alternar_tema)
    btn_config.configure(command=abrir_configuracion)
    btn_ayuda.configure(command=lambda: mostrar_tutorial(forzado=True))
    btn_biblioteca.configure(command=abrir_biblioteca)

    aplicar_tema()
    # GANCHOS DE PRUEBA. No cambian nada del funcionamiento: son referencias a
    # las funciones internas para que una prueba pueda ABRIR ESTA MISMA
    # VENTANA y operarla, en vez de replicar el mecanismo por fuera (que es lo
    # que hizo la v34 y por eso salía verde mientras a Willy le fallaba).
    root._ora = {"motor": motor, "refrescar_fases": refrescar_fases,
                 "pintar_avisos": _pintar_avisos,
                 "avisos_del_paso": _avisos_del_paso,
                 "resolver_aviso": _resolver_aviso,
                 "ventana_avisos": _ventana_avisos,
                 "win_avisos": win_avisos, "paso_actual": paso_actual,
                 "fase_disponible": _fase_disponible,
                 "btn_vivo": btn_vivo,
                 # v43 — EL CAMINO DEL EDIFICIO, OPERABLE DESDE UNA PRUEBA.
                 # Faltaban justo estos: por eso el fallo del filtro de rutas
                 # (una tupla llegando a os.path.exists) llegó hasta la
                 # pantalla de Willy con 36 pruebas en verde. La única prueba
                 # que lo tocaba comprobaba que un texto estuviera en el
                 # archivo; nunca EJECUTÓ nada.
                 "detectar_edificio": _detectar_edificio,
                 "abrir_edificio": abrir_edificio,
                 "guardar_edificio_disco": _guardar_edificio_en_disco,
                 "rotulo_progreso": _rotulo_progreso,
                 "elegir_carril": _elegir_carril, "modo_app": modo_app,
                 "siguiente_nivel": _siguiente_nivel,
                 "piso_actual": _piso_actual,
                 "var_esc": var_esc,
                 "pintar_lista_vigas": _pintar_lista_vigas,
                 "aplicar_peralte_lote": _aplicar_peralte_lote,
                 "marcas_vigas": marcas_vigas,
                 "var_peralte_lote": var_peralte_lote,
                 "pasos_del_nivel": _pasos_del_nivel,
                 "observaciones_menores": _mostrar_observaciones_menores,
                 "pedir_ia_disponible": True,
                 "campos_un_piso": campos_un_piso,
                 "btn_un_piso": btn_un_piso, "btn_varios": btn_edificio,
                 "olvidar_todo": lambda: _olvidar_todo_de_verdad(
                     __import__("memoria_elementos").limpiar_todo),
                 "ventana_evidencia": _ventana_evidencia,
                 "contorno_de": _contorno_de,
                 "contorno_crudo": _contorno_crudo,
                 "bajo_nivel": bajo_nivel,
                 "analizar": analizar,
                 "analizar_edificio": analizar_edificio_ahora,
                 "ventana_insertar_mobiliario": _ventana_insertar_mobiliario,
                 "aplicar_nivel": _aplicar_nivel,
                 "estado": estado, "edificio": edificio,
                 "nivel_activo": nivel_activo,
                 "construir_decisiones": _construir_decisiones,
                 "var_archivo": var_archivo, "var_specs": var_specs,
                 "var_losa": var_losa, "var_unidad": var_unidad,
                 "btn_analizar": btn_analizar}
    refrescar_fases()
    _poll_seleccion()          # selección en tiempo real, siempre activa
    root.after(400, lambda: mostrar_tutorial())   # Fase 0: solo la 1ª vez
    root.mainloop()


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        # prueba sin ventana: motor completo con un plano de ejemplo
        m = Motor()
        plano = sys.argv[2] if len(sys.argv) > 2 else "ejemplos/planta_sin_cotas.dxf"
        r = m.analizar(plano, "m")
        print("informe:", len(m.informe()), "caracteres")
        total = m.generar({"altura_muro": 2.6, "espesor_losa": 0.2,
                           "carpinteria": False, "escalera": False})
        print("selftest OK:", total, "elementos")
    else:
        # pythonw no tiene consola: si algo revienta al construir la ventana,
        # el proceso muere sin decir NADA y parece que ORA "no arranca".
        # Aquí se atrapa, se escribe en ORA_ERROR.txt junto al programa y se
        # muestra en pantalla, para no volver a diagnosticar a ciegas.
        try:
            main()
        except Exception:
            import traceback
            detalle = traceback.format_exc()
            try:
                trace_forense.excepcion(
                    Exception(detalle.strip().splitlines()[-1]
                              if detalle.strip() else "arranque"),
                    funcion="main()")
                trace_forense.cerrar_sesion()
            except Exception:
                pass
            try:
                with open(os.path.join(BASE, "ORA_ERROR.txt"), "w",
                          encoding="utf-8") as fh:
                    fh.write(detalle)
            except Exception:
                pass
            try:
                import tkinter as tk
                from tkinter import messagebox
                aviso = tk.Tk()
                aviso.withdraw()
                messagebox.showerror(
                    "ORA no pudo abrir",
                    "ORA falló al arrancar. El detalle quedó guardado en "
                    "ORA_ERROR.txt, en la carpeta del programa.\n\n"
                    + detalle[-1200:])
                aviso.destroy()
            except Exception:
                print(detalle)
            raise
